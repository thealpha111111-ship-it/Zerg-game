/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Mode =
  | 'FIRST_PERSON'
  | 'OVERVIEW'
  | 'MUTATION'
  | 'NEWS'
  | 'MAP'
  | 'HIVE_WINDOW'
  | 'TEAM_WINDOW'
  | 'GLOBAL_COMMAND'
  | 'PROCESS_MONITOR';

export type PlayerRole = 'swarm_king' | 'swarm_queen';

export type UnitType =
  | 'Zerglings'
  | 'Roach'
  | 'Hydralisk'
  | 'Leaper'
  | 'Acid Spitter'
  | 'Overseer'
  | 'Seer'
  | 'Swarm Claws'
  | 'Queen\'s Guard'
  | 'Ultralisk'
  | 'Hive Queen'
  | 'Genarch'
  | 'Swarm King / Queen'
  | 'Burrower'
  | 'Carrier'
  | 'Mutator';

export type StructureType =
  | 'Hatchery'
  | 'Lair'
  | 'Hive'
  | 'Swarm Citadel'
  | 'Creep Tumor'
  | 'Spore Crawler'
  | 'Spine Crawler'
  | 'Nydus Network'
  | 'Nydus Worm';

export interface Unit {
  id: string;
  type: UnitType;
  name: string;
  ownerId: string; // 'swarm' or hiveId
  locationId: string;
  teamId: string | null;
  status: 'IDLE' | 'MOVING' | 'MUTATING' | 'IN_TEAM' | 'GUARDING';
  hp: number;
  maxHp: number;
  attack: number;
  consumesCap: boolean; // Overseers & Seers do not consume cap
  providesCap: number; // Overseer adds 6, Seer adds 6
}

export interface Base {
  baseId: string;
  name: string;
  ownerId: string; // 'swarm' or hiveId
  type: 'HATCHERY' | 'LAIR' | 'HIVE' | 'CITADEL';
  locationId: string;
  structureIds: string[];
  unitIds: string[];
  queenId: string | null;
  activeOrders: string[];
  status: 'ACTIVE' | 'FORMING' | 'DESTROYED';
  creepRadius: number;
  larvaeAvailable: number;
  maxLarvae: number;
}

export type ProcessType =
  | 'MUTATE_UNIT'
  | 'MUTATE_STRUCTURE'
  | 'BUILD_BASE'
  | 'HIVE_FORMATION'
  | 'TRAVEL'
  | 'DIRECTIVE_EXECUTION'
  | 'CREATE_NYDUS';

export interface Process {
  id: string;
  type: ProcessType;
  name: string;
  ownerId: string; // 'swarm' or hiveId
  targetId: string | null;
  locationId: string | null;
  startedTurn: number;
  remainingMessages: number;
  totalMessages: number;
  reservedCosts: {
    biomass?: number;
    larvae?: number;
    unitIds?: string[];
  };
  status: 'ACTIVE' | 'COMPLETED' | 'CANCELLED' | 'BLOCKED';
  onComplete: string; // ID of the completion handler
  completionData: Record<string, any>;
}

export interface PlanStep {
  stepId: string;
  description: string;
  type: 'MOVE' | 'HARVEST' | 'ENGAGE' | 'BUILD' | 'SCOUT' | 'SECURE';
  locationId: string;
  targetId?: string;
  turnsRequired: number;
  turnsSpent: number;
  isComplete: boolean;
}

export interface HiveOrder {
  orderId: string;
  hiveId: string;
  source: 'SWARM_KING' | 'HIVE_QUEEN' | 'AUTOMATION';
  text: string;
  objectiveType: 'HUNT' | 'ATTACK' | 'DEFEND' | 'EXPAND' | 'BUILD' | 'SCOUT' | 'PATROL' | 'GATHER';
  targetId: string | null;
  targetLocationId: string | null;
  teamId: string | null;
  stage:
    | 'RECEIVED'
    | 'PLANNED'
    | 'TEAM_FORMED'
    | 'MOVING'
    | 'ARRIVED'
    | 'EXECUTING'
    | 'VERIFYING'
    | 'COMPLETED'
    | 'FAILED'
    | 'BLOCKED';
  status: 'ACTIVE' | 'COMPLETED' | 'BLOCKED' | 'CANCELLED';
  plan: PlanStep[];
  currentStepIndex: number;
  completionPredicate: string;
  startedTurn: number;
  lastProgressTurn: number;
  stalledTurns: number;
  reason?: string;
}

export interface IndependentHive {
  hiveId: string;
  name: string;
  queenUnitId: string;
  status: 'FORMING' | 'ACTIVE' | 'DESTROYED';
  biomass: number;
  biomassPer10Turns: number;
  swarmShareRate: number; // e.g. 0.30
  pendingContribution: number;
  ownedUnits: string[];
  ownedBases: string[];
  teams: string[];
  activeOrders: HiveOrder[];
  completedOrders: HiveOrder[];
  constructionProcesses: string[];
  level: number;
  territory: string[];
  permissions: {
    mayAttack: boolean;
    mayExpand: boolean;
    mayCreateTeams: boolean;
  };
  mapMarkerId: string;
  color: string;
}

export interface Team {
  teamId: string;
  ownerId: string; // 'swarm' or hiveId
  name: string;
  unitIds: string[];
  homeBaseId: string;
  locationId: string;
  directive: string;
  status: 'IDLE' | 'MOVING' | 'EXECUTING' | 'RETURNING' | 'DISBANDED';
  targetId: string | null;
  targetLocationId: string | null;
  path: string[];
  progress: number; // 0 to 100
  sourceOrderId: string | null;
}

export interface MapObject {
  objectId: string;
  kind: 'BASE' | 'NYDUS_NETWORK' | 'NYDUS_WORM' | 'TEAM' | 'HIVE' | 'RESOURCE_CACHE' | 'HOSTILE';
  sourceEntityId: string;
  locationId: string;
  ownerId: string;
  status: string;
  visible: boolean;
  label: string;
}

export interface Region {
  id: string;
  name: string;
  x: number; // 0-100% coords for tactical map
  y: number;
  biome: string;
  description: string;
  hasCreep: boolean;
  creepLevel: number; // 0-100
  connectedRegionIds: string[];
  biomassYield: number;
  threatLevel: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH';
  discovered: boolean;
}

export interface NewsEntry {
  id: string;
  sourceId: string;
  sourceType: 'SWARM' | 'HIVE_QUEEN' | 'SCOUT' | 'SEER' | 'SYSTEM';
  turn: number;
  visibility: 'GLOBAL' | 'HIVE_ONLY' | 'SECRET';
  headline: string;
  facts: string;
  timestamp: number;
}

export interface StateTransition {
  id: string;
  turn: number;
  commandType: string;
  summary: string;
  before: Record<string, any>;
  after: Record<string, any>;
  timestamp: number;
}

export interface GameState {
  turn: number;
  player: {
    role: PlayerRole;
    locationId: string;
  };
  swarm: {
    biomass: number;
    larvae: number;
    unitCap: number;
    units: Unit[];
    bases: string[];
    teams: string[];
    processes: Process[];
  };
  hives: IndependentHive[];
  bases: Base[];
  teams: Team[];
  map: {
    regions: Region[];
    objects: MapObject[];
  };
  news: NewsEntry[];
  settings: {
    autoAdvanceNews: boolean;
    soundAmbiance: boolean;
  };
  log: StateTransition[];
  chatHistory: ChatMessage[];
}

export interface ChatMessage {
  id: string;
  turn: number;
  mode: Mode;
  sender: 'PLAYER' | 'ASSISTANT' | 'QUEEN';
  text: string;
  scene?: string | null;
  locationId?: string;
  metadata?: Record<string, any>;
  timestamp: number;
}

export interface StateChangeSummary {
  type: string;
  description: string;
  entityId?: string;
}

export interface FirstPersonResponse {
  mode: 'FIRST_PERSON';
  speaker: string;
  reply: string;
  scene: string | null;
  playerLocationId: string;
  stateChanges: StateChangeSummary[];
}

export type CommandType =
  | 'MOVE_PLAYER'
  | 'TALK'
  | 'MUTATE_UNIT'
  | 'MUTATE_STRUCTURE'
  | 'BUILD_HATCHERY'
  | 'CREATE_INDEPENDENT_HIVE'
  | 'SEND_HIVE_DIRECTIVE'
  | 'CREATE_TEAM'
  | 'PROGRAM_TEAM'
  | 'CREATE_NYDUS'
  | 'TRANSFER_UNITS'
  | 'SET_HIVE_POLICY'
  | 'ADVANCE_TURN';

export interface Command {
  type: CommandType;
  payload: Record<string, any>;
  rawMessage?: string;
}

export type Result<T = GameState> =
  | { ok: true; state: T; events: StateEvent[]; response?: string | FirstPersonResponse }
  | { ok: false; code: string; message: string; state: GameState };

export interface StateEvent {
  type: string;
  message: string;
  entityId?: string;
  data?: Record<string, any>;
}
