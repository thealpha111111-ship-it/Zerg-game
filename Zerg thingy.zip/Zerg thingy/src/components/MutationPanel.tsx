/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState, UnitType, StructureType } from '../types/game.ts';
import { MUTATION_RULES, MutationRule } from '../simulation/data/mutationTable.ts';
import {
  Dna,
  Bug,
  Flame,
  Clock,
  CheckCircle2,
  AlertCircle,
  Layers,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';

interface MutationPanelProps {
  state: GameState;
  onMutateUnit: (unitType: UnitType) => void;
  onMutateStructure?: (targetStructure: StructureType) => void;
}

export const MutationPanel: React.FC<MutationPanelProps> = ({
  state,
  onMutateUnit,
  onMutateStructure
}) => {
  const [filter, setFilter] = useState<'ALL' | 'UNIT' | 'STRUCTURE' | 'SUPPORT'>('ALL');
  const [selectedEntity, setSelectedEntity] = useState<MutationRule>(MUTATION_RULES['Zerglings']);

  const activeProcesses = state.swarm.processes.filter(p => p.status === 'ACTIVE');
  const hasGenarch = state.swarm.units.some(u => u.type === 'Genarch' && u.ownerId === 'swarm');
  const idleOverseer = state.swarm.units.find(u => u.type === 'Overseer' && u.ownerId === 'swarm' && u.status === 'IDLE');
  const primaryBase = state.bases.find(b => b.ownerId === 'swarm');

  // Filter rules
  const rulesList = Object.values(MUTATION_RULES).filter(rule => {
    if (filter === 'ALL') return true;
    if (filter === 'UNIT') return rule.category === 'UNIT' && !rule.isSupportUnit;
    if (filter === 'STRUCTURE') return rule.category === 'STRUCTURE';
    if (filter === 'SUPPORT') return rule.isSupportUnit || rule.category === 'UPGRADE';
    return true;
  });

  // Validation function for whether player can mutate this right now
  const checkCanMutate = (rule: MutationRule): { can: boolean; reason?: string } => {
    if (state.swarm.biomass < rule.biomassCost) {
      return { can: false, reason: `Need ${rule.biomassCost - state.swarm.biomass} more Biomass` };
    }
    if (rule.larvaCost > 0 && state.swarm.larvae < rule.larvaCost) {
      return { can: false, reason: 'No larvae available' };
    }
    if (rule.requiresGenarch && !hasGenarch) {
      return { can: false, reason: 'Requires Genarch in Swarm' };
    }
    if (rule.consumesUnitType && !idleOverseer) {
      return { can: false, reason: `Requires idle ${rule.consumesUnitType}` };
    }
    if (rule.id === 'Nydus Worm') {
      const hasNet = primaryBase?.structureIds.includes('struct-nydus-network');
      if (!hasNet) return { can: false, reason: 'Requires Nydus Network' };
    }
    if (rule.id === 'Lair' && primaryBase?.type !== 'HATCHERY') {
      return { can: false, reason: 'Requires completed Hatchery' };
    }
    if (rule.id === 'Hive' && primaryBase?.type !== 'LAIR') {
      return { can: false, reason: 'Requires completed Lair' };
    }
    return { can: true };
  };

  const handleTrigger = (rule: MutationRule) => {
    if (rule.category === 'UNIT') {
      onMutateUnit(rule.id as UnitType);
    } else if (onMutateStructure) {
      onMutateStructure(rule.id as StructureType);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
              Genetic Synthesis Vats
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              SECTION 11 CODEX
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Mutation Chamber</h1>
        </div>

        {/* Resources Quick Pill */}
        <div className="flex items-center gap-4 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2 font-mono text-xs">
          <div className="flex items-center gap-1.5 text-emerald-300">
            <Flame className="w-4 h-4 text-emerald-400" />
            <span className="font-bold">{state.swarm.biomass}</span> Biomass
          </div>
          <div className="h-4 w-px bg-neutral-800" />
          <div className="flex items-center gap-1.5 text-amber-300">
            <Bug className="w-4 h-4 text-amber-400" />
            <span className="font-bold">{state.swarm.larvae}</span> Viable Larvae
          </div>
        </div>
      </div>

      {/* Main Grid: Catalog + Detail / Active Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Mutation Catalog */}
        <div className="lg:col-span-2 space-y-4">
          {/* Filters */}
          <div className="flex items-center gap-2 border-b border-neutral-800 pb-3 font-mono text-xs">
            {(['ALL', 'UNIT', 'STRUCTURE', 'SUPPORT'] as const).map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all ${
                  filter === f
                    ? 'bg-purple-900/60 text-purple-200 border border-purple-600/50 font-bold'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
                }`}
              >
                {f === 'ALL' ? 'All Mutations' : f === 'UNIT' ? 'Combat Strains' : f === 'STRUCTURE' ? 'Bio-Structures' : 'Support & Apex'}
              </button>
            ))}
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[640px] overflow-y-auto pr-1">
            {rulesList.map(rule => {
              const status = checkCanMutate(rule);
              const isSelected = selectedEntity.id === rule.id;

              return (
                <div
                  key={rule.id}
                  onClick={() => setSelectedEntity(rule)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-purple-950/40 border-purple-500 shadow-md shadow-purple-950/50'
                      : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-sm font-bold text-neutral-100">{rule.name}</h3>
                        <span className="text-[10px] text-purple-400 font-mono">{rule.combatRole}</span>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-300">
                        {rule.turnsRequired} {rule.turnsRequired === 1 ? 'Turn' : 'Turns'}
                      </span>
                    </div>

                    <p className="text-xs text-neutral-400 mt-2 line-clamp-2 leading-relaxed">
                      {rule.description}
                    </p>
                  </div>

                  {/* Bottom Cost + Status */}
                  <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-3">
                      <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                        <Flame className="w-3.5 h-3.5" /> {rule.biomassCost}
                      </span>
                      {rule.larvaCost > 0 && (
                        <span className="text-amber-400 flex items-center gap-1 font-semibold">
                          <Bug className="w-3.5 h-3.5" /> {rule.larvaCost}
                        </span>
                      )}
                      {rule.addsCapacity && (
                        <span className="text-purple-400 font-bold">+{rule.addsCapacity} Cap</span>
                      )}
                    </div>

                    {status.can ? (
                      <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Ready
                      </span>
                    ) : (
                      <span className="text-[10px] text-neutral-400 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {status.reason}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Col: Selected Entity Detail + Incubation Trigger */}
        <div className="space-y-6">
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-purple-950/80 border border-purple-600/50 flex items-center justify-center">
                <Dna className="w-6 h-6 text-purple-400 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] font-mono text-purple-400 uppercase tracking-wider">Metamorphosis Target</span>
                <h2 className="text-lg font-black text-white">{selectedEntity.name}</h2>
                <span className="text-xs text-neutral-400">{selectedEntity.combatRole}</span>
              </div>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed bg-neutral-950/60 p-3.5 rounded-xl border border-neutral-800">
              {selectedEntity.description}
            </p>

            {/* Invariant & Requirement Checklist */}
            <div className="space-y-2 pt-1 font-mono text-xs">
              <div className="flex items-center justify-between text-neutral-300">
                <span>Biomass Cost:</span>
                <span className={state.swarm.biomass >= selectedEntity.biomassCost ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {selectedEntity.biomassCost} (You have {state.swarm.biomass})
                </span>
              </div>

              {selectedEntity.larvaCost > 0 && (
                <div className="flex items-center justify-between text-neutral-300">
                  <span>Larva Requirement:</span>
                  <span className={state.swarm.larvae >= selectedEntity.larvaCost ? 'text-amber-400 font-bold' : 'text-rose-400 font-bold'}>
                    {selectedEntity.larvaCost} Larva (Available: {state.swarm.larvae})
                  </span>
                </div>
              )}

              <div className="flex items-center justify-between text-neutral-300">
                <span>Gestation Duration:</span>
                <span className="text-purple-300 font-bold">{selectedEntity.turnsRequired} Messages / Turns</span>
              </div>

              {selectedEntity.producesCount && selectedEntity.producesCount > 1 && (
                <div className="flex items-center justify-between text-emerald-400 font-bold">
                  <span>Batch Yield:</span>
                  <span>{selectedEntity.producesCount} units per single larva</span>
                </div>
              )}

              {selectedEntity.isSupportUnit && (
                <div className="flex items-center justify-between text-purple-400 font-bold">
                  <span>Support Exception:</span>
                  <span>Consumes 0 Cap (+{selectedEntity.addsCapacity} Capacity)</span>
                </div>
              )}

              {selectedEntity.requiresGenarch && (
                <div className="flex items-center justify-between">
                  <span>Genarch Catalyst:</span>
                  <span className={hasGenarch ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {hasGenarch ? 'Available in Swarm' : 'Missing Genarch'}
                  </span>
                </div>
              )}
            </div>

            {/* Big Action Button */}
            {(() => {
              const status = checkCanMutate(selectedEntity);
              return (
                <button
                  disabled={!status.can}
                  onClick={() => handleTrigger(selectedEntity)}
                  className="w-full py-3.5 rounded-xl bg-purple-700 hover:bg-purple-600 disabled:opacity-40 disabled:hover:bg-purple-700 text-white font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-purple-900/30"
                >
                  <Dna className="w-4 h-4" />
                  <span>
                    {status.can ? `Initiate Gestation (${selectedEntity.turnsRequired} Turns)` : status.reason}
                  </span>
                </button>
              );
            })()}
          </div>

          {/* Active Incubation Vats */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                <Layers className="w-4 h-4" /> Active Incubation Vats
              </span>
              <span className="text-xs font-mono text-neutral-400">{activeProcesses.length} active</span>
            </div>

            {activeProcesses.length === 0 ? (
              <div className="text-xs text-neutral-400 text-center py-4 font-mono">
                No active gestations. Incubation fluids awaiting genetic catalyst.
              </div>
            ) : (
              <div className="space-y-3">
                {activeProcesses.map(p => {
                  const pct = Math.round(((p.totalMessages - p.remainingMessages) / p.totalMessages) * 100);
                  return (
                    <div key={p.id} className="bg-neutral-950 p-3 rounded-xl border border-purple-900/30 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-neutral-200">{p.name}</span>
                        <span className="font-mono text-purple-400">{p.remainingMessages} turns remaining</span>
                      </div>
                      <div className="w-full bg-neutral-900 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
