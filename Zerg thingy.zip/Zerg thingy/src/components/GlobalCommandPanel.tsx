/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState } from '../types/game.ts';
import {
  Globe2,
  Send,
  Crown,
  Zap,
  Target
} from 'lucide-react';

interface GlobalCommandPanelProps {
  state: GameState;
  onDispatchOrder: (directive: string, objectiveType: any, targetRegionId: string) => void;
  onAdvanceTurn: () => void;
}

export const GlobalCommandPanel: React.FC<GlobalCommandPanelProps> = ({
  state,
  onDispatchOrder,
  onAdvanceTurn
}) => {
  const [strategicText, setStrategicText] = useState('');
  const [objectiveType, setObjectiveType] = useState<any>('SCOUT');
  const [targetRegionId, setTargetRegionId] = useState(state.map.regions[1]?.id || 'region-northern-chasm');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!strategicText.trim()) return;
    onDispatchOrder(strategicText.trim(), objectiveType, targetRegionId);
    setStrategicText('');
  };

  const quickDirectives = [
    { title: 'Northern Caldron Recon', text: 'Scout northern volcanic rifts for dormant biomass deposits', type: 'SCOUT', loc: 'region-northern-chasm' },
    { title: 'Secure Sunken Ruins', text: 'Deploy forward vanguard to cleanse mercenary barricades', type: 'ATTACK', loc: 'region-sunken-expanse' },
    { title: 'Acid Trench Harvest', text: 'Establish biological extraction cordon around sulphur geysers', type: 'GATHER', loc: 'region-acid-trench' },
    { title: 'Perimeter Defense', text: 'Dig into calcified cliffs and repel intrusive wildlife', type: 'DEFEND', loc: 'region-eastern-ridge' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
              Overmind Supreme Synapse
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              GLOBAL COMMAND MODE
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Strategic Hive Nexus</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Broadcast authoritative macro-directives across all independent hives, taskforces, and brood clusters.
          </p>
        </div>

        <button
          onClick={onAdvanceTurn}
          className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-mono text-xs font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md"
        >
          <Zap className="w-4 h-4 text-amber-300" />
          <span>Advance Planetary Turn (+1)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Directive Dispatch Console */}
        <div className="lg:col-span-2 space-y-5">
          <form
            onSubmit={handleSubmit}
            className="bg-neutral-900/90 border border-purple-900/50 rounded-2xl p-6 shadow-xl space-y-4"
          >
            <div className="flex items-center gap-2 border-b border-purple-900/30 pb-3">
              <Globe2 className="w-5 h-5 text-purple-400" />
              <h2 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
                Broadcast Strategic Order
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-mono text-neutral-400 block mb-1.5">Operational Doctrine</label>
                <select
                  value={objectiveType}
                  onChange={e => setObjectiveType(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-neutral-200 focus:outline-none focus:border-purple-500"
                >
                  <option value="SCOUT">SCOUT: Reveal sector fog & detect threats</option>
                  <option value="HUNT">HUNT: Seek out and eliminate hostile fauna</option>
                  <option value="ATTACK">ATTACK: Assault enemy defensive strongpoint</option>
                  <option value="DEFEND">DEFEND: Establish fortified defense grid</option>
                  <option value="EXPAND">EXPAND: Seed auxiliary creep nodes</option>
                  <option value="GATHER">GATHER: Secure biomass deposits</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-mono text-neutral-400 block mb-1.5">Target Sector Coordinates</label>
                <select
                  value={targetRegionId}
                  onChange={e => setTargetRegionId(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs font-mono text-neutral-200 focus:outline-none focus:border-purple-500"
                >
                  {state.map.regions.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.name} ({r.threatLevel} threat)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-mono text-neutral-400 block mb-1.5">Directive Instructions</label>
              <textarea
                rows={3}
                value={strategicText}
                onChange={e => setStrategicText(e.target.value)}
                placeholder="Formulate strategic decree (e.g. 'Deploy strike teams to eliminate hostile mercenary camp in Sunken Expanse and claim metal salvage')..."
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl p-3 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-purple-500 font-mono resize-none"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!strategicText.trim()}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 disabled:opacity-40 text-white font-mono text-xs font-bold flex items-center gap-2 cursor-pointer shadow-lg"
              >
                <Send className="w-4 h-4" />
                <span>Transmit Global Decree</span>
              </button>
            </div>
          </form>

          {/* Preset Decrees */}
          <div className="bg-neutral-900/70 border border-neutral-800 rounded-2xl p-5 space-y-3">
            <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider block">
              Doctrine Presets
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {quickDirectives.map((d, i) => (
                <div
                  key={i}
                  onClick={() => {
                    setStrategicText(d.text);
                    setObjectiveType(d.type);
                    setTargetRegionId(d.loc);
                  }}
                  className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-purple-600/50 transition-all cursor-pointer space-y-1"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-neutral-200">
                    <span>{d.title}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 border border-purple-800">
                      {d.type}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 line-clamp-1">{d.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Sub-Brood Network Status */}
        <div className="space-y-5">
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-purple-400" />
                <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-neutral-200">
                  Sub-Brood Receptive Nodes
                </h3>
              </div>
              <span className="text-xs font-mono text-purple-400">{state.hives.length} Colonies</span>
            </div>

            {state.hives.length === 0 ? (
              <div className="text-xs text-neutral-400 italic font-mono bg-neutral-950 p-4 rounded-xl border border-neutral-800">
                No autonomous colonies currently established. All directives execute directly through Swarm Vanguard.
              </div>
            ) : (
              <div className="space-y-2.5">
                {state.hives.map(h => (
                  <div
                    key={h.hiveId}
                    className="bg-neutral-950 p-3 rounded-xl border border-purple-900/30 space-y-1 text-xs font-mono"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-neutral-200">{h.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-900/60 text-purple-200">
                        {h.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-400 flex items-center justify-between">
                      <span>{h.ownedUnits.length} Units</span>
                      <span>{h.activeOrders.length} Active Directives</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 shadow-lg space-y-3">
            <div className="flex items-center gap-2 border-b border-neutral-800 pb-3">
              <Target className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-neutral-200">
                Active Tactical Squads ({state.teams.length})
              </h3>
            </div>
            <div className="space-y-2">
              {state.teams.map(t => (
                <div
                  key={t.teamId}
                  className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 text-xs font-mono space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-neutral-200 truncate">{t.name}</span>
                    <span className="text-[10px] text-amber-300 font-semibold">{t.status}</span>
                  </div>
                  <div className="text-[10px] text-neutral-500 italic truncate">"{t.directive}"</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};