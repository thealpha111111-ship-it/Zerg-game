/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState, NewsEntry } from '../types/game.ts';
import {
  Radio,
  Clock,
  Shield,
  Eye,
  Crown,
  Sparkles,
  Layers,
  Filter
} from 'lucide-react';

interface NewsPanelProps {
  state: GameState;
}

export const NewsPanel: React.FC<NewsPanelProps> = ({ state }) => {
  const [filter, setFilter] = useState<'ALL' | 'GLOBAL' | 'HIVE_QUEEN' | 'SWARM'>('ALL');

  const filteredNews = state.news.filter(n => {
    if (filter === 'ALL') return true;
    if (filter === 'GLOBAL') return n.visibility === 'GLOBAL';
    if (filter === 'HIVE_QUEEN') return n.sourceType === 'HIVE_QUEEN';
    if (filter === 'SWARM') return n.sourceType === 'SWARM' || n.sourceType === 'SYSTEM';
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
              Synaptic Intelligence Log
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              SECTION 12 BOUNDARIES
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Hive News & Intelligence</h1>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <Filter className="w-3.5 h-3.5 text-neutral-400" />
          {(['ALL', 'GLOBAL', 'HIVE_QUEEN', 'SWARM'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all ${
                filter === f
                  ? 'bg-purple-900/60 text-purple-200 border border-purple-600/50 font-bold'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
              }`}
            >
              {f === 'ALL' ? 'All Logs' : f === 'GLOBAL' ? 'Global' : f === 'HIVE_QUEEN' ? 'Queen Dispatches' : 'Swarm Core'}
            </button>
          ))}
        </div>
      </div>

      {/* News Feed */}
      <div className="space-y-4">
        {filteredNews.length === 0 ? (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-12 text-center text-neutral-400 text-xs font-mono">
            No intelligence logs matching active filter criteria.
          </div>
        ) : (
          filteredNews.map(item => (
            <div
              key={item.id}
              className="bg-neutral-900/80 border border-neutral-800/80 rounded-2xl p-5 shadow-lg space-y-2 hover:border-purple-900/50 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-purple-950/80 border border-purple-800/40 flex items-center justify-center">
                    {item.sourceType === 'HIVE_QUEEN' ? (
                      <Crown className="w-4 h-4 text-purple-400" />
                    ) : item.sourceType === 'SCOUT' ? (
                      <Eye className="w-4 h-4 text-amber-400" />
                    ) : (
                      <Radio className="w-4 h-4 text-emerald-400" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-neutral-100">{item.headline}</h3>
                    <span className="text-[10px] font-mono text-purple-400">
                      Source: {item.sourceType} • Turn {item.turn}
                    </span>
                  </div>
                </div>

                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-950 border border-neutral-800 text-neutral-400">
                  {item.visibility}
                </span>
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed font-mono bg-neutral-950/50 p-3 rounded-xl border border-neutral-800/50">
                {item.facts}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
