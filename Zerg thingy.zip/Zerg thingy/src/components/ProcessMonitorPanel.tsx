/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GameState, Process } from '../types/game.ts';
import {
  Layers,
  Clock,
  MapPin,
  Shield,
  Dna,
  Home,
  CheckCircle2,
  Flame,
  Bug
} from 'lucide-react';

interface ProcessMonitorPanelProps {
  state: GameState;
  onAdvanceTurn: () => void;
}

export const ProcessMonitorPanel: React.FC<ProcessMonitorPanelProps> = ({ state, onAdvanceTurn }) => {
  const activeProcesses = state.swarm.processes.filter(p => p.status === 'ACTIVE');
  const completedProcesses = state.swarm.processes.filter(p => p.status === 'COMPLETED');

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
              Timed Operations Engine
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              SECTION 6 & 13 CONTRACT
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Process Monitor</h1>
          <p className="text-xs text-neutral-400 mt-1">
            "What is happening right now?", "Who owns this?", "Where is it?", and "How many messages until it completes?"
          </p>
        </div>

        <button
          onClick={onAdvanceTurn}
          className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-mono text-xs font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md"
        >
          <Clock className="w-4 h-4" />
          <span>Advance Turn (+1 Message Progress)</span>
        </button>
      </div>

      {/* Active Processes Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-neutral-200 uppercase font-mono tracking-wider flex items-center gap-2">
            <Layers className="w-4 h-4 text-purple-400" />
            <span>Active Processes ({activeProcesses.length})</span>
          </h2>
        </div>

        {activeProcesses.length === 0 ? (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-10 text-center text-xs font-mono text-neutral-400">
            No active multi-message operations in progress.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeProcesses.map(proc => {
              const region = state.map.regions.find(r => r.id === proc.locationId);
              const pct = Math.round(
                ((proc.totalMessages - proc.remainingMessages) / proc.totalMessages) * 100
              );

              return (
                <div
                  key={proc.id}
                  className="bg-neutral-900/90 border border-purple-900/40 rounded-2xl p-5 shadow-lg space-y-4"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-bold">
                          {proc.type}
                        </span>
                        <span className="text-xs font-mono text-neutral-400">ID: {proc.id.slice(0, 16)}</span>
                      </div>
                      <h3 className="text-base font-bold text-white mt-1.5">{proc.name}</h3>
                    </div>

                    <div className="text-right font-mono">
                      <span className="text-xs font-bold text-purple-400">
                        {proc.remainingMessages} {proc.remainingMessages === 1 ? 'msg' : 'msgs'} left
                      </span>
                      <span className="text-[10px] text-neutral-500 block">Total: {proc.totalMessages}</span>
                    </div>
                  </div>

                  {/* 4 Answers Contract */}
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                    <div>
                      <span className="text-neutral-500 text-[10px] block">OWNER:</span>
                      <span className="text-neutral-200 font-semibold">{proc.ownerId}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 text-[10px] block">LOCATION:</span>
                      <span className="text-neutral-200 font-semibold truncate block">
                        {region ? region.name : proc.locationId || 'Central Spire'}
                      </span>
                    </div>
                    <div>
                      <span className="text-neutral-500 text-[10px] block">STARTED TURN:</span>
                      <span className="text-neutral-200 font-semibold">Turn {proc.startedTurn}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 text-[10px] block">COMPLETION HANDLER:</span>
                      <span className="text-purple-300 font-semibold truncate block">{proc.onComplete}</span>
                    </div>
                  </div>

                  {/* Reserved Costs */}
                  {proc.reservedCosts && (
                    <div className="flex items-center gap-4 text-xs font-mono text-neutral-400">
                      <span>Reserved:</span>
                      {proc.reservedCosts.biomass ? (
                        <span className="text-emerald-400 flex items-center gap-1">
                          <Flame className="w-3.5 h-3.5" /> {proc.reservedCosts.biomass} Biomass
                        </span>
                      ) : null}
                      {proc.reservedCosts.larvae ? (
                        <span className="text-amber-400 flex items-center gap-1">
                          <Bug className="w-3.5 h-3.5" /> {proc.reservedCosts.larvae} Larva
                        </span>
                      ) : null}
                    </div>
                  )}

                  {/* Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-mono text-neutral-400">
                      <span>Gestation Progress</span>
                      <span>{pct}%</span>
                    </div>
                    <div className="w-full bg-neutral-950 h-2 rounded-full overflow-hidden border border-neutral-800">
                      <div
                        className="bg-gradient-to-r from-purple-600 to-emerald-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Completed History */}
      {completedProcesses.length > 0 && (
        <div className="space-y-3 pt-6 border-t border-neutral-800">
          <h2 className="text-xs font-bold text-neutral-400 uppercase font-mono tracking-wider">
            Recently Resolved Operations ({completedProcesses.length})
          </h2>

          <div className="space-y-2">
            {completedProcesses.slice(-5).map(proc => (
              <div
                key={proc.id}
                className="bg-neutral-900/50 border border-neutral-800/80 rounded-xl p-3 flex items-center justify-between text-xs font-mono"
              >
                <div className="flex items-center gap-2 text-neutral-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold">{proc.name}</span>
                </div>
                <span className="text-neutral-500">Completed at remaining 0</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
