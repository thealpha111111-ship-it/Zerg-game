/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState, IndependentHive, HiveOrder } from '../types/game.ts';
import {
  Crown,
  Plus,
  Send,
  Shield,
  Activity,
  Flame,
  CheckCircle2,
  AlertTriangle,
  Compass,
  ArrowRight,
  Eye,
  Sliders,
  Radio
} from 'lucide-react';

interface IndependentHivesPanelProps {
  state: GameState;
  onCreateHive: (queenId: string, unitIds: string[], baseLocation: string, hiveName: string) => void;
  onSendDirective: (hiveId: string, text: string, objectiveType: any, targetLoc: string) => void;
  onUpdatePolicy: (hiveId: string, policy: { mayAttack: boolean; mayExpand: boolean; mayCreateTeams: boolean }) => void;
}

export const IndependentHivesPanel: React.FC<IndependentHivesPanelProps> = ({
  state,
  onCreateHive,
  onSendDirective,
  onUpdatePolicy
}) => {
  const [selectedHiveId, setSelectedHiveId] = useState<string>(
    state.hives[0]?.hiveId || ''
  );
  const [isFoundingOpen, setIsFoundingOpen] = useState(state.hives.length === 0);

  // Founding form state
  const availableQueens = state.swarm.units.filter(
    u => u.type === 'Hive Queen' && u.ownerId === 'swarm'
  );
  const [selectedQueenId, setSelectedQueenId] = useState<string>(availableQueens[0]?.id || '');
  const [selectedRegionId, setSelectedRegionId] = useState<string>('region-northern-chasm');
  const [selectedZerglingCount, setSelectedZerglingCount] = useState<number>(20);
  const [selectedRoachCount, setSelectedRoachCount] = useState<number>(5);
  const [hiveNameInput, setHiveNameInput] = useState<string>("Zagara's Hive");

  // Directive form state
  const [directiveText, setDirectiveText] = useState('');
  const [objectiveType, setObjectiveType] = useState<
    'HUNT' | 'ATTACK' | 'DEFEND' | 'EXPAND' | 'BUILD' | 'SCOUT' | 'PATROL' | 'GATHER'
  >('SCOUT');
  const [directiveTargetLoc, setDirectiveTargetLoc] = useState<string>('region-northern-chasm');

  const selectedHive = state.hives.find(h => h.hiveId === selectedHiveId) || state.hives[0];

  // Available Swarm counts for founding
  const availableZerglings = state.swarm.units.filter(u => u.type === 'Zerglings' && u.ownerId === 'swarm').length;
  const availableRoaches = state.swarm.units.filter(u => u.type === 'Roach' && u.ownerId === 'swarm').length;

  const handleLaunchFounding = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedQueenId) return;

    // Pick units
    const zIds = state.swarm.units
      .filter(u => u.type === 'Zerglings' && u.ownerId === 'swarm')
      .slice(0, selectedZerglingCount)
      .map(u => u.id);

    const rIds = state.swarm.units
      .filter(u => u.type === 'Roach' && u.ownerId === 'swarm')
      .slice(0, selectedRoachCount)
      .map(u => u.id);

    const assigned = [...zIds, ...rIds];
    onCreateHive(selectedQueenId, assigned, selectedRegionId, hiveNameInput || "Independent Hive");
    setIsFoundingOpen(false);
  };

  const handleDispatchDirective = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHive || !directiveText.trim()) return;
    onSendDirective(selectedHive.hiveId, directiveText.trim(), objectiveType, directiveTargetLoc);
    setDirectiveText('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
              Autonomous Sub-Broods
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              SECTION 7 & 8 CONTRACT
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Independent Hives</h1>
        </div>

        <button
          onClick={() => setIsFoundingOpen(!isFoundingOpen)}
          className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>{isFoundingOpen ? 'Close Founding Console' : 'Found New Independent Hive'}</span>
        </button>
      </div>

      {/* Founding Wizard Card */}
      {isFoundingOpen && (
        <form
          onSubmit={handleLaunchFounding}
          className="bg-neutral-900/90 border border-purple-800/60 rounded-2xl p-6 shadow-2xl space-y-5"
        >
          <div className="flex items-center justify-between border-b border-purple-900/40 pb-3">
            <div className="flex items-center gap-2">
              <Crown className="w-5 h-5 text-purple-400" />
              <h2 className="text-base font-bold text-white">Found Independent Colony (Section 7.1)</h2>
            </div>
            <span className="text-xs text-purple-400 font-mono">Atomic State Transfer</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Queen Selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono text-neutral-400">Hive Queen</label>
              {availableQueens.length === 0 ? (
                <div className="text-xs text-rose-400 bg-neutral-950 p-2.5 rounded-xl border border-rose-900/40">
                  No free Hive Queens in Swarm. Incubate one in Mutation Chamber first.
                </div>
              ) : (
                <select
                  value={selectedQueenId}
                  onChange={e => setSelectedQueenId(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-purple-500 font-mono"
                >
                  {availableQueens.map(q => (
                    <option key={q.id} value={q.id}>
                      {q.name} ({q.hp} HP)
                    </option>
                  ))}
                </select>
              )}
            </div>

            {/* Target Founding Region */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono text-neutral-400">Target Region</label>
              <select
                value={selectedRegionId}
                onChange={e => setSelectedRegionId(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-purple-500 font-mono"
              >
                {state.map.regions.map(r => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({r.biome})
                  </option>
                ))}
              </select>
            </div>

            {/* Assigned Units */}
            <div className="space-y-1.5">
              <label className="text-xs font-mono text-neutral-400">
                Assigned Zerglings (Max {availableZerglings})
              </label>
              <input
                type="number"
                min="0"
                max={availableZerglings}
                value={selectedZerglingCount}
                onChange={e => setSelectedZerglingCount(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-purple-500 font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono text-neutral-400">
                Assigned Roaches (Max {availableRoaches})
              </label>
              <input
                type="number"
                min="0"
                max={availableRoaches}
                value={selectedRoachCount}
                onChange={e => setSelectedRoachCount(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-purple-500 font-mono"
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
            <div className="w-full sm:w-80">
              <input
                type="text"
                value={hiveNameInput}
                onChange={e => setHiveNameInput(e.target.value)}
                placeholder="Colony Name (e.g. Zagara's Hive)"
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-purple-500"
              />
            </div>

            <button
              type="submit"
              disabled={availableQueens.length === 0}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 disabled:opacity-40 text-white text-xs font-mono font-bold flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <Send className="w-4 h-4" />
              <span>Sever Direct Neural Link & Found Colony</span>
            </button>
          </div>
        </form>
      )}

      {/* Main Colony Management Interface */}
      {state.hives.length === 0 ? (
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-12 text-center space-y-3">
          <Crown className="w-12 h-12 text-purple-600 mx-auto animate-pulse" />
          <h3 className="text-lg font-bold text-neutral-200">No Independent Hives Active</h3>
          <p className="text-xs text-neutral-400 max-w-md mx-auto">
            Use the Founding Console above or send a First Person command (e.g. "Zagara, take 20 zerglings and 5 roaches north and establish an independent hive.") to create autonomous colonies!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Hive Selector List */}
          <div className="space-y-3">
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 block px-1">
              Colonies ({state.hives.length})
            </span>
            {state.hives.map(hive => {
              const isSelected = hive.hiveId === selectedHive?.hiveId;
              return (
                <div
                  key={hive.hiveId}
                  onClick={() => setSelectedHiveId(hive.hiveId)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-purple-950/40 border-purple-500 shadow-md'
                      : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-2">
                      <Crown className="w-4 h-4 text-purple-400" />
                      {hive.name}
                    </h3>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        hive.status === 'ACTIVE'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                      }`}
                    >
                      {hive.status}
                    </span>
                  </div>

                  <div className="mt-3 flex items-center justify-between text-xs font-mono text-neutral-400">
                    <span>{hive.ownedUnits.length} Bio-Forms</span>
                    <span className="text-emerald-400 font-bold">{hive.biomass} Biomass</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Center + Right: Selected Colony Operations */}
          {selectedHive && (
            <div className="lg:col-span-2 space-y-6">
              {/* Colony Vital Statistics & Doctrine */}
              <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-5">
                <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
                  <div>
                    <span className="text-[10px] font-mono text-purple-400 uppercase tracking-wider">Autonomous Entity</span>
                    <h2 className="text-xl font-black text-white">{selectedHive.name}</h2>
                  </div>
                  <div className="text-right font-mono">
                    <span className="text-xs text-neutral-400 block">Tithe Rate</span>
                    <span className="text-sm font-bold text-emerald-400">30% to Sovereign</span>
                  </div>
                </div>

                {/* Sub-State Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
                  <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                    <span className="text-neutral-400 block text-[10px]">OWNED FORMS</span>
                    <span className="text-neutral-100 text-sm font-bold">{selectedHive.ownedUnits.length} Units</span>
                  </div>
                  <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                    <span className="text-neutral-400 block text-[10px]">BASE NETWORK</span>
                    <span className="text-neutral-100 text-sm font-bold">{selectedHive.ownedBases.length} Bases</span>
                  </div>
                  <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                    <span className="text-neutral-400 block text-[10px]">LOCAL BIOMASS</span>
                    <span className="text-emerald-400 text-sm font-bold">{selectedHive.biomass}</span>
                  </div>
                  <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                    <span className="text-neutral-400 block text-[10px]">HIVE LEVEL</span>
                    <span className="text-purple-300 text-sm font-bold">Tier {selectedHive.level}</span>
                  </div>
                </div>

                {/* Doctrine Permissions */}
                <div className="border-t border-neutral-800 pt-4 flex flex-wrap items-center justify-between gap-4">
                  <span className="text-xs font-mono text-neutral-400 flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-purple-400" /> Behavioral Permissions:
                  </span>
                  <div className="flex items-center gap-4 text-xs font-mono">
                    <label className="flex items-center gap-1.5 cursor-pointer text-neutral-300">
                      <input
                        type="checkbox"
                        checked={selectedHive.permissions.mayAttack}
                        onChange={e =>
                          onUpdatePolicy(selectedHive.hiveId, {
                            ...selectedHive.permissions,
                            mayAttack: e.target.checked
                          })
                        }
                        className="accent-purple-600 rounded"
                      />
                      <span>May Attack</span>
                    </label>

                    <label className="flex items-center gap-1.5 cursor-pointer text-neutral-300">
                      <input
                        type="checkbox"
                        checked={selectedHive.permissions.mayExpand}
                        onChange={e =>
                          onUpdatePolicy(selectedHive.hiveId, {
                            ...selectedHive.permissions,
                            mayExpand: e.target.checked
                          })
                        }
                        className="accent-purple-600 rounded"
                      />
                      <span>May Expand</span>
                    </label>

                    <label className="flex items-center gap-1.5 cursor-pointer text-neutral-300">
                      <input
                        type="checkbox"
                        checked={selectedHive.permissions.mayCreateTeams}
                        onChange={e =>
                          onUpdatePolicy(selectedHive.hiveId, {
                            ...selectedHive.permissions,
                            mayCreateTeams: e.target.checked
                          })
                        }
                        className="accent-purple-600 rounded"
                      />
                      <span>May Form Teams</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Directives Console (Section 8 Lifecycle) */}
              <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Radio className="w-4 h-4 text-purple-400" />
                    <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
                      Issue Synaptic Directive (Section 8 State Machine)
                    </h3>
                  </div>
                  <span className="text-xs font-mono text-purple-400">Anti-Stall Watchdog Active</span>
                </div>

                <form onSubmit={handleDispatchDirective} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-mono text-neutral-400 block mb-1">Objective Type</label>
                      <select
                        value={objectiveType}
                        onChange={e => setObjectiveType(e.target.value as any)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-mono text-neutral-200"
                      >
                        <option value="SCOUT">SCOUT: Recon sector perimeter</option>
                        <option value="HUNT">HUNT: Neutralize regional hostiles</option>
                        <option value="ATTACK">ATTACK: Assault designated strongpoint</option>
                        <option value="DEFEND">DEFEND: Establish fortified guard</option>
                        <option value="EXPAND">EXPAND: Seed auxiliary creep nodes</option>
                        <option value="GATHER">GATHER: Harvest mineral/biomass deposits</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-mono text-neutral-400 block mb-1">Target Sector</label>
                      <select
                        value={directiveTargetLoc}
                        onChange={e => setDirectiveTargetLoc(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-mono text-neutral-200"
                      >
                        {state.map.regions.map(r => (
                          <option key={r.id} value={r.id}>
                            {r.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={directiveText}
                      onChange={e => setDirectiveText(e.target.value)}
                      placeholder="Directive instruction (e.g. 'Scout the northern caldera and report threats')..."
                      className="flex-1 bg-neutral-950 border border-neutral-800 focus:border-purple-500 rounded-xl px-4 py-2.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none"
                    />
                    <button
                      type="submit"
                      disabled={!directiveText.trim() || selectedHive.status === 'FORMING'}
                      className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 disabled:opacity-40 text-white font-mono text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Transmit</span>
                    </button>
                  </div>
                </form>

                {/* Active Directives State Machine List */}
                <div className="space-y-3 pt-3">
                  <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider block">
                    Active Directives ({selectedHive.activeOrders.length})
                  </span>

                  {selectedHive.activeOrders.length === 0 ? (
                    <div className="text-xs text-neutral-400 italic bg-neutral-950 p-4 rounded-xl border border-neutral-800 font-mono">
                      No active directives. Queen is holding defensive station.
                    </div>
                  ) : (
                    selectedHive.activeOrders.map(order => {
                      const stages = ['RECEIVED', 'PLANNED', 'TEAM_FORMED', 'MOVING', 'ARRIVED', 'EXECUTING', 'VERIFYING', 'COMPLETED'];
                      const currentIdx = stages.indexOf(order.stage);

                      return (
                        <div
                          key={order.orderId}
                          className="bg-neutral-950 border border-purple-900/30 rounded-xl p-4 space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-neutral-200">{order.text}</span>
                            <span
                              className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                                order.status === 'BLOCKED'
                                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                  : 'bg-purple-950 text-purple-300 border border-purple-800'
                              }`}
                            >
                              {order.stage} ({order.status})
                            </span>
                          </div>

                          {/* Directive Stage Machine Bar */}
                          <div className="flex items-center gap-1 text-[9px] font-mono text-neutral-500 overflow-x-auto pb-1">
                            {stages.map((stg, idx) => (
                              <React.Fragment key={stg}>
                                <span
                                  className={`px-1.5 py-0.5 rounded whitespace-nowrap ${
                                    idx === currentIdx
                                      ? 'bg-purple-600 text-white font-bold animate-pulse'
                                      : idx < currentIdx
                                      ? 'bg-purple-950 text-purple-400'
                                      : 'bg-neutral-900 text-neutral-600'
                                  }`}
                                >
                                  {stg}
                                </span>
                                {idx < stages.length - 1 && <span>→</span>}
                              </React.Fragment>
                            ))}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
