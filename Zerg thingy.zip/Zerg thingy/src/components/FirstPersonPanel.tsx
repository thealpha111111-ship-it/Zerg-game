/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { GameState } from '../types/game.ts';
import {
  Send,
  Compass,
  MapPin,
  Bot,
  User,
  Sparkles,
  Footprints,
  Eye,
  MessageSquare,
  Shield,
  Dna,
  Bug,
  Crown
} from 'lucide-react';

interface FirstPersonPanelProps {
  state: GameState;
  onSendMessage: (msg: string) => void;
  onMovePlayer: (regionId: string) => void;
}

export const FirstPersonPanel: React.FC<FirstPersonPanelProps> = ({
  state,
  onSendMessage,
  onMovePlayer
}) => {
  const [inputText, setInputText] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const currentRegion = state.map.regions.find(r => r.id === state.player.locationId);
  const connectedRegions = state.map.regions.filter(r =>
    currentRegion?.connectedRegionIds.includes(r.id)
  );

  // Units physically in this room/chamber
  const unitsInRoom = state.swarm.units.filter(u => u.locationId === state.player.locationId);

  const firstPersonHistory = state.chatHistory.filter(
    c => c.mode === 'FIRST_PERSON' || !c.mode
  );

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [firstPersonHistory.length]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const samplePrompts = [
    'I walk through the eastern tunnel and ask the Queen what is happening.',
    'I enter the hatchery and ask the nearest queen whether the western scouting party returned.',
    'Zagara, take 20 zerglings and 5 roaches north and establish an independent hive.',
    'Status report on our biomass and larvae stores.'
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-120px)] max-w-6xl mx-auto px-4 py-4 gap-4">
      {/* Sensory Location Bar */}
      <div className="bg-neutral-900/80 border border-purple-900/40 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 shadow-md backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-purple-950 flex items-center justify-center border border-purple-700/50">
            <Compass className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-mono tracking-wider text-purple-400">Current Biological Chamber</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-900/40 text-purple-300 border border-purple-800/40 font-mono">
                {currentRegion?.biome}
              </span>
            </div>
            <h2 className="text-sm font-bold text-neutral-100 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-purple-400" />
              {currentRegion?.name}
            </h2>
          </div>
        </div>

        {/* Adjacent Passages */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-neutral-400 font-mono flex items-center gap-1">
            <Footprints className="w-3.5 h-3.5" /> Move to:
          </span>
          {connectedRegions.map(reg => (
            <button
              key={reg.id}
              onClick={() => onMovePlayer(reg.id)}
              className="px-2.5 py-1 text-xs font-mono rounded bg-neutral-800 hover:bg-purple-900/40 hover:text-purple-300 border border-neutral-700 hover:border-purple-600 transition-all cursor-pointer"
              title={`Traverse bio-tunnel to ${reg.name}`}
            >
              {reg.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content: Chat Window + In-Room Organisms */}
      <div className="flex-1 flex flex-col md:flex-row gap-4 min-h-0">
        {/* Dialogue Stream */}
        <div className="flex-1 bg-neutral-950/70 border border-neutral-800/80 rounded-2xl p-4 sm:p-6 overflow-y-auto space-y-4 shadow-inner">
          {firstPersonHistory.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 py-12">
              <MessageSquare className="w-12 h-12 text-purple-800 mb-3 animate-pulse" />
              <p className="text-base text-neutral-400 font-medium">The Organic Synapse is Silent</p>
              <p className="text-xs text-neutral-500 max-w-sm mt-1">
                Speak with the Queens, inspect biological chambers, or whisper commands across the psionic web.
              </p>
            </div>
          ) : (
            firstPersonHistory.map(item => (
              <div
                key={item.id}
                className={`flex flex-col gap-1.5 ${
                  item.sender === 'PLAYER' ? 'items-end' : 'items-start'
                }`}
              >
                <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-400 px-1">
                  {item.sender === 'PLAYER' ? (
                    <>
                      <span className="text-purple-300 font-bold uppercase">{state.player.role.replace('_', ' ')} (YOU)</span>
                      <User className="w-3.5 h-3.5 text-purple-400" />
                    </>
                  ) : (
                    <>
                      <Bot className="w-3.5 h-3.5 text-purple-400" />
                      <span className="text-purple-300 font-bold">QUEEN ZAGARA / NEURAL OVERMIND</span>
                    </>
                  )}
                  <span>•</span>
                  <span>Turn {item.turn}</span>
                </div>

                {/* Message Bubble */}
                <div
                  className={`max-w-2xl rounded-2xl px-4 py-3.5 text-sm leading-relaxed ${
                    item.sender === 'PLAYER'
                      ? 'bg-purple-900/40 border border-purple-600/40 text-purple-100 rounded-tr-sm'
                      : 'bg-neutral-900/90 border border-neutral-800 text-neutral-200 rounded-tl-sm shadow-md'
                  }`}
                >
                  {/* Rule: Show reply first! */}
                  <div className="whitespace-pre-wrap font-sans">{item.text}</div>

                  {/* Scene description */}
                  {item.scene && (
                    <div className="mt-3 pt-2.5 border-t border-purple-900/30 text-xs text-neutral-400 italic flex items-start gap-2">
                      <Eye className="w-4 h-4 text-purple-500 shrink-0 mt-0.5" />
                      <span>{item.scene}</span>
                    </div>
                  )}

                  {/* State changes badges */}
                  {item.metadata?.stateChanges && item.metadata.stateChanges.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-neutral-800 flex flex-wrap gap-1.5">
                      {item.metadata.stateChanges.map((sc: any, idx: number) => (
                        <span
                          key={idx}
                          className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/50"
                        >
                          ✦ {sc.description}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Right Drawer: Physical Inhabitants in Current Chamber */}
        <div className="hidden lg:flex w-72 flex-col bg-neutral-900/80 border border-neutral-800/80 rounded-2xl p-4 shadow-lg space-y-4">
          <div className="flex items-center gap-2 border-b border-neutral-800 pb-2.5">
            <Shield className="w-4 h-4 text-purple-400" />
            <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-neutral-200">
              Chamber Inhabitants ({unitsInRoom.length})
            </h3>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {unitsInRoom.slice(0, 10).map(u => (
              <div
                key={u.id}
                onClick={() => {
                  const query = u.type === 'Hive Queen'
                    ? `Speak with ${u.name} about expanding our hive territory.`
                    : u.type === 'Genarch'
                    ? `Consult Genarch ${u.name} regarding genetic enhancements.`
                    : `Examine the ${u.type} guarding this chamber.`;
                  setInputText(query);
                }}
                className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800/80 hover:border-purple-600/50 cursor-pointer transition-all space-y-1"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-neutral-200">{u.name}</span>
                  <span className="text-[10px] font-mono text-purple-400">{u.type}</span>
                </div>
                <div className="text-[10px] font-mono text-neutral-500 flex items-center justify-between">
                  <span>{u.hp} HP</span>
                  <span className="text-emerald-400">{u.status}</span>
                </div>
              </div>
            ))}
            {unitsInRoom.length > 10 && (
              <div className="text-[11px] text-neutral-500 font-mono text-center pt-1">
                + {unitsInRoom.length - 10} additional swarm organisms
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Suggested Quick Inquiries */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-[11px] font-mono text-neutral-400 shrink-0 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-purple-400" /> Prompts:
        </span>
        {samplePrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => {
              setInputText(p);
              onSendMessage(p);
            }}
            className="text-xs px-3 py-1 rounded-full bg-neutral-900/90 hover:bg-purple-950/80 text-neutral-300 hover:text-purple-200 border border-neutral-800 hover:border-purple-600/50 whitespace-nowrap transition-colors cursor-pointer"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Chat Input */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          placeholder="Speak or command in first person (e.g. 'I walk to the eastern ridge', 'Ask the Queen about the scouts')..."
          className="flex-1 bg-neutral-900/90 border border-neutral-800 focus:border-purple-500 rounded-xl px-4 py-3 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none transition-colors"
        />
        <button
          type="submit"
          disabled={!inputText.trim()}
          className="px-5 py-3 rounded-xl bg-purple-700 hover:bg-purple-600 disabled:opacity-50 disabled:hover:bg-purple-700 text-white font-medium flex items-center justify-center transition-all cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};