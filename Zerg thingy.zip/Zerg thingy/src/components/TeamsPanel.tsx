/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState, Team } from '../types/game.ts';
import {
  Shield,
  Plus,
  Compass,
  ArrowRight,
  Flame,
  Radio,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Send
} from 'lucide-react';

interface TeamsPanelProps {
  state: GameState;
  onCreateTeam: (ownerId: string, unitIds: string[], teamName: string, directive: string) => void;
  onProgramTeam: (teamId: string, directive: string, targetLocationId?: string) => void;
}

export const TeamsPanel: React.FC<TeamsPanelProps> = ({
  state,
  onCreateTeam,
  onProgramTeam
}) => {
  const [isCreating, setIsCreating] = useState(false);
  const [selectedTeamId, setSelectedTeamId] = useState<string>(state.teams[0]?.teamId || '');

  // Form state
  const [newTeamName, setNewTeamName] = useState("Swarm's Strike Claws");
  const [newTeamDirective, setNewTeamDirective] = useState("Scout outer biological ridge");
  const [selectedUnitIds, setSelectedUnitIds] = useState<string[]>([]);

  // Reprogram state
  const [programDirective, setProgramDirective] = useState('');
  const [programLocation, setProgramLocation] = useState('region-northern-chasm');

  const selectedTeam = state.teams.find(t => t.teamId === selectedTeamId) || state.teams[0];

  // Available idle swarm units
  const idleSwarmUnits = state.swarm.units.filter(
    u => u.ownerId === 'swarm' && (u.status === 'IDLE' || !u.teamId)
  );

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedUnitIds.length === 0) return;
    onCreateTeam('swarm', selectedUnitIds, newTeamName, newTeamDirective);
    setSelectedUnitIds([]);
    setIsCreating(false);
  };

  const handleProgramSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTeam || !programDirective.trim()) return;
    onProgramTeam(selectedTeam.teamId, programDirective.trim(), programLocation);
    setProgramDirective('');
  };

  const toggleSelectUnit = (id: string) => {
    if (selectedUnitIds.includes(id)) {
      setSelectedUnitIds(selectedUnitIds.filter(x => x !== id));
    } else {
      setSelectedUnitIds([...selectedUnitIds, id]);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
              Tactical Bio-Squads
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              SECTION 9 SPEC
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Teams & Taskforces</h1>
        </div>

        <button
          onClick={() => setIsCreating(!isCreating)}
          className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-mono font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md"
        >
          <Plus className="w-4 h-4" />
          <span>{isCreating ? 'Close Team Creator' : 'Form New Taskforce'}</span>
        </button>
      </div>

      {/* Creation Modal / Inline Form */}
      {isCreating && (
        <form
          onSubmit={handleCreateSubmit}
          className="bg-neutral-900/90 border border-purple-800/60 rounded-2xl p-6 shadow-2xl space-y-4"
        >
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-400" />
            <span>Assemble New Tactical Team</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-mono text-neutral-400 block mb-1">Squad Designation</label>
              <input
                type="text"
                value={newTeamName}
                onChange={e => setNewTeamName(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-purple-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs font-mono text-neutral-400 block mb-1">Initial Directive</label>
              <input
                type="text"
                value={newTeamDirective}
                onChange={e => setNewTeamDirective(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-purple-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-mono text-neutral-400 block mb-2">
              Select Organisms ({selectedUnitIds.length} selected of {idleSwarmUnits.length} idle):
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-48 overflow-y-auto p-1">
              {idleSwarmUnits.map(u => {
                const isSelected = selectedUnitIds.includes(u.id);
                return (
                  <button
                    type="button"
                    key={u.id}
                    onClick={() => toggleSelectUnit(u.id)}
                    className={`p-2 rounded-lg text-left text-xs font-mono border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-purple-900/70 border-purple-500 text-purple-100'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <div className="font-bold text-[11px] truncate">{u.name}</div>
                    <div className="text-[10px] text-neutral-500">{u.type}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={selectedUnitIds.length === 0}
              className="px-6 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 disabled:opacity-40 text-white font-mono text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Commission Team ({selectedUnitIds.length} units)</span>
            </button>
          </div>
        </form>
      )}

      {/* Teams Grid & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Teams List */}
        <div className="space-y-3">
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 block px-1">
            Active Taskforces ({state.teams.length})
          </span>

          {state.teams.map(team => {
            const isSwarmTeam = team.ownerId === 'swarm';
            const isSelected = team.teamId === selectedTeam?.teamId;

            return (
              <div
                key={team.teamId}
                onClick={() => setSelectedTeamId(team.teamId)}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-purple-950/40 border-purple-500 shadow-md'
                    : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-purple-400" />
                    {team.name}
                  </h3>
                  {/* Visual distinction rule (Section 9): Swarm's team vs Queen's team */}
                  <span
                    className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold ${
                      isSwarmTeam
                        ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                        : 'bg-purple-950/80 text-purple-300 border border-purple-800'
                    }`}
                  >
                    {isSwarmTeam ? "Swarm's team" : "Queen's team"}
                  </span>
                </div>

                <div className="mt-2 text-xs text-neutral-400 italic truncate">
                  "{team.directive}"
                </div>

                <div className="mt-3 flex items-center justify-between text-xs font-mono text-neutral-500">
                  <span>{team.unitIds.length} Organisms</span>
                  <span className="text-purple-300 font-semibold">{team.status}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Team Operations */}
        {selectedTeam && (
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-5">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-purple-400">Taskforce Overview</span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        selectedTeam.ownerId === 'swarm'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-purple-950 text-purple-300 border border-purple-800'
                      }`}
                    >
                      {selectedTeam.ownerId === 'swarm' ? "Swarm's team" : "Queen's team"}
                    </span>
                  </div>
                  <h2 className="text-xl font-black text-white mt-1">{selectedTeam.name}</h2>
                </div>

                <span className="text-xs font-mono px-3 py-1 rounded bg-neutral-950 border border-neutral-800 text-neutral-300 font-bold">
                  Status: {selectedTeam.status}
                </span>
              </div>

              {/* Directive Card */}
              <div className="bg-neutral-950 p-4 rounded-xl border border-purple-900/30 space-y-1">
                <span className="text-[10px] font-mono text-purple-400 uppercase tracking-wider">Current Synaptic Directive</span>
                <p className="text-sm text-neutral-200 font-medium">"{selectedTeam.directive}"</p>
                <div className="text-xs font-mono text-neutral-500 flex items-center gap-4 pt-1">
                  <span>Location: {selectedTeam.locationId}</span>
                  {selectedTeam.targetLocationId && (
                    <span className="text-purple-400">Target: {selectedTeam.targetLocationId}</span>
                  )}
                </div>
              </div>

              {/* Reprogram Team Directive */}
              <form onSubmit={handleProgramSubmit} className="space-y-3 pt-2">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 block">
                  Reprogram Directive
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <input
                      type="text"
                      value={programDirective}
                      onChange={e => setProgramDirective(e.target.value)}
                      placeholder="New orders (e.g. 'Attack enemy outpost at Sunken Expanse')..."
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <select
                      value={programLocation}
                      onChange={e => setProgramLocation(e.target.value)}
                      className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-mono text-neutral-200"
                    >
                      {state.map.regions.map(r => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={!programDirective.trim()}
                    className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 disabled:opacity-40 text-white font-mono text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Upload Directive</span>
                  </button>
                </div>
              </form>

              {/* Roster of Organisms */}
              <div className="space-y-2 pt-2">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 block">
                  Assigned Bio-Forms ({selectedTeam.unitIds.length})
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {selectedTeam.unitIds.map(uId => {
                    const unit = state.swarm.units.find(u => u.id === uId);
                    return (
                      <div
                        key={uId}
                        className="bg-neutral-950 p-2.5 rounded-lg border border-neutral-800 font-mono text-xs"
                      >
                        <div className="font-bold text-neutral-200 truncate">{unit?.name || uId}</div>
                        <div className="text-[10px] text-purple-400">{unit?.type || 'Organism'}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
