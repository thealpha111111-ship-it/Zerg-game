/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState, Region, MapObject } from '../types/game.ts';
import {
  MapPin,
  Compass,
  Home,
  Shield,
  Crown,
  FastForward,
  AlertTriangle,
  Flame,
  Radio
} from 'lucide-react';

interface TacticalMapPanelProps {
  state: GameState;
  onMovePlayer: (regionId: string) => void;
  onQuickFoundHive?: (regionId: string) => void;
}

export const TacticalMapPanel: React.FC<TacticalMapPanelProps> = ({
  state,
  onMovePlayer,
  onQuickFoundHive
}) => {
  const [selectedRegionId, setSelectedRegionId] = useState<string>(state.player.locationId);

  const selectedRegion = state.map.regions.find(r => r.id === selectedRegionId) || state.map.regions[0];
  const isPlayerHere = state.player.locationId === selectedRegion.id;

  // Find map objects in selected region
  const objectsInSelectedRegion = state.map.objects.filter(
    obj => obj.locationId === selectedRegion.id && obj.visible
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
              Tactical Bio-Grid
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              STABLE ENTITY IDS
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">Planetary Neural Topology</h1>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-purple-500 shadow-[0_0_8px_#a855f7]" />
            <span>Creep Sector</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
            <span>Sovereign (You)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
            <span>Active Base</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Tactical Map View */}
        <div className="lg:col-span-2 bg-neutral-950/90 border border-purple-950/80 rounded-2xl p-6 relative overflow-hidden shadow-2xl min-h-[480px] flex items-center justify-center">
          {/* Subtle Creep Background Web Texture */}
          <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#8b5cf6_1px,transparent_1px)] [background-size:24px_24px]" />

          {/* SVG Map Canvas */}
          <svg className="w-full h-full max-h-[480px] absolute inset-0" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* Connection Bio-Tendrils */}
            {state.map.regions.map(r1 =>
              r1.connectedRegionIds.map(cId => {
                const r2 = state.map.regions.find(r => r.id === cId);
                if (!r2 || r1.id > r2.id) return null; // draw each line once
                const hasCreepBoth = r1.hasCreep && r2.hasCreep;
                return (
                  <line
                    key={`${r1.id}-${r2.id}`}
                    x1={r1.x}
                    y1={r1.y}
                    x2={r2.x}
                    y2={r2.y}
                    stroke={hasCreepBoth ? '#7e22ce' : '#334155'}
                    strokeWidth={hasCreepBoth ? '1.2' : '0.6'}
                    strokeDasharray={hasCreepBoth ? undefined : '1, 1'}
                    className={hasCreepBoth ? 'animate-pulse' : ''}
                  />
                );
              })
            )}

            {/* Creep Radii Blotches */}
            {state.map.regions.map(r => {
              if (!r.hasCreep) return null;
              return (
                <circle
                  key={`creep-${r.id}`}
                  cx={r.x}
                  cy={r.y}
                  r="10"
                  fill="url(#creepGradient)"
                  opacity="0.3"
                  className="animate-pulse"
                />
              );
            })}

            <defs>
              <radialGradient id="creepGradient">
                <stop offset="0%" stopColor="#a855f7" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#581c87" stopOpacity="0" />
              </radialGradient>
            </defs>
          </svg>

          {/* Region Nodes */}
          {state.map.regions.map(r => {
            const isSelected = r.id === selectedRegionId;
            const hasPlayer = r.id === state.player.locationId;
            const baseObj = state.map.objects.find(o => o.locationId === r.id && o.kind === 'BASE');
            const hiveObj = state.map.objects.find(o => o.locationId === r.id && o.kind === 'HIVE');
            const teamObjs = state.map.objects.filter(o => o.locationId === r.id && o.kind === 'TEAM');

            return (
              <div
                key={r.id}
                onClick={() => setSelectedRegionId(r.id)}
                style={{ left: `${r.x}%`, top: `${r.y}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 z-10 flex flex-col items-center ${
                  isSelected ? 'scale-110' : 'hover:scale-105'
                }`}
              >
                {/* Node Ring */}
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg ${
                    hasPlayer
                      ? 'bg-amber-950/90 border-2 border-amber-400 shadow-[0_0_20px_#fbbf24]'
                      : hiveObj
                      ? 'bg-purple-950/90 border-2 border-purple-400 shadow-[0_0_15px_#a855f7]'
                      : baseObj
                      ? 'bg-emerald-950/90 border-2 border-emerald-500 shadow-[0_0_15px_#10b981]'
                      : 'bg-neutral-900/90 border border-neutral-700'
                  }`}
                >
                  {hasPlayer ? (
                    <Compass className="w-6 h-6 text-amber-300 animate-spin-slow" />
                  ) : hiveObj ? (
                    <Crown className="w-5 h-5 text-purple-300" />
                  ) : baseObj ? (
                    <Home className="w-5 h-5 text-emerald-300" />
                  ) : (
                    <Radio className="w-4 h-4 text-neutral-400" />
                  )}
                </div>

                {/* Region Label */}
                <span
                  className={`text-[11px] font-mono font-bold mt-1.5 px-2 py-0.5 rounded backdrop-blur whitespace-nowrap shadow ${
                    isSelected
                      ? 'bg-purple-900/90 text-purple-200 border border-purple-500'
                      : 'bg-neutral-950/80 text-neutral-300 border border-neutral-800'
                  }`}
                >
                  {r.name}
                </span>

                {/* Sub Badges for Objects */}
                <div className="flex gap-1 mt-0.5">
                  {hiveObj && (
                    <span className={`text-[9px] font-mono px-1 rounded ${hiveObj.status === 'FORMING' ? 'bg-amber-900 text-amber-200' : 'bg-purple-900 text-purple-200'}`}>
                      {hiveObj.status === 'FORMING' ? 'Forming Hive' : 'Active Hive'}
                    </span>
                  )}
                  {teamObjs.length > 0 && (
                    <span className="text-[9px] font-mono px-1 rounded bg-indigo-900 text-indigo-200">
                      {teamObjs.length} Team
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Region Tactical Inspector Sidebar */}
        <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 space-y-5 shadow-xl flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-purple-400 uppercase tracking-wider">Selected Sector</span>
                <h3 className="text-lg font-bold text-neutral-100 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-purple-400" />
                  {selectedRegion.name}
                </h3>
              </div>
              <span className="text-xs font-mono font-bold text-neutral-400 bg-neutral-950 px-2 py-1 rounded border border-neutral-800">
                ID: {selectedRegion.id}
              </span>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              {selectedRegion.description}
            </p>

            {/* Environmental Stats */}
            <div className="grid grid-cols-2 gap-3 pt-2 font-mono text-xs">
              <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-800">
                <span className="text-neutral-500 text-[10px] block">BIOME</span>
                <span className="text-neutral-200 font-medium">{selectedRegion.biome}</span>
              </div>

              <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-800">
                <span className="text-neutral-500 text-[10px] block">CREEP STATUS</span>
                <span className={selectedRegion.hasCreep ? 'text-purple-400 font-bold' : 'text-neutral-400'}>
                  {selectedRegion.hasCreep ? `${selectedRegion.creepLevel}% Creep` : 'Barren Rock'}
                </span>
              </div>

              <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-800">
                <span className="text-neutral-500 text-[10px] block">BIOMASS YIELD</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <Flame className="w-3 h-3" /> +{selectedRegion.biomassYield}
                </span>
              </div>

              <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-800">
                <span className="text-neutral-500 text-[10px] block">THREAT LEVEL</span>
                <span
                  className={`font-bold flex items-center gap-1 ${
                    selectedRegion.threatLevel === 'HIGH'
                      ? 'text-rose-400'
                      : selectedRegion.threatLevel === 'MEDIUM'
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  <AlertTriangle className="w-3 h-3" /> {selectedRegion.threatLevel}
                </span>
              </div>
            </div>

            {/* Tactical Objects Present */}
            <div className="space-y-2 pt-2">
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider block">
                Entities In Sector ({objectsInSelectedRegion.length})
              </span>
              {objectsInSelectedRegion.length === 0 ? (
                <div className="text-xs text-neutral-400 italic bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                  No active installations or squads in this sector.
                </div>
              ) : (
                <div className="space-y-2">
                  {objectsInSelectedRegion.map(obj => (
                    <div
                      key={obj.objectId}
                      className="bg-neutral-950 p-2.5 rounded-xl border border-purple-900/30 flex items-center justify-between text-xs font-mono"
                    >
                      <div className="flex items-center gap-2">
                        {obj.kind === 'BASE' ? (
                          <Home className="w-4 h-4 text-emerald-400" />
                        ) : obj.kind === 'HIVE' ? (
                          <Crown className="w-4 h-4 text-purple-400" />
                        ) : (
                          <Shield className="w-4 h-4 text-indigo-400" />
                        )}
                        <span className="text-neutral-200 font-semibold">{obj.label}</span>
                      </div>
                      <span className="text-[10px] text-purple-300 px-1.5 py-0.5 rounded bg-purple-950 border border-purple-800">
                        {obj.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Tactical Context Actions */}
          <div className="pt-4 border-t border-neutral-800 space-y-2">
            {!isPlayerHere ? (
              <button
                onClick={() => onMovePlayer(selectedRegion.id)}
                className="w-full py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-mono font-bold flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
              >
                <Compass className="w-4 h-4" />
                <span>Move Sovereign Here</span>
              </button>
            ) : (
              <div className="w-full py-2 rounded-xl bg-amber-950/40 border border-amber-800/40 text-amber-300 text-xs font-mono text-center">
                Sovereign Consciousness Located Here
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
