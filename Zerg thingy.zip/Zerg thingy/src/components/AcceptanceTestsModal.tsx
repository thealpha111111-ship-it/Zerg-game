/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TestResult, runAllAcceptanceTests } from '../simulation/acceptanceTests.ts';
import {
  CheckCircle2,
  XCircle,
  Play,
  RotateCcw,
  X,
  ShieldCheck,
  FileCode2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface AcceptanceTestsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tests: TestResult[];
  onRefreshTests: () => void;
}

export const AcceptanceTestsModal: React.FC<AcceptanceTestsModalProps> = ({
  isOpen,
  onClose,
  tests,
  onRefreshTests
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const passedCount = tests.filter(t => t.passed).length;
  const totalCount = tests.length;
  const allPassed = passedCount === totalCount && totalCount > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-neutral-900 border border-purple-800/80 rounded-2xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center border ${
              allPassed ? 'bg-emerald-950/80 border-emerald-600/50' : 'bg-purple-950/80 border-purple-600/50'
            }`}>
              <ShieldCheck className={`w-5 h-5 ${allPassed ? 'text-emerald-400' : 'text-purple-400'}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white font-mono">Mandatory Acceptance Tests</h2>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/50 font-mono">
                  SECTION 17 SPEC
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Authoritative verification of state mutations, process lifecycles, and First Person contracts.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onRefreshTests}
              className="px-3.5 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Run Suite</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Score Banner */}
        <div className="px-5 py-3 bg-neutral-950/50 border-b border-neutral-800/80 flex items-center justify-between font-mono text-xs">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Suite Status:</span>
            <span className={`font-bold ${allPassed ? 'text-emerald-400' : 'text-amber-400'}`}>
              {passedCount} / {totalCount} PASSED
            </span>
          </div>
          <div className="w-48 bg-neutral-800 h-2 rounded-full overflow-hidden">
            <div
              className={`h-2 rounded-full transition-all duration-500 ${
                allPassed ? 'bg-emerald-500' : 'bg-purple-500'
              }`}
              style={{ width: `${(passedCount / (totalCount || 1)) * 100}%` }}
            />
          </div>
        </div>

        {/* Tests List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-2.5">
          {tests.map(test => {
            const isExpanded = expandedId === test.id;
            return (
              <div
                key={test.id}
                className="bg-neutral-950/90 border border-neutral-800/80 rounded-xl overflow-hidden transition-colors hover:border-purple-900/40"
              >
                <div
                  onClick={() => setExpandedId(isExpanded ? null : test.id)}
                  className="p-3.5 flex items-center justify-between cursor-pointer select-none"
                >
                  <div className="flex items-center gap-3">
                    {test.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-500 shrink-0" />
                    )}
                    <div>
                      <span className="text-xs font-mono font-bold text-purple-400 mr-2">[{test.id}]</span>
                      <span className="text-xs font-semibold text-neutral-200">{test.name}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        test.passed
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {test.passed ? 'PASSED' : 'FAILED'}
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-neutral-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-neutral-500" />
                    )}
                  </div>
                </div>

                {isExpanded && (
                  <div className="p-4 pt-1 border-t border-neutral-800/60 bg-neutral-950 text-xs font-mono space-y-2">
                    <div>
                      <span className="text-neutral-500 text-[10px] block">EXPECTED:</span>
                      <span className="text-emerald-300">{test.expected}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 text-[10px] block">ACTUAL:</span>
                      <span className="text-neutral-200">{test.actual}</span>
                    </div>
                    <div>
                      <span className="text-neutral-500 text-[10px] block">SPEC VERIFICATION NOTE:</span>
                      <span className="text-neutral-400 italic">{test.details}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
