/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GameState, Mode, Unit } from '../types/game.ts';
import { calculateUsedSwarmUnitCap } from '../simulation/rulesEngine.ts';
import {
  Flame,
  Bug,
  Activity,
  Home,
  Crown,
  Layers,
  ArrowRight,
  Shield,
  Zap
} from 'lucide-react';

interface OverviewPanelProps {
  state: GameState;
  onNavigateMode: (mode: Mode) => void;
}

export const OverviewPanel: React.FC<OverviewPanelProps> = ({ state, onNavigateMode }) => {
  const activeProcesses = state.swarm.processes.filter(p => p.status === 'ACTIVE');
  const usedCap = calculateUsedSwarmUnitCap(state.swarm.units);

  // Group units by type
  const unitCounts: Record<string, { count: number; hp: number; consumesCap: boolean }> = {};
  state.swarm.units.forEach(u => {
    if (!unitCounts[u.type]) {
      unitCounts[u.type] = { count: 0, hp: u.maxHp, consumesCap: u.consumesCap };
    }
    unitCounts[u.type].count++;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Banner / Summary Card */}
      <div className="bg-gradient-to-r from-purple-950/60 via-neutral-900/80 to-neutral-950/90 border border-purple-800/40 rounded-2xl p-6 shadow-xl backdrop-blur">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
                Sovereign Consciousness Matrix
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/50 font-mono">
                SYNAPSE STABLE
              </span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1">Strategic Overview</h1>
            <p className="text-xs text-neutral-400 mt-1 max-w-xl">
              Turn {state.turn} • {state.swarm.units.length} total bio-forms under central command across {state.bases.length} bases.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigateMode('MUTATION')}
              className="px-4 py-2 rounded-xl bg-purple-700/80 hover:bg-purple-600 text-white text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <span>Incubate Organisms</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigateMode('HIVE_WINDOW')}
              className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-mono font-semibold flex items-center gap-2 transition-all cursor-pointer border border-neutral-700"
            >
              <span>Independent Hives</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Big Key Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-purple-900/30">
          <div className="bg-neutral-950/60 border border-neutral-800/80 rounded-xl p-3.5">
            <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
              <Flame className="w-4 h-4 text-emerald-400" />
              <span>Available Biomass</span>
            </div>
            <div className="text-xl font-bold font-mono text-emerald-300 mt-1">
              {state.swarm.biomass.toLocaleString()}
            </div>
            <div className="text-[11px] text-neutral-400 mt-0.5">+15 / turn harvest</div>
          </div>

          <div className="bg-neutral-950/60 border border-neutral-800/80 rounded-xl p-3.5">
            <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
              <Bug className="w-4 h-4 text-amber-400" />
              <span>Spire Larvae</span>
            </div>
            <div className="text-xl font-bold font-mono text-amber-300 mt-1">
              {state.swarm.larvae} <span className="text-xs text-neutral-500 font-normal">/ 8</span>
            </div>
            <div className="text-[11px] text-neutral-400 mt-0.5">+1 every 2 turns</div>
          </div>

          <div className="bg-neutral-950/60 border border-neutral-800/80 rounded-xl p-3.5">
            <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
              <Activity className="w-4 h-4 text-purple-400" />
              <span>Unit Capacity</span>
            </div>
            <div className="text-xl font-bold font-mono text-purple-300 mt-1">
              {usedCap} <span className="text-xs text-neutral-500 font-normal">/ {state.swarm.unitCap}</span>
            </div>
            <div className="text-[11px] text-neutral-400 mt-0.5">Base 30 + Overseers</div>
          </div>

          <div className="bg-neutral-950/60 border border-neutral-800/80 rounded-xl p-3.5">
            <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
              <Layers className="w-4 h-4 text-indigo-400" />
              <span>Active Gestations</span>
            </div>
            <div className="text-xl font-bold font-mono text-indigo-300 mt-1">
              {activeProcesses.length}
            </div>
            <div className="text-[11px] text-neutral-400 mt-0.5">In incubation vats</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Units Breakdown */}
        <div className="lg:col-span-2 space-y-6">
          {/* Swarm Units Catalog */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-neutral-100 uppercase tracking-wider font-mono">
                  Controlled Bio-Forms ({state.swarm.units.length})
                </h2>
              </div>
              <button
                onClick={() => onNavigateMode('MUTATION')}
                className="text-xs text-purple-400 hover:text-purple-300 font-mono flex items-center gap-1 cursor-pointer"
              >
                Breed more <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {Object.entries(unitCounts).map(([type, data]) => (
                <div
                  key={type}
                  className="bg-neutral-950/70 border border-neutral-800 rounded-xl p-3 flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between">
                    <span className="text-xs font-semibold text-neutral-200">{type}</span>
                    <span className="text-sm font-bold font-mono text-purple-300 bg-purple-950/70 px-2 py-0.5 rounded border border-purple-800/40">
                      {data.count}
                    </span>
                  </div>
                  <div className="mt-2 text-[10px] font-mono text-neutral-400 flex items-center justify-between">
                    <span>{data.hp} HP</span>
                    <span>{data.consumesCap ? '1 Cap' : 'Support (0 Cap)'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Active Gestations / Processes */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-neutral-100 uppercase tracking-wider font-mono">
                  Gestation Queue ({activeProcesses.length})
                </h2>
              </div>
              <button
                onClick={() => onNavigateMode('PROCESS_MONITOR')}
                className="text-xs text-purple-400 hover:text-purple-300 font-mono flex items-center gap-1 cursor-pointer"
              >
                Full Monitor <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {activeProcesses.length === 0 ? (
              <div className="text-center py-6 text-neutral-400 text-xs font-mono">
                Incubation vats are dormant. All genetic mutations completed.
              </div>
            ) : (
              <div className="space-y-3">
                {activeProcesses.map(proc => {
                  const pct = Math.round(
                    ((proc.totalMessages - proc.remainingMessages) / proc.totalMessages) * 100
                  );
                  return (
                    <div
                      key={proc.id}
                      className="bg-neutral-950/80 border border-purple-900/30 rounded-xl p-3.5 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-neutral-200">{proc.name}</span>
                        <span className="text-xs font-mono font-bold text-purple-400">
                          {proc.remainingMessages} {proc.remainingMessages === 1 ? 'message' : 'messages'} remaining
                        </span>
                      </div>
                      <div className="w-full bg-neutral-900 rounded-full h-2 overflow-hidden border border-neutral-800">
                        <div
                          className="bg-gradient-to-r from-purple-600 to-emerald-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Bases & Independent Hives */}
        <div className="space-y-6">
          {/* Bases Network */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Home className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-neutral-100 uppercase tracking-wider font-mono">
                  Base Network ({state.bases.length})
                </h2>
              </div>
            </div>

            <div className="space-y-3">
              {state.bases.map(base => {
                const region = state.map.regions.find(r => r.id === base.locationId);
                return (
                  <div
                    key={base.baseId}
                    className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-3 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-200">{base.name}</span>
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/40">
                        {base.type}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-400 flex items-center justify-between font-mono">
                      <span>Location: {region?.name || base.locationId}</span>
                      <span className="text-emerald-400">Creep {base.creepRadius}m</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Independent Hives Summary */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-neutral-100 uppercase tracking-wider font-mono">
                  Independent Hives ({state.hives.length})
                </h2>
              </div>
              <button
                onClick={() => onNavigateMode('HIVE_WINDOW')}
                className="text-xs text-purple-400 hover:text-purple-300 font-mono flex items-center gap-1 cursor-pointer"
              >
                Manage <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {state.hives.length === 0 ? (
              <div className="text-center py-6 text-neutral-400 text-xs font-mono">
                No independent hives established yet. Found a hive with a Queen to claim distant biomes!
              </div>
            ) : (
              <div className="space-y-3">
                {state.hives.map(hive => (
                  <div
                    key={hive.hiveId}
                    className="bg-neutral-950/80 border border-purple-900/30 rounded-xl p-3 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-200">{hive.name}</span>
                      <span
                        className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                          hive.status === 'ACTIVE'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                        }`}
                      >
                        {hive.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-400 flex items-center justify-between font-mono">
                      <span>Units: {hive.ownedUnits.length}</span>
                      <span>Biomass: {hive.biomass}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
