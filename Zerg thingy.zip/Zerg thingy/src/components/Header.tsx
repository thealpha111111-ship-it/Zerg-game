/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameState, Mode } from '../types/game.ts';
import { calculateUsedSwarmUnitCap } from '../simulation/rulesEngine.ts';
import { soundEngine } from '../simulation/soundEngine.ts';
import {
  Dna,
  FastForward,
  RotateCcw,
  CheckCircle2,
  Bug,
  Activity,
  Flame,
  Layers,
  Volume2,
  VolumeX,
  Globe2
} from 'lucide-react';

interface HeaderProps {
  state: GameState;
  activeMode: Mode;
  setActiveMode: (mode: Mode) => void;
  onAdvanceTurn: () => void;
  onReset: () => void;
  onOpenTests: () => void;
  passedTestsCount: number;
  totalTestsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  activeMode,
  setActiveMode,
  onAdvanceTurn,
  onReset,
  onOpenTests,
  passedTestsCount,
  totalTestsCount
}) => {
  const [soundOn, setSoundOn] = useState(false);
  const activeProcesses = state.swarm.processes.filter(p => p.status === 'ACTIVE');
  const usedCap = calculateUsedSwarmUnitCap(state.swarm.units);

  const toggleSound = () => {
    if (soundOn) {
      soundEngine.stopAmbiance();
      setSoundOn(false);
    } else {
      soundEngine.startAmbiance();
      setSoundOn(true);
    }
  };

  return (
    <header className="bg-neutral-950/90 border-b border-purple-900/40 backdrop-blur-md sticky top-0 z-40 select-none">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand & Turn */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-purple-950/80 border border-purple-600/50 shadow-[0_0_15px_rgba(168,85,247,0.3)]">
            <Dna className="w-6 h-6 text-purple-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-wider text-neutral-100 text-lg uppercase font-mono">
                The Swarm
              </span>
              <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-purple-900/60 text-purple-300 border border-purple-700/50">
                RP + RTS v2
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <span className="font-mono text-purple-400 font-semibold">TURN {state.turn}</span>
              <span>•</span>
              <span className="capitalize text-neutral-300 font-medium">
                {state.player.role.replace('_', ' ')}
              </span>
            </div>
          </div>
        </div>

        {/* Resources Metrics */}
        <div className="flex items-center gap-3 sm:gap-6 bg-neutral-900/90 border border-neutral-800 rounded-xl px-4 py-1.5 shadow-inner">
          {/* Biomass */}
          <div className="flex items-center gap-2" title="Swarm Biomass">
            <Flame className="w-4 h-4 text-emerald-400" />
            <div>
              <div className="text-[10px] text-neutral-400 font-mono uppercase tracking-wider">Biomass</div>
              <div className="text-sm font-bold font-mono text-emerald-300">
                {state.swarm.biomass.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="h-6 w-px bg-neutral-800" />

          {/* Larvae */}
          <div className="flex items-center gap-2" title="Central Spire Larvae">
            <Bug className="w-4 h-4 text-amber-400" />
            <div>
              <div className="text-[10px] text-neutral-400 font-mono uppercase tracking-wider">Larvae</div>
              <div className="text-sm font-bold font-mono text-amber-300">
                {state.swarm.larvae} <span className="text-xs text-neutral-500 font-normal">/ 8</span>
              </div>
            </div>
          </div>

          <div className="h-6 w-px bg-neutral-800" />

          {/* Unit Cap */}
          <div className="flex items-center gap-2" title="Unit Capacity">
            <Activity className="w-4 h-4 text-purple-400" />
            <div>
              <div className="text-[10px] text-neutral-400 font-mono uppercase tracking-wider">Unit Cap</div>
              <div className="text-sm font-bold font-mono text-purple-300">
                {usedCap} <span className="text-xs text-neutral-500 font-normal">/ {state.swarm.unitCap}</span>
              </div>
            </div>
          </div>

          {activeProcesses.length > 0 && (
            <>
              <div className="h-6 w-px bg-neutral-800 hidden md:block" />
              <div
                className="hidden md:flex items-center gap-2 text-xs font-mono text-purple-300 bg-purple-950/60 px-2.5 py-1 rounded-lg border border-purple-800/40 animate-pulse cursor-pointer"
                onClick={() => setActiveMode('PROCESS_MONITOR')}
              >
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                <span>{activeProcesses.length} Gestating</span>
              </div>
            </>
          )}
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-2">
          {/* Audio Ambiance Toggle */}
          <button
            onClick={toggleSound}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              soundOn
                ? 'bg-purple-900/60 border-purple-600 text-purple-200'
                : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
            }`}
            title={soundOn ? 'Disable Swarm Ambiance' : 'Enable Swarm Bio-Ambiance'}
          >
            {soundOn ? <Volume2 className="w-4 h-4 text-purple-400 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Acceptance Tests Button */}
          <button
            onClick={onOpenTests}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-lg bg-neutral-900 border border-neutral-700 hover:border-purple-500 text-neutral-200 transition-all shadow-sm hover:shadow-purple-500/20 cursor-pointer"
            title="Run Mandatory Spec Acceptance Tests (Section 15, 16, 17)"
          >
            <CheckCircle2 className={`w-3.5 h-3.5 ${passedTestsCount === totalTestsCount ? 'text-emerald-400' : 'text-amber-400'}`} />
            <span className="hidden sm:inline">Tests:</span>
            <span className="font-bold text-purple-300">{passedTestsCount}/{totalTestsCount}</span>
          </button>

          {/* Advance Turn Button */}
          <button
            onClick={onAdvanceTurn}
            className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-mono font-bold rounded-lg bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white shadow-[0_0_15px_rgba(147,51,234,0.3)] hover:shadow-[0_0_20px_rgba(147,51,234,0.5)] transition-all cursor-pointer active:scale-95"
            title="Advance 1 simulation turn (+1 message / progress step)"
          >
            <FastForward className="w-4 h-4" />
            <span>Next Turn</span>
          </button>

          {/* Reset */}
          <button
            onClick={onReset}
            className="p-1.5 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60 rounded-lg transition-colors cursor-pointer"
            title="Reset GameState to initial seed"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mode Navigation Bar */}
      <div className="border-t border-neutral-800/80 bg-neutral-950/70">
        <div className="max-w-7xl mx-auto px-4 flex items-center overflow-x-auto scrollbar-none gap-1 py-1 text-xs font-mono">
          <NavTab label="First Person RP" mode="FIRST_PERSON" current={activeMode} onClick={() => setActiveMode('FIRST_PERSON')} />
          <NavTab label="Strategic Overview" mode="OVERVIEW" current={activeMode} onClick={() => setActiveMode('OVERVIEW')} />
          <NavTab label="Global Command" mode="GLOBAL_COMMAND" current={activeMode} onClick={() => setActiveMode('GLOBAL_COMMAND')} />
          <NavTab label="Tactical Map" mode="MAP" current={activeMode} onClick={() => setActiveMode('MAP')} />
          <NavTab
            label="Mutation Chamber"
            mode="MUTATION"
            current={activeMode}
            onClick={() => setActiveMode('MUTATION')}
            badge={state.swarm.larvae > 0 ? `${state.swarm.larvae} Larvae` : undefined}
          />
          <NavTab
            label="Independent Hives"
            mode="HIVE_WINDOW"
            current={activeMode}
            onClick={() => setActiveMode('HIVE_WINDOW')}
            badge={state.hives.length > 0 ? `${state.hives.length}` : undefined}
          />
          <NavTab
            label="Teams & Taskforces"
            mode="TEAM_WINDOW"
            current={activeMode}
            onClick={() => setActiveMode('TEAM_WINDOW')}
            badge={`${state.teams.length}`}
          />
          <NavTab
            label="Hive News"
            mode="NEWS"
            current={activeMode}
            onClick={() => setActiveMode('NEWS')}
            badge={state.news.length > 0 ? `${state.news.length}` : undefined}
          />
          <NavTab
            label="Process Engine"
            mode="PROCESS_MONITOR"
            current={activeMode}
            onClick={() => setActiveMode('PROCESS_MONITOR')}
            badge={activeProcesses.length > 0 ? `${activeProcesses.length}` : undefined}
          />
        </div>
      </div>
    </header>
  );
};

interface NavTabProps {
  label: string;
  mode: Mode;
  current: Mode;
  onClick: () => void;
  badge?: string;
}

const NavTab: React.FC<NavTabProps> = ({ label, mode, current, onClick, badge }) => {
  const isActive = current === mode;
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-md flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer font-medium ${
        isActive
          ? 'bg-purple-900/50 text-purple-200 border border-purple-500/40 shadow-sm'
          : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
      }`}
    >
      <span>{label}</span>
      {badge && (
        <span
          className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
            isActive ? 'bg-purple-600 text-white' : 'bg-neutral-800 text-neutral-300'
          }`}
        >
          {badge}
        </span>
      )}
    </button>
  );
};