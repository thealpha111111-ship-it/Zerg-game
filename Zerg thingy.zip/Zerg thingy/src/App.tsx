/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameState, Mode, UnitType, StructureType } from './types/game.ts';
import { loadGameState, saveGameState, resetGameState, dispatchTurn } from './simulation/gameEngine.ts';
import { runAllAcceptanceTests, TestResult } from './simulation/acceptanceTests.ts';
import { Header } from './components/Header.tsx';
import { FirstPersonPanel } from './components/FirstPersonPanel.tsx';
import { OverviewPanel } from './components/OverviewPanel.tsx';
import { TacticalMapPanel } from './components/TacticalMapPanel.tsx';
import { MutationPanel } from './components/MutationPanel.tsx';
import { IndependentHivesPanel } from './components/IndependentHivesPanel.tsx';
import { TeamsPanel } from './components/TeamsPanel.tsx';
import { NewsPanel } from './components/NewsPanel.tsx';
import { ProcessMonitorPanel } from './components/ProcessMonitorPanel.tsx';
import { AcceptanceTestsModal } from './components/AcceptanceTestsModal.tsx';

export default function App() {
  const [state, setState] = useState<GameState>(() => loadGameState());
  const [activeMode, setActiveMode] = useState<Mode>('FIRST_PERSON');
  const [isTestsModalOpen, setIsTestsModalOpen] = useState(false);
  const [testResults, setTestResults] = useState<TestResult[]>(() => runAllAcceptanceTests());
  const [toastMessage, setToastMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  useEffect(() => {
    // Run tests on mount
    const results = runAllAcceptanceTests();
    setTestResults(results);
  }, []);

  const showToast = (text: string, isError = false) => {
    setToastMessage({ text, isError });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleAdvanceTurn = () => {
    const res = dispatchTurn(state, 'advance turn', activeMode, {
      type: 'ADVANCE_TURN',
      payload: {}
    });
    setState(res.state);
    showToast(`Turn ${res.state.turn} commenced.`);
  };

  const handleSendMessage = (msg: string) => {
    const res = dispatchTurn(state, msg, activeMode);
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    }
  };

  const handleMovePlayer = (regionId: string) => {
    const res = dispatchTurn(state, '', activeMode, {
      type: 'MOVE_PLAYER',
      payload: { destinationId: regionId }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      const reg = res.state.map.regions.find(r => r.id === regionId);
      showToast(`Consciousness relocated to ${reg?.name || regionId}`);
    }
  };

  const handleMutateUnit = (unitType: UnitType) => {
    const res = dispatchTurn(state, '', 'MUTATION', {
      type: 'MUTATE_UNIT',
      payload: { unitType, ownerId: 'swarm' }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      showToast(`Incubation started: ${unitType}`);
    }
  };

  const handleMutateStructure = (targetStructure: StructureType) => {
    const res = dispatchTurn(state, '', 'MUTATION', {
      type: 'MUTATE_STRUCTURE',
      payload: {
        baseId: state.bases[0]?.baseId || 'base-central-spire',
        targetStructure
      }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      showToast(`Base evolution initiated: ${targetStructure}`);
    }
  };

  const handleCreateHive = (queenId: string, unitIds: string[], baseLocation: string, hiveName: string) => {
    const res = dispatchTurn(state, '', 'HIVE_WINDOW', {
      type: 'CREATE_INDEPENDENT_HIVE',
      payload: {
        queenUnitId: queenId,
        assignedUnitIds: unitIds,
        baseLocation,
        hiveName
      }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      showToast(`Colony founded: ${hiveName} (FORMING)`);
    }
  };

  const handleSendDirective = (hiveId: string, text: string, objectiveType: any, targetLoc: string) => {
    const res = dispatchTurn(state, '', 'HIVE_WINDOW', {
      type: 'SEND_HIVE_DIRECTIVE',
      payload: {
        hiveId,
        orderText: text,
        objectiveType,
        targetLocationId: targetLoc
      }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      showToast(`Directive transmitted to sub-brood.`);
    }
  };

  const handleUpdatePolicy = (hiveId: string, policy: { mayAttack: boolean; mayExpand: boolean; mayCreateTeams: boolean }) => {
    const res = dispatchTurn(state, '', 'HIVE_WINDOW', {
      type: 'SET_HIVE_POLICY',
      payload: { hiveId, policy }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      showToast(`Colony doctrine updated.`);
    }
  };

  const handleCreateTeam = (ownerId: string, unitIds: string[], teamName: string, directive: string) => {
    const res = dispatchTurn(state, '', 'TEAM_WINDOW', {
      type: 'CREATE_TEAM',
      payload: {
        ownerId,
        unitIds,
        teamName,
        directive
      }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      showToast(`Team ${teamName} commissioned.`);
    }
  };

  const handleProgramTeam = (teamId: string, directive: string, targetLoc?: string) => {
    const res = dispatchTurn(state, '', 'TEAM_WINDOW', {
      type: 'PROGRAM_TEAM',
      payload: {
        teamId,
        directive,
        targetLocationId: targetLoc
      }
    });
    setState(res.state);
    if (!res.result.ok) {
      showToast(res.result.message, true);
    } else {
      showToast(`Taskforce orders updated.`);
    }
  };

  const handleResetSimulation = () => {
    if (window.confirm('Reset the Swarm simulation to canonical Turn 1 state?')) {
      const fresh = resetGameState();
      setState(fresh);
      const results = runAllAcceptanceTests();
      setTestResults(results);
      showToast('Simulation reset to Turn 1.');
    }
  };

  const handleRefreshTests = () => {
    const results = runAllAcceptanceTests();
    setTestResults(results);
    showToast(`Ran 16 Acceptance Tests (${results.filter(r => r.passed).length}/16 Passed)`);
  };

  const passedTestsCount = testResults.filter(t => t.passed).length;

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-purple-800 selection:text-white">
      {/* Tactical Header */}
      <Header
        state={state}
        activeMode={activeMode}
        setActiveMode={setActiveMode}
        onAdvanceTurn={handleAdvanceTurn}
        onReset={handleResetSimulation}
        onOpenTests={() => setIsTestsModalOpen(true)}
        passedTestsCount={passedTestsCount}
        totalTestsCount={testResults.length}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-12">
        {activeMode === 'FIRST_PERSON' && (
          <FirstPersonPanel
            state={state}
            onSendMessage={handleSendMessage}
            onMovePlayer={handleMovePlayer}
          />
        )}

        {activeMode === 'OVERVIEW' && (
          <OverviewPanel
            state={state}
            onNavigateMode={setActiveMode}
          />
        )}

        {activeMode === 'MAP' && (
          <TacticalMapPanel
            state={state}
            onMovePlayer={handleMovePlayer}
          />
        )}

        {activeMode === 'MUTATION' && (
          <MutationPanel
            state={state}
            onMutateUnit={handleMutateUnit}
            onMutateStructure={handleMutateStructure}
          />
        )}

        {activeMode === 'HIVE_WINDOW' && (
          <IndependentHivesPanel
            state={state}
            onCreateHive={handleCreateHive}
            onSendDirective={handleSendDirective}
            onUpdatePolicy={handleUpdatePolicy}
          />
        )}

        {activeMode === 'TEAM_WINDOW' && (
          <TeamsPanel
            state={state}
            onCreateTeam={handleCreateTeam}
            onProgramTeam={handleProgramTeam}
          />
        )}

        {activeMode === 'NEWS' && (
          <NewsPanel
            state={state}
          />
        )}

        {activeMode === 'PROCESS_MONITOR' && (
          <ProcessMonitorPanel
            state={state}
            onAdvanceTurn={handleAdvanceTurn}
          />
        )}
      </main>

      {/* Acceptance Tests Modal */}
      <AcceptanceTestsModal
        isOpen={isTestsModalOpen}
        onClose={() => setIsTestsModalOpen(false)}
        tests={testResults}
        onRefreshTests={handleRefreshTests}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl border text-xs font-mono shadow-2xl flex items-center gap-2 animate-bounce-subtle backdrop-blur ${
            toastMessage.isError
              ? 'bg-rose-950/90 border-rose-800 text-rose-200'
              : 'bg-purple-950/90 border-purple-800 text-purple-200'
          }`}
        >
          <span>{toastMessage.text}</span>
        </div>
      )}
    </div>
  );
}
