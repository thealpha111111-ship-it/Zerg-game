/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GameState, Unit, Base, Team, Region, MapObject, NewsEntry } from '../../types/game.ts';

export function createInitialGameState(): GameState {
  const units: Unit[] = [];

  // 1 Hive Queen (Zagara) for testing independent hive expansion
  units.push({
    id: 'unit-queen-zagara',
    type: 'Hive Queen',
    name: 'Zagara',
    ownerId: 'swarm',
    locationId: 'region-central-spire',
    teamId: null,
    status: 'IDLE',
    hp: 450,
    maxHp: 450,
    attack: 35,
    consumesCap: true,
    providesCap: 0
  });

  // 1 Genarch
  units.push({
    id: 'unit-genarch-otheus',
    type: 'Genarch',
    name: 'Genarch Otheus',
    ownerId: 'swarm',
    locationId: 'region-central-spire',
    teamId: null,
    status: 'IDLE',
    hp: 600,
    maxHp: 600,
    attack: 15,
    consumesCap: true,
    providesCap: 0
  });

  // 1 Overseer (Support unit: adds +6 cap, consumes 0 cap!)
  units.push({
    id: 'unit-overseer-1',
    type: 'Overseer',
    name: 'Overseer Gaze-01',
    ownerId: 'swarm',
    locationId: 'region-central-spire',
    teamId: null,
    status: 'IDLE',
    hp: 200,
    maxHp: 200,
    attack: 0,
    consumesCap: false,
    providesCap: 6
  });

  // 20 Zerglings
  for (let i = 1; i <= 20; i++) {
    units.push({
      id: `unit-zergling-${i}`,
      type: 'Zerglings',
      name: `Zergling ${i < 10 ? '0' + i : i}`,
      ownerId: 'swarm',
      locationId: 'region-central-spire',
      teamId: null,
      status: 'IDLE',
      hp: 35,
      maxHp: 35,
      attack: 10,
      consumesCap: true,
      providesCap: 0
    });
  }

  // 5 Roaches
  for (let i = 1; i <= 5; i++) {
    units.push({
      id: `unit-roach-${i}`,
      type: 'Roach',
      name: `Roach 0${i}`,
      ownerId: 'swarm',
      locationId: 'region-central-spire',
      teamId: null,
      status: 'IDLE',
      hp: 145,
      maxHp: 145,
      attack: 18,
      consumesCap: true,
      providesCap: 0
    });
  }

  // 2 Mutators
  for (let i = 1; i <= 2; i++) {
    units.push({
      id: `unit-mutator-${i}`,
      type: 'Mutator',
      name: `Mutator 0${i}`,
      ownerId: 'swarm',
      locationId: 'region-central-spire',
      teamId: null,
      status: 'IDLE',
      hp: 60,
      maxHp: 60,
      attack: 5,
      consumesCap: true,
      providesCap: 0
    });
  }

  const initialBase: Base = {
    baseId: 'base-central-spire',
    name: 'Central Hatchery Spire',
    ownerId: 'swarm',
    type: 'HATCHERY',
    locationId: 'region-central-spire',
    structureIds: ['struct-hatchery-primary'],
    unitIds: units.map(u => u.id),
    queenId: 'unit-queen-zagara',
    activeOrders: [],
    status: 'ACTIVE',
    creepRadius: 100,
    larvaeAvailable: 4,
    maxLarvae: 6
  };

  const initialTeam: Team = {
    teamId: 'team-swarm-recon-alpha',
    ownerId: 'swarm',
    name: "Swarm's Vanguard Alpha",
    unitIds: ['unit-zergling-1', 'unit-zergling-2', 'unit-zergling-3', 'unit-zergling-4'],
    homeBaseId: 'base-central-spire',
    locationId: 'region-central-spire',
    directive: 'Patrol biological creep perimeter',
    status: 'IDLE',
    targetId: null,
    targetLocationId: null,
    path: [],
    progress: 100,
    sourceOrderId: null
  };

  // Mark those 4 zerglings as in-team
  units.forEach(u => {
    if (initialTeam.unitIds.includes(u.id)) {
      u.teamId = initialTeam.teamId;
      u.status = 'IN_TEAM';
    }
  });

  const regions: Region[] = [
    {
      id: 'region-central-spire',
      name: 'Central Hatchery Spire',
      x: 48,
      y: 48,
      biome: 'Spawning Pools & Creep Heart',
      description: 'The beating nexus of our superorganism. Vats of living biomass pulse with raw instinct.',
      hasCreep: true,
      creepLevel: 100,
      connectedRegionIds: ['region-northern-chasm', 'region-eastern-ridge', 'region-acid-trench'],
      biomassYield: 30,
      threatLevel: 'NONE',
      discovered: true
    },
    {
      id: 'region-northern-chasm',
      name: 'Northern Chasm',
      x: 48,
      y: 18,
      biome: 'Basalt Caldera & Mineral Rifts',
      description: 'Rugged volcanic fault lines rich in dormant nutrient sediment. Prime soil for independent hive expansion.',
      hasCreep: false,
      creepLevel: 0,
      connectedRegionIds: ['region-central-spire', 'region-sunken-expanse'],
      biomassYield: 120,
      threatLevel: 'LOW',
      discovered: true
    },
    {
      id: 'region-eastern-ridge',
      name: 'Eastern Creep Ridge',
      x: 78,
      y: 48,
      biome: 'Calcified Bio-Cliffs',
      description: 'Sprawling bone-coral formations. Creep extends across the lower ledges. Deep echo of distant wildlife.',
      hasCreep: true,
      creepLevel: 55,
      connectedRegionIds: ['region-central-spire', 'region-sunken-expanse'],
      biomassYield: 75,
      threatLevel: 'LOW',
      discovered: true
    },
    {
      id: 'region-acid-trench',
      name: 'Acid Trench',
      x: 48,
      y: 80,
      biome: 'Corrosive Geysers & Sulphur Bogs',
      description: 'Boiling green pools of digestive enzymes. Dangerous to unprotected strains, highly nutritious if conquered.',
      hasCreep: false,
      creepLevel: 0,
      connectedRegionIds: ['region-central-spire', 'region-spawning-caverns'],
      biomassYield: 95,
      threatLevel: 'MEDIUM',
      discovered: true
    },
    {
      id: 'region-spawning-caverns',
      name: 'Spawning Caverns',
      x: 20,
      y: 75,
      biome: 'Deep Subterranean Vats',
      description: 'Moist subterranean tunnels lined with bioluminescent tendrils and dormant egg nests.',
      hasCreep: true,
      creepLevel: 80,
      connectedRegionIds: ['region-acid-trench', 'region-central-spire'],
      biomassYield: 60,
      threatLevel: 'NONE',
      discovered: true
    },
    {
      id: 'region-sunken-expanse',
      name: 'Sunken Expanse',
      x: 82,
      y: 18,
      biome: 'Terran Bunker Ruins & Scrap Fields',
      description: 'Derelict steel barricades and hostile mercenary scavengers. Massive biological scrap yield.',
      hasCreep: false,
      creepLevel: 0,
      connectedRegionIds: ['region-northern-chasm', 'region-eastern-ridge'],
      biomassYield: 240,
      threatLevel: 'HIGH',
      discovered: false
    }
  ];

  const mapObjects: MapObject[] = [
    {
      objectId: 'obj-base-central-spire',
      kind: 'BASE',
      sourceEntityId: initialBase.baseId,
      locationId: 'region-central-spire',
      ownerId: 'swarm',
      status: 'ACTIVE',
      visible: true,
      label: 'Central Hatchery'
    },
    {
      objectId: 'obj-team-swarm-alpha',
      kind: 'TEAM',
      sourceEntityId: initialTeam.teamId,
      locationId: 'region-central-spire',
      ownerId: 'swarm',
      status: 'IDLE',
      visible: true,
      label: "Swarm's Vanguard Alpha"
    }
  ];

  const news: NewsEntry[] = [
    {
      id: 'news-init-1',
      sourceId: 'system',
      sourceType: 'SYSTEM',
      turn: 1,
      visibility: 'GLOBAL',
      headline: 'The Swarm Awakens',
      facts: 'The Great Consciousness stirs at Central Spire. Larvae are ready for mutation. 29 organisms await orders.',
      timestamp: Date.now() - 10000
    }
  ];

  // Base unit cap = 20 + 1 Overseer (+6) = 26
  // Controlled units consuming cap = 20 zerglings + 5 roaches + 2 mutators + 1 Queen + 1 Genarch = 29
  // Note: 29/26 allows testing cap warnings, or cap can be 32 (20 base + 2 Overseers). Let's give base cap 30 + 6 = 36 so 29/36 is clean!
  const baseCap = 30;
  const extraCap = units.reduce((sum, u) => sum + (u.providesCap || 0), 0);

  return {
    turn: 1,
    player: {
      role: 'swarm_king',
      locationId: 'region-central-spire'
    },
    swarm: {
      biomass: 850,
      larvae: 4,
      unitCap: baseCap + extraCap,
      units,
      bases: [initialBase.baseId],
      teams: [initialTeam.teamId],
      processes: []
    },
    hives: [],
    bases: [initialBase],
    teams: [initialTeam],
    map: {
      regions,
      objects: mapObjects
    },
    news,
    settings: {
      autoAdvanceNews: true,
      soundAmbiance: true
    },
    log: [
      {
        id: 'log-0',
        turn: 1,
        commandType: 'INITIALIZE',
        summary: 'Swarm consciousness initialized with 850 Biomass and 4 Larvae.',
        before: {},
        after: { biomass: 850, larvae: 4, units: units.length },
        timestamp: Date.now()
      }
    ],
    chatHistory: [
      {
        id: 'chat-welcome-1',
        turn: 1,
        mode: 'FIRST_PERSON',
        sender: 'ASSISTANT',
        text: 'The wet walls of the Central Spire shudder as your consciousness floods the organic matrix. Queen Zagara lowers her cephalic plate in reverent greeting.',
        scene: 'Central Hatchery Spire. Bio-luminescent spores drift lazily over the warm amber incubation vats. The Song of the Overmind resonates in your marrow.',
        locationId: 'region-central-spire',
        timestamp: Date.now()
      }
    ]
  };
}
