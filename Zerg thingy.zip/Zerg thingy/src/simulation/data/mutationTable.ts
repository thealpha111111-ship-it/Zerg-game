/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { UnitType, StructureType } from '../../types/game.ts';

export interface MutationRule {
  id: UnitType | StructureType;
  category: 'UNIT' | 'STRUCTURE' | 'UPGRADE';
  name: string;
  biomassCost: number;
  larvaCost: number;
  turnsRequired: number; // in messages/turns
  requiresStructure?: StructureType[];
  requiresUnit?: UnitType[];
  requiresGenarch?: boolean;
  requiresCreep?: boolean;
  requiresMutator?: boolean;
  isSupportUnit?: boolean; // If true, does not consume unit capacity
  addsCapacity?: number; // Overseer & Seer add +6 cap
  producesCount?: number; // Zerglings: 1 larva creates 2 units
  consumesUnitType?: UnitType; // Seer consumes 1 Overseer
  description: string;
  combatRole: string;
}

export const MUTATION_RULES: Record<string, MutationRule> = {
  Hatchery: {
    id: 'Hatchery',
    category: 'STRUCTURE',
    name: 'Hatchery',
    biomassCost: 100,
    larvaCost: 0,
    turnsRequired: 4,
    description: 'Foundation base; spreads bio-creep and incubates larvae.',
    combatRole: 'Foundation'
  },
  Lair: {
    id: 'Lair',
    category: 'STRUCTURE',
    name: 'Lair',
    biomassCost: 50,
    larvaCost: 0,
    turnsRequired: 3,
    requiresStructure: ['Hatchery'],
    description: 'Upgrades Hatchery; expands tactical command and neural depth.',
    combatRole: 'Advanced Base'
  },
  Hive: {
    id: 'Hive',
    category: 'STRUCTURE',
    name: 'Hive',
    biomassCost: 250,
    larvaCost: 0,
    turnsRequired: 3,
    requiresStructure: ['Lair'],
    requiresUnit: ['Hive Queen'],
    description: 'Pinnacle biological node; requires 1 free Hive Queen.',
    combatRole: 'Apex Base'
  },
  'Swarm Citadel': {
    id: 'Swarm Citadel',
    category: 'STRUCTURE',
    name: 'Swarm Citadel',
    biomassCost: 700,
    larvaCost: 0,
    turnsRequired: 10,
    requiresStructure: ['Hive'],
    description: 'Imposing throne of the Swarm Sovereign. Dominates planetary bio-signature.',
    combatRole: 'Sovereign Fortress'
  },
  'Creep Tumor': {
    id: 'Creep Tumor',
    category: 'STRUCTURE',
    name: 'Creep Tumor',
    biomassCost: 0,
    larvaCost: 0,
    turnsRequired: 1,
    requiresUnit: ['Hive Queen'],
    requiresCreep: true,
    description: 'Hive Queen only; extends biological creep coverage across the sector.',
    combatRole: 'Creep Spreader'
  },
  'Spore Crawler': {
    id: 'Spore Crawler',
    category: 'STRUCTURE',
    name: 'Spore Crawler',
    biomassCost: 25,
    larvaCost: 0,
    turnsRequired: 2,
    requiresMutator: true,
    requiresCreep: true,
    description: 'Spits corrosive bio-spores at aerial intruders.',
    combatRole: 'Anti-Air Defense'
  },
  'Spine Crawler': {
    id: 'Spine Crawler',
    category: 'STRUCTURE',
    name: 'Spine Crawler',
    biomassCost: 25,
    larvaCost: 0,
    turnsRequired: 2,
    requiresMutator: true,
    requiresCreep: true,
    description: 'Chitin-reinforced burrowing tentacle that impales ground enemies.',
    combatRole: 'Anti-Ground Defense'
  },
  'Nydus Network': {
    id: 'Nydus Network',
    category: 'STRUCTURE',
    name: 'Nydus Network',
    biomassCost: 300,
    larvaCost: 0,
    turnsRequired: 5,
    requiresMutator: true,
    requiresCreep: true,
    description: 'Subterranean transit canal enabling instantaneous worm tunnels across sectors.',
    combatRole: 'Logistics / Transit'
  },
  'Nydus Worm': {
    id: 'Nydus Worm',
    category: 'STRUCTURE',
    name: 'Nydus Worm',
    biomassCost: 100,
    larvaCost: 0,
    turnsRequired: 2,
    requiresStructure: ['Nydus Network'],
    description: 'Canal exit worm erupting from the earth to deliver swarms instantaneously.',
    combatRole: 'Canal Maw'
  },
  Burrower: {
    id: 'Burrower',
    category: 'UNIT',
    name: 'Burrower',
    biomassCost: 20,
    larvaCost: 1,
    turnsRequired: 2,
    description: 'Subterranean scout and trap specialist with tremor sense.',
    combatRole: 'Subsurface Infiltrator'
  },
  Carrier: {
    id: 'Carrier',
    category: 'UNIT',
    name: 'Carrier',
    biomassCost: 20,
    larvaCost: 1,
    turnsRequired: 3,
    description: 'Heavy bio-carapace beast designed to transport biomass & organs.',
    combatRole: 'Logistics Hauler'
  },
  Mutator: {
    id: 'Mutator',
    category: 'UNIT',
    name: 'Mutator',
    biomassCost: 20,
    larvaCost: 1,
    turnsRequired: 2,
    description: 'Organic builder organism capable of transforming into defensive creep structures.',
    combatRole: 'Bio-Architect'
  },
  Zerglings: {
    id: 'Zerglings',
    category: 'UNIT',
    name: 'Zerglings',
    biomassCost: 15,
    larvaCost: 1,
    turnsRequired: 1,
    producesCount: 2, // 1 larva -> 2 zerglings
    description: 'Voracious light swarming beasts. 1 larva yields a deadly pair.',
    combatRole: 'Light Swarm Melee'
  },
  Roach: {
    id: 'Roach',
    category: 'UNIT',
    name: 'Roach',
    biomassCost: 40,
    larvaCost: 1,
    turnsRequired: 3,
    description: 'Regenerative armored assault organism spitting acid saliva.',
    combatRole: 'Armored Vanguard'
  },
  Hydralisk: {
    id: 'Hydralisk',
    category: 'UNIT',
    name: 'Hydralisk',
    biomassCost: 75,
    larvaCost: 1,
    turnsRequired: 4,
    requiresGenarch: true,
    description: 'Deadly ranged predator launching piercing grooved chitin spines.',
    combatRole: 'Medium Ranged Assault'
  },
  Leaper: {
    id: 'Leaper',
    category: 'UNIT',
    name: 'Leaper',
    biomassCost: 35,
    larvaCost: 1,
    turnsRequired: 2,
    description: 'High-agility flanker leaping across cliffs and defensive perimeter lines.',
    combatRole: 'Agile Flanker'
  },
  'Acid Spitter': {
    id: 'Acid Spitter',
    category: 'UNIT',
    name: 'Acid Spitter',
    biomassCost: 120,
    larvaCost: 1,
    turnsRequired: 4,
    requiresGenarch: true,
    description: 'Siege organism that hurls volatile bioplasm dissolving enemy bunkers.',
    combatRole: 'Heavy Siege Artillery'
  },
  Overseer: {
    id: 'Overseer',
    category: 'UNIT',
    name: 'Overseer',
    biomassCost: 75,
    larvaCost: 1,
    turnsRequired: 3,
    isSupportUnit: true, // Does not consume unit cap!
    addsCapacity: 6, // Adds +6 cap!
    description: 'Floating sensory bio-balloon. Expands neural capacity by +6 without taking cap.',
    combatRole: 'Overlord & Cap Expander'
  },
  Seer: {
    id: 'Seer',
    category: 'UNIT',
    name: 'Seer',
    biomassCost: 50,
    larvaCost: 1,
    turnsRequired: 2,
    requiresGenarch: true,
    consumesUnitType: 'Overseer', // Replaces/removes an Overseer
    isSupportUnit: true,
    addsCapacity: 6, // Maintains +6 cap
    description: 'Ascended ocular mutant. Detects cloaked infiltrators and uncovers distant fog.',
    combatRole: 'True Sight Recon'
  },
  'Swarm Claws': {
    id: 'Swarm Claws',
    category: 'UNIT',
    name: 'Swarm Claws',
    biomassCost: 200,
    larvaCost: 1,
    turnsRequired: 6,
    requiresGenarch: true,
    description: 'Monstrous close-combat shredders with razor-honed bone blades.',
    combatRole: 'Apex Shock Trooper'
  },
  "Queen's Guard": {
    id: 'Queen\'s Guard',
    category: 'UNIT',
    name: 'Queen\'s Guard',
    biomassCost: 200,
    larvaCost: 1,
    turnsRequired: 7,
    requiresGenarch: true,
    description: 'Elite royal bio-sentinel bred exclusively to sacrifice for the Queen.',
    combatRole: 'Honor Shield'
  },
  Ultralisk: {
    id: 'Ultralisk',
    category: 'UNIT',
    name: 'Ultralisk',
    biomassCost: 400,
    larvaCost: 1,
    turnsRequired: 7,
    description: 'Colossal biological behemoth armed with scissor-like Kaiser blades.',
    combatRole: 'Massive Juggernaut'
  },
  'Hive Queen': {
    id: 'Hive Queen',
    category: 'UNIT',
    name: 'Hive Queen',
    biomassCost: 450,
    larvaCost: 1,
    turnsRequired: 8,
    description: 'Sentient brood matriarch. Can establish and govern independent hives.',
    combatRole: 'Command & Expansion'
  },
  Genarch: {
    id: 'Genarch',
    category: 'UNIT',
    name: 'Genarch',
    biomassCost: 900,
    larvaCost: 1,
    turnsRequired: 12,
    description: 'Living biological repository of apex genetic strands. Unlocks tier 3 mutations.',
    combatRole: 'Genetic Catalyst'
  },
  'Swarm King / Queen': {
    id: 'Swarm King / Queen',
    category: 'UNIT',
    name: 'Swarm King / Queen',
    biomassCost: 5000,
    larvaCost: 1,
    turnsRequired: 20,
    requiresGenarch: true,
    description: 'The Absolute Sovereign of the Overmind. Complete psionic telepathy over all broods.',
    combatRole: 'Overmind Deity'
  }
};
