/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from '@google/genai';
import { GameState, Mode, Command, Result, Process, FirstPersonResponse } from '../types/game.ts';

function getApiKey(): string {
  try {
    if (typeof process !== 'undefined' && process.env && process.env.GEMINI_API_KEY) {
      return process.env.GEMINI_API_KEY;
    }
    if (typeof window !== 'undefined' && (window as any).GEMINI_API_KEY) {
      return (window as any).GEMINI_API_KEY;
    }
  } catch {
    // Ignore
  }
  return '';
}

/**
 * Uses Gemini 2.5 Flash to classify and parameterize free-form player natural language into a typed Command.
 * Returns null if no API key is configured or on failure, cleanly falling back to the local parser.
 */
export async function parseCommandWithAI(
  message: string,
  state: GameState,
  activeMode: Mode
): Promise<Command | null> {
  const apiKey = getApiKey();
  if (!apiKey || !message || message.trim().length === 0) return null;

  try {
    const ai = new GoogleGenAI({ apiKey });
    const prompt = `
You are the natural-language command classifier for "The Swarm", an RTS + Roleplay biological simulation.
Classify the following player message into EXACTLY one of these typed commands:
- MOVE_PLAYER (destinationId: string)
- TALK (targetId: string, message: string)
- MUTATE_UNIT (unitType: string, ownerId: "swarm")
- MUTATE_STRUCTURE (baseId: string, targetStructure: string)
- BUILD_HATCHERY (regionId: string)
- CREATE_INDEPENDENT_HIVE (queenUnitId: string, assignedUnitIds: string[], baseLocation: string, hiveName: string)
- SEND_HIVE_DIRECTIVE (hiveId: string, orderText: string, objectiveType: "HUNT"|"ATTACK"|"DEFEND"|"EXPAND"|"BUILD"|"SCOUT"|"PATROL"|"GATHER", targetLocationId: string)
- CREATE_TEAM (ownerId: "swarm", unitIds: string[], teamName: string, directive: string)
- PROGRAM_TEAM (teamId: string, directive: string, targetLocationId?: string)
- CREATE_NYDUS (sourceBaseId: string, destination: string)
- ADVANCE_TURN ()

Context:
- Player current location: ${state.player.locationId}
- Map Regions: ${JSON.stringify(state.map.regions.map(r => ({ id: r.id, name: r.name })))}
- Swarm Units: ${state.swarm.units.length} total. Hive Queens: ${state.swarm.units.filter(u => u.type === 'Hive Queen').map(u => ({ id: u.id, name: u.name })).map(u => u.name).join(', ') || 'None'}
- Hives: ${state.hives.map(h => ({ id: h.hiveId, name: h.name })).map(h => `${h.name} (${h.hiveId})`).join(', ') || 'None'}
- Active Mode: ${activeMode}

Player Message: "${message}"

Output ONLY a raw JSON object matching the Command format, with fields:
{
  "type": "...",
  "payload": { ... }
}
Do not write markdown backticks or explanations.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const text = response.text?.trim() || '';
    const cleanJson = text.replace(/^```json/i, '').replace(/^```/, '').replace(/```$/, '').trim();
    const parsed = JSON.parse(cleanJson);
    if (parsed && parsed.type && parsed.payload) {
      return {
        type: parsed.type,
        payload: parsed.payload,
        rawMessage: message
      };
    }
  } catch {
    // Graceful fallback to deterministic parser
  }
  return null;
}

/**
 * Uses Gemini to enrich the narrative prose in First Person mode while strictly obeying Section 4.1 & 14.
 */
export async function narrateWithAI(
  mode: Mode,
  state: GameState,
  command: Command,
  result: Result<GameState>,
  completedProcesses: Process[]
): Promise<{ text: string; firstPerson?: FirstPersonResponse } | null> {
  const apiKey = getApiKey();
  if (!apiKey || mode !== 'FIRST_PERSON') return null;

  try {
    const ai = new GoogleGenAI({ apiKey });
    const currentRegion = state.map.regions.find(r => r.id === state.player.locationId);

    const prompt = `
You are Queen Zagara and the Neural Mind of The Swarm, an alien biological superorganism.
Generate the narrative response to the Sovereign's action.

Rules from Section 4.1 & 14:
- Show reply first. Show scene description only when useful.
- MUST NOT contain status dashboards (NO "BIOMASS: 800", NO "LARVAE: 4", NO unit cap tables) unless the player explicitly asked for resources.
- Speak with fierce biological devotion ("My Sovereign", "Our broods", "synapses").
- Keep responses focused, vivid, and grounded in the current chamber.

Current State:
- Sovereign Location: ${currentRegion?.name} (${currentRegion?.biome})
- Player Input: "${command.rawMessage || ''}"
- Command Executed: ${command.type} (Result: ${result.ok ? 'SUCCESS' : 'FAILED: ' + (result as any).message})
- Completed gestations: ${completedProcesses.map(p => p.name).join(', ') || 'None'}

Return ONLY a raw JSON object with this shape:
{
  "speaker": "Queen Zagara",
  "reply": "Your in-character spoken words here...",
  "scene": "A brief 1-2 sentence sensory description of the organic chamber, or null"
}
Do not write markdown formatting.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const text = response.text?.trim() || '';
    const cleanJson = text.replace(/^```json/i, '').replace(/^```/, '').replace(/```$/, '').trim();
    const parsed = JSON.parse(cleanJson);

    if (parsed && parsed.reply) {
      const stateChanges = (result.events || []).map(e => ({
        type: e.type,
        description: e.message,
        entityId: e.entityId
      }));

      return {
        text: parsed.reply,
        firstPerson: {
          mode: 'FIRST_PERSON',
          speaker: parsed.speaker || 'Queen Zagara',
          reply: parsed.reply,
          scene: parsed.scene || null,
          playerLocationId: state.player.locationId,
          stateChanges
        }
      };
    }
  } catch {
    // Graceful fallback to deterministic narrator
  }
  return null;
}