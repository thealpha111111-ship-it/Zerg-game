/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  GameState,
  Command,
  Result,
  StateEvent,
  Unit,
  Base,
  Team,
  Process,
  IndependentHive,
  HiveOrder,
  MapObject,
  NewsEntry,
  StateTransition,
  UnitType,
  StructureType
} from '../types/game.ts';
import { MUTATION_RULES } from './data/mutationTable.ts';

/**
 * Calculates current unit capacity for the Swarm.
 * Base cap: 30. Each Overseer provides +6, each Seer provides +6.
 */
export function calculateSwarmUnitCap(swarmUnits: Unit[]): number {
  const baseCap = 30;
  const supportBonus = swarmUnits
    .filter(u => u.ownerId === 'swarm')
    .reduce((sum, u) => sum + (u.providesCap || 0), 0);
  return baseCap + supportBonus;
}

/**
 * Calculates number of units currently consuming capacity in the Swarm.
 */
export function calculateUsedSwarmUnitCap(swarmUnits: Unit[]): number {
  return swarmUnits.filter(u => u.ownerId === 'swarm' && u.consumesCap).length;
}

/**
 * Invariant Checker
 * Enforces all Section 3.1 & Section 11 & 18 rules.
 */
export function validateInvariants(state: GameState): { valid: boolean; error?: string } {
  // 1. No resource may become negative
  if (state.swarm.biomass < 0) return { valid: false, error: 'Invariant violated: Biomass cannot be negative' };
  if (state.swarm.larvae < 0) return { valid: false, error: 'Invariant violated: Larvae count cannot be negative' };

  for (const hive of state.hives) {
    if (hive.biomass < 0) return { valid: false, error: `Invariant violated: Hive ${hive.name} biomass negative` };
  }

  // 2. A unit can belong to exactly one owner and exactly one location
  const seenUnits = new Set<string>();
  for (const u of state.swarm.units) {
    if (seenUnits.has(u.id)) return { valid: false, error: `Invariant violated: Duplicate unit ${u.id}` };
    seenUnits.add(u.id);
    if (!u.ownerId) return { valid: false, error: `Unit ${u.id} has no owner` };
    if (!u.locationId) return { valid: false, error: `Unit ${u.id} has no location` };
  }

  // 3. A base belongs either to Swarm or exactly one hive
  for (const b of state.bases) {
    if (b.ownerId !== 'swarm' && !state.hives.some(h => h.hiveId === b.ownerId)) {
      return { valid: false, error: `Base ${b.baseId} has orphan owner ${b.ownerId}` };
    }
  }

  // 4. Units transferred to an independent hive must NOT be in Swarm list
  for (const hive of state.hives) {
    for (const uId of hive.ownedUnits) {
      if (state.swarm.units.some(u => u.id === uId && u.ownerId === 'swarm')) {
        return { valid: false, error: `Unit ${uId} is owned by hive ${hive.hiveId} but still marked swarm-owned` };
      }
    }
  }

  // 5. Player location is always a valid map region
  const regionIds = new Set(state.map.regions.map(r => r.id));
  if (!regionIds.has(state.player.locationId)) {
    return { valid: false, error: `Player location ${state.player.locationId} is not a valid region` };
  }

  return { valid: true };
}

/**
 * Pure-ish function: Applies a typed command to GameState and returns Result<GameState>
 */
export function applyCommand(state: GameState, command: Command): Result<GameState> {
  const events: StateEvent[] = [];
  const turn = state.turn;
  const prevStateSnap = {
    biomass: state.swarm.biomass,
    larvae: state.swarm.larvae,
    unitsCount: state.swarm.units.length,
    hivesCount: state.hives.length,
    processesCount: state.swarm.processes.length
  };

  switch (command.type) {
    case 'MOVE_PLAYER': {
      const destinationId = command.payload.destinationId;
      const targetRegion = state.map.regions.find(r => r.id === destinationId);
      if (!targetRegion) {
        return { ok: false, code: 'INVALID_DESTINATION', message: `Destination region "${destinationId}" does not exist.`, state };
      }

      const currentRegion = state.map.regions.find(r => r.id === state.player.locationId);
      if (currentRegion && !currentRegion.connectedRegionIds.includes(destinationId) && currentRegion.id !== destinationId) {
        return {
          ok: false,
          code: 'UNREACHABLE_DESTINATION',
          message: `Cannot move directly from ${currentRegion.name} to ${targetRegion.name}. No biological passage exists.`,
          state
        };
      }

      const newState: GameState = {
        ...state,
        player: {
          ...state.player,
          locationId: destinationId
        }
      };

      events.push({
        type: 'PLAYER_MOVED',
        message: `Sovereign relocated consciousness to ${targetRegion.name}.`,
        entityId: destinationId,
        data: { from: state.player.locationId, to: destinationId }
      });

      return auditAndReturn(newState, 'MOVE_PLAYER', `Player moved to ${targetRegion.name}`, prevStateSnap, events);
    }

    case 'TALK': {
      // Direct conversation. Does not mutate RTS state unless an action was requested.
      const { targetId, message } = command.payload;
      return {
        ok: true,
        state,
        events: [{ type: 'TALK_EXCHANGED', message: `Spoke with ${targetId || 'Swarm organism'}` }]
      };
    }

    case 'MUTATE_UNIT': {
      const { unitType, ownerId = 'swarm', sourceLarvaId } = command.payload as {
        unitType: UnitType;
        ownerId?: string;
        sourceLarvaId?: string;
      };

      const rule = MUTATION_RULES[unitType];
      if (!rule) {
        return { ok: false, code: 'UNKNOWN_MUTATION', message: `Unknown unit mutation type: "${unitType}".`, state };
      }

      // Check biomass
      if (state.swarm.biomass < rule.biomassCost) {
        return {
          ok: false,
          code: 'INSUFFICIENT_BIOMASS',
          message: `Requires ${rule.biomassCost} Biomass, but the Swarm only possesses ${state.swarm.biomass}.`,
          state
        };
      }

      // Check larvae
      if (rule.larvaCost > 0 && state.swarm.larvae < rule.larvaCost) {
        return {
          ok: false,
          code: 'INSUFFICIENT_LARVAE',
          message: `Requires ${rule.larvaCost} Larva, but 0 are currently gestating in Central Spire.`,
          state
        };
      }

      // Check Genarch requirement
      if (rule.requiresGenarch) {
        const hasGenarch = state.swarm.units.some(u => u.type === 'Genarch' && u.ownerId === 'swarm');
        if (!hasGenarch) {
          return {
            ok: false,
            code: 'REQUIRES_GENARCH',
            message: `Mutating ${unitType} requires an active Genarch in the Swarm to synthesize apex genetic sequences.`,
            state
          };
        }
      }

      // Check specific unit consumption (e.g. Seer replaces Overseer)
      let consumedUnit: Unit | undefined;
      if (rule.consumesUnitType) {
        consumedUnit = state.swarm.units.find(u => u.type === rule.consumesUnitType && u.ownerId === 'swarm' && u.status === 'IDLE');
        if (!consumedUnit) {
          return {
            ok: false,
            code: 'MISSING_SOURCE_UNIT',
            message: `Mutating ${unitType} requires an idle ${rule.consumesUnitType} to undergo physical metamorphosis.`,
            state
          };
        }
      }

      // Create Process
      const processId = `proc-mutate-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const newProcess: Process = {
        id: processId,
        type: 'MUTATE_UNIT',
        name: `Gestating ${unitType}`,
        ownerId,
        targetId: null,
        locationId: state.player.locationId,
        startedTurn: state.turn,
        remainingMessages: rule.turnsRequired,
        totalMessages: rule.turnsRequired,
        reservedCosts: {
          biomass: rule.biomassCost,
          larvae: rule.larvaCost,
          unitIds: consumedUnit ? [consumedUnit.id] : []
        },
        status: 'ACTIVE',
        onComplete: 'RESOLVE_MUTATE_UNIT',
        completionData: {
          unitType,
          ownerId,
          producesCount: rule.producesCount || 1,
          consumedUnitId: consumedUnit?.id
        }
      };

      // Reserve costs immediately (atomic transition)
      let updatedUnits = [...state.swarm.units];
      if (consumedUnit) {
        updatedUnits = updatedUnits.filter(u => u.id !== consumedUnit!.id);
      }

      const updatedBiomass = state.swarm.biomass - rule.biomassCost;
      const updatedLarvae = state.swarm.larvae - rule.larvaCost;

      const newState: GameState = {
        ...state,
        swarm: {
          ...state.swarm,
          biomass: updatedBiomass,
          larvae: updatedLarvae,
          units: updatedUnits,
          processes: [...state.swarm.processes, newProcess],
          unitCap: calculateSwarmUnitCap(updatedUnits)
        }
      };

      events.push({
        type: 'PROCESS_STARTED',
        message: `Began gestation of ${unitType} (${rule.turnsRequired} messages remaining). Deducted ${rule.biomassCost} Biomass and ${rule.larvaCost} Larva.`,
        entityId: processId,
        data: { unitType, remainingMessages: rule.turnsRequired }
      });

      return auditAndReturn(
        newState,
        'MUTATE_UNIT',
        `Started mutation: ${unitType} [${rule.turnsRequired} turns]`,
        prevStateSnap,
        events
      );
    }

    case 'CREATE_NYDUS': {
      const { sourceBaseId, destination } = command.payload;
      const sourceBase = state.bases.find(b => b.baseId === sourceBaseId);
      if (!sourceBase) {
        return { ok: false, code: 'INVALID_BASE', message: `Source base ${sourceBaseId} not found.`, state };
      }

      // Check if Nydus Network exists at base or in swarm
      const hasNydusNetwork = sourceBase.structureIds.includes('struct-nydus-network') ||
        state.bases.some(b => b.structureIds.includes('struct-nydus-network'));

      if (!hasNydusNetwork) {
        return {
          ok: false,
          code: 'REQUIRES_NYDUS_NETWORK',
          message: 'Cannot create a Nydus Worm without an operational Nydus Network structure.',
          state
        };
      }

      const targetRegion = state.map.regions.find(r => r.id === destination);
      if (!targetRegion) {
        return { ok: false, code: 'INVALID_DESTINATION', message: `Destination region "${destination}" not found.`, state };
      }

      const rule = MUTATION_RULES['Nydus Worm'];
      if (state.swarm.biomass < rule.biomassCost) {
        return {
          ok: false,
          code: 'INSUFFICIENT_BIOMASS',
          message: `Requires ${rule.biomassCost} Biomass to burrow Nydus Worm canal.`,
          state
        };
      }

      const processId = `proc-nydus-${Date.now()}`;
      const newProcess: Process = {
        id: processId,
        type: 'CREATE_NYDUS',
        name: `Burrowing Nydus Worm to ${targetRegion.name}`,
        ownerId: 'swarm',
        targetId: null,
        locationId: destination,
        startedTurn: state.turn,
        remainingMessages: rule.turnsRequired,
        totalMessages: rule.turnsRequired,
        reservedCosts: { biomass: rule.biomassCost },
        status: 'ACTIVE',
        onComplete: 'RESOLVE_NYDUS_WORM',
        completionData: { destinationRegionId: destination, sourceBaseId }
      };

      const newState: GameState = {
        ...state,
        swarm: {
          ...state.swarm,
          biomass: state.swarm.biomass - rule.biomassCost,
          processes: [...state.swarm.processes, newProcess]
        }
      };

      events.push({
        type: 'PROCESS_STARTED',
        message: `Nydus Worm subterranean boring initiated toward ${targetRegion.name} (${rule.turnsRequired} messages).`,
        entityId: processId
      });

      return auditAndReturn(newState, 'CREATE_NYDUS', `Burrowing Nydus Worm to ${targetRegion.name}`, prevStateSnap, events);
    }

    case 'CREATE_INDEPENDENT_HIVE': {
      // Section 7.1:
      // 1. Validate the Hive Queen exists and is owned by the Swarm.
      // 2. Validate every assigned unit is currently Swarm-owned and not locked by another process.
      // 3. Remove the queen and assigned units from Swarm unit collections in the same transaction.
      // 4. Create the new IndependentHive record immediately with status FORMING.
      // 5. Create the base/construction process tied to that hiveId.
      // 6. Create the map marker immediately as a FORMING marker, so the player can see where the project is.
      // 7. Immediately add a News acknowledgement that the queen received the founding order.
      const {
        queenUnitId,
        assignedUnitIds = [],
        baseLocation,
        hiveName
      } = command.payload as {
        queenUnitId: string;
        assignedUnitIds: string[];
        baseLocation: string;
        hiveName?: string;
      };

      const queen = state.swarm.units.find(u => u.id === queenUnitId);
      if (!queen || queen.type !== 'Hive Queen') {
        return {
          ok: false,
          code: 'INVALID_QUEEN',
          message: 'Target queen is not a valid Hive Queen or does not exist.',
          state
        };
      }

      if (queen.ownerId !== 'swarm') {
        return {
          ok: false,
          code: 'QUEEN_NOT_SWARM_OWNED',
          message: `Hive Queen "${queen.name}" is already pledged to an independent hive.`,
          state
        };
      }

      const targetRegion = state.map.regions.find(r => r.id === baseLocation);
      if (!targetRegion) {
        return {
          ok: false,
          code: 'INVALID_LOCATION',
          message: `Target founding location "${baseLocation}" does not exist on the tactical map.`,
          state
        };
      }

      // Check if another base already occupies this exact region
      const existingBaseAtLocation = state.bases.find(b => b.locationId === baseLocation && b.status === 'ACTIVE');
      if (existingBaseAtLocation) {
        return {
          ok: false,
          code: 'LOCATION_OCCUPIED',
          message: `Region ${targetRegion.name} already houses active base ${existingBaseAtLocation.name}.`,
          state
        };
      }

      // Validate assigned units are swarm-owned and exist
      const allUnitIdsToTransfer = [queenUnitId, ...assignedUnitIds];
      const unitsToTransfer: Unit[] = [];

      for (const uId of allUnitIdsToTransfer) {
        const u = state.swarm.units.find(unit => unit.id === uId);
        if (!u) {
          return {
            ok: false,
            code: 'UNIT_NOT_FOUND',
            message: `Assigned unit ${uId} does not exist in the Swarm catalog.`,
            state
          };
        }
        if (u.ownerId !== 'swarm') {
          return {
            ok: false,
            code: 'UNIT_NOT_OWNED',
            message: `Assigned unit "${u.name}" (${u.type}) is not owned by the main Swarm.`,
            state
          };
        }
        unitsToTransfer.push(u);
      }

      const hiveId = `hive-${queen.name.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}`;
      const actualHiveName = hiveName || `${queen.name}'s Brood`;
      const mapMarkerId = `marker-${hiveId}`;
      const processId = `proc-found-${hiveId}`;

      // Update unit ownership atomically
      const transferredUnits = unitsToTransfer.map(u => ({
        ...u,
        ownerId: hiveId,
        locationId: baseLocation,
        status: 'MOVING' as const
      }));

      // Remove transferred units from Swarm
      const remainingSwarmUnits = state.swarm.units.filter(u => !allUnitIdsToTransfer.includes(u.id));

      // Create new IndependentHive record with status FORMING
      const newHive: IndependentHive = {
        hiveId,
        name: actualHiveName,
        queenUnitId: queen.id,
        status: 'FORMING',
        biomass: 150,
        biomassPer10Turns: 80,
        swarmShareRate: 0.30,
        pendingContribution: 0,
        ownedUnits: transferredUnits.map(u => u.id),
        ownedBases: [],
        teams: [],
        activeOrders: [],
        completedOrders: [],
        constructionProcesses: [processId],
        level: 1,
        territory: [baseLocation],
        permissions: {
          mayAttack: true,
          mayExpand: true,
          mayCreateTeams: true
        },
        mapMarkerId,
        color: '#a855f7' // bioluminescent royal violet
      };

      // Create formation process: takes 3 turns (travel + base construction)
      const formationProcess: Process = {
        id: processId,
        type: 'HIVE_FORMATION',
        name: `Founding ${actualHiveName}`,
        ownerId: hiveId,
        targetId: hiveId,
        locationId: baseLocation,
        startedTurn: state.turn,
        remainingMessages: 3,
        totalMessages: 3,
        reservedCosts: { unitIds: allUnitIdsToTransfer },
        status: 'ACTIVE',
        onComplete: 'RESOLVE_INDEPENDENT_HIVE_FORMATION',
        completionData: {
          hiveId,
          baseLocation,
          hiveName: actualHiveName,
          queenId: queen.id
        }
      };

      // Create map marker immediately as FORMING
      const newMapMarker: MapObject = {
        objectId: mapMarkerId,
        kind: 'HIVE',
        sourceEntityId: hiveId,
        locationId: baseLocation,
        ownerId: hiveId,
        status: 'FORMING',
        visible: true,
        label: `${actualHiveName} (Forming)`
      };

      // Immediate news acknowledgement from Queen
      const newsEntry: NewsEntry = {
        id: `news-${Date.now()}`,
        sourceId: hiveId,
        sourceType: 'HIVE_QUEEN',
        turn: state.turn,
        visibility: 'GLOBAL',
        headline: `${queen.name} Acknowledged Founding Directive`,
        facts: `${queen.name} has severed primary bio-link with the Swarm Core, departing with ${assignedUnitIds.length} organism(s) to colonize ${targetRegion.name}. Status: FORMING.`,
        timestamp: Date.now()
      };

      const newState: GameState = {
        ...state,
        swarm: {
          ...state.swarm,
          units: remainingSwarmUnits,
          processes: [...state.swarm.processes, formationProcess],
          unitCap: calculateSwarmUnitCap(remainingSwarmUnits)
        },
        hives: [...state.hives, newHive],
        map: {
          ...state.map,
          objects: [...state.map.objects, newMapMarker]
        },
        news: [newsEntry, ...state.news]
      };

      events.push({
        type: 'INDEPENDENT_HIVE_FORMING',
        message: `${queen.name} acknowledged the founding order and began expansion to ${targetRegion.name} (3 messages to establish).`,
        entityId: hiveId,
        data: { hiveId, queenName: queen.name, regionName: targetRegion.name }
      });

      return auditAndReturn(
        newState,
        'CREATE_INDEPENDENT_HIVE',
        `Initiated founding of ${actualHiveName} at ${targetRegion.name}`,
        prevStateSnap,
        events
      );
    }

    case 'SEND_HIVE_DIRECTIVE': {
      const {
        hiveId,
        orderText,
        objectiveType = 'SCOUT',
        targetLocationId = null,
        targetId = null
      } = command.payload;

      const hive = state.hives.find(h => h.hiveId === hiveId);
      if (!hive) {
        return { ok: false, code: 'HIVE_NOT_FOUND', message: `Independent hive ${hiveId} not found.`, state };
      }

      if (hive.status === 'FORMING') {
        return {
          ok: false,
          code: 'HIVE_STILL_FORMING',
          message: `${hive.name} is still FORMING. Orders cannot be executed until initial hatchery construction completes.`,
          state
        };
      }

      const orderId = `order-${Date.now()}`;
      const targetLoc = targetLocationId || hive.territory[0] || 'region-northern-chasm';

      // Section 9 / Section 8.1 Directive State Machine
      const newOrder: HiveOrder = {
        orderId,
        hiveId,
        source: 'SWARM_KING',
        text: orderText || `Execute ${objectiveType} at ${targetLoc}`,
        objectiveType,
        targetId,
        targetLocationId: targetLoc,
        teamId: null,
        stage: 'RECEIVED',
        status: 'ACTIVE',
        plan: [
          {
            stepId: `step-plan-${orderId}-1`,
            description: `Rally expeditionary team at ${hive.name}`,
            type: 'SCOUT',
            locationId: targetLoc,
            turnsRequired: 1,
            turnsSpent: 0,
            isComplete: false
          },
          {
            stepId: `step-move-${orderId}-2`,
            description: `Traverse biological corridor to ${targetLoc}`,
            type: 'MOVE',
            locationId: targetLoc,
            turnsRequired: 2,
            turnsSpent: 0,
            isComplete: false
          },
          {
            stepId: `step-exec-${orderId}-3`,
            description: `Execute ${objectiveType} directive at target coordinates`,
            type: objectiveType === 'BUILD' ? 'BUILD' : objectiveType === 'HUNT' ? 'ENGAGE' : 'SCOUT',
            locationId: targetLoc,
            turnsRequired: 2,
            turnsSpent: 0,
            isComplete: false
          }
        ],
        currentStepIndex: 0,
        completionPredicate: 'ALL_PLAN_STEPS_RESOLVED',
        startedTurn: state.turn,
        lastProgressTurn: state.turn,
        stalledTurns: 0
      };

      // Queen acknowledgement to News immediately
      const queenUnit = [...state.swarm.units, ...hive.ownedUnits.map(id => ({ id, name: 'Queen' }))].find(
        u => u.id === hive.queenUnitId
      );
      const queenName = queenUnit?.name || 'Hive Queen';

      const ackNews: NewsEntry = {
        id: `news-ack-${orderId}`,
        sourceId: hive.hiveId,
        sourceType: 'HIVE_QUEEN',
        turn: state.turn,
        visibility: 'GLOBAL',
        headline: `${queenName} Accepted Directive`,
        facts: `${queenName} acknowledges: "${newOrder.text}". Mobilizing sub-brood to execute.`,
        timestamp: Date.now()
      };

      const updatedHives = state.hives.map(h => {
        if (h.hiveId === hiveId) {
          return {
            ...h,
            activeOrders: [...h.activeOrders, newOrder]
          };
        }
        return h;
      });

      const newState: GameState = {
        ...state,
        hives: updatedHives,
        news: [ackNews, ...state.news]
      };

      events.push({
        type: 'DIRECTIVE_RECEIVED',
        message: `${queenName} acknowledged directive: "${newOrder.text}". Order registered as ACTIVE.`,
        entityId: orderId,
        data: { hiveId, orderId }
      });

      return auditAndReturn(newState, 'SEND_HIVE_DIRECTIVE', `Directive issued to ${hive.name}`, prevStateSnap, events);
    }

    case 'CREATE_TEAM': {
      const {
        ownerId = 'swarm',
        unitIds = [],
        teamName,
        directive = 'Hold position and defend perimeter',
        locationId
      } = command.payload;

      if (!unitIds || unitIds.length === 0) {
        return { ok: false, code: 'NO_UNITS_SELECTED', message: 'Cannot create an empty team. Select at least 1 unit.', state };
      }

      // Check unit ownership: All units must belong to ownerId
      for (const uId of unitIds) {
        const u = state.swarm.units.find(x => x.id === uId);
        if (!u) {
          return { ok: false, code: 'UNIT_NOT_FOUND', message: `Unit ${uId} does not exist.`, state };
        }
        if (u.ownerId !== ownerId) {
          return {
            ok: false,
            code: 'OWNERSHIP_MISMATCH',
            message: `Unit "${u.name}" belongs to ${u.ownerId}, not ${ownerId}. A team may only contain units owned by the same entity.`,
            state
          };
        }
      }

      const teamId = `team-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const targetLocation = locationId || state.player.locationId;
      const homeBase = state.bases.find(b => b.ownerId === ownerId)?.baseId || state.bases[0]?.baseId || 'base-central-spire';

      const newTeam: Team = {
        teamId,
        ownerId,
        name: teamName || (ownerId === 'swarm' ? "Swarm's Strike Team" : "Queen's Bio-Cohort"),
        unitIds: [...unitIds],
        homeBaseId: homeBase,
        locationId: targetLocation,
        directive,
        status: 'IDLE',
        targetId: null,
        targetLocationId: null,
        path: [],
        progress: 100,
        sourceOrderId: null
      };

      // Remove units from any previous team and assign to this new team
      const updatedTeams = state.teams
        .map(t => {
          const remainingUnits = t.unitIds.filter(id => !unitIds.includes(id));
          return {
            ...t,
            unitIds: remainingUnits,
            status: remainingUnits.length === 0 ? ('DISBANDED' as const) : t.status
          };
        })
        .filter(t => t.status !== 'DISBANDED');

      updatedTeams.push(newTeam);

      // Update unit status and teamId
      const updatedSwarmUnits = state.swarm.units.map(u => {
        if (unitIds.includes(u.id)) {
          return {
            ...u,
            teamId: newTeam.teamId,
            status: 'IN_TEAM' as const
          };
        }
        return u;
      });

      // Add map object for team
      const teamMapObject: MapObject = {
        objectId: `obj-${newTeam.teamId}`,
        kind: 'TEAM',
        sourceEntityId: newTeam.teamId,
        locationId: targetLocation,
        ownerId,
        status: 'IDLE',
        visible: true,
        label: newTeam.name
      };

      const newState: GameState = {
        ...state,
        teams: updatedTeams,
        swarm: {
          ...state.swarm,
          units: updatedSwarmUnits,
          teams: ownerId === 'swarm' ? [...state.swarm.teams, teamId] : state.swarm.teams
        },
        map: {
          ...state.map,
          objects: [...state.map.objects, teamMapObject]
        }
      };

      events.push({
        type: 'TEAM_CREATED',
        message: `Formed team "${newTeam.name}" with ${unitIds.length} organisms.`,
        entityId: teamId
      });

      return auditAndReturn(newState, 'CREATE_TEAM', `Created team ${newTeam.name}`, prevStateSnap, events);
    }

    case 'PROGRAM_TEAM': {
      const { teamId, directive, targetLocationId } = command.payload;
      const team = state.teams.find(t => t.teamId === teamId);
      if (!team) {
        return { ok: false, code: 'TEAM_NOT_FOUND', message: `Team ${teamId} not found.`, state };
      }

      const updatedTeams = state.teams.map(t => {
        if (t.teamId === teamId) {
          const isMoving = !!targetLocationId && targetLocationId !== t.locationId;
          return {
            ...t,
            directive,
            targetLocationId: targetLocationId || t.targetLocationId,
            status: isMoving ? ('MOVING' as const) : ('EXECUTING' as const)
          };
        }
        return t;
      });

      const newState: GameState = {
        ...state,
        teams: updatedTeams
      };

      events.push({
        type: 'TEAM_PROGRAMMED',
        message: `Reprogrammed ${team.name}: "${directive}".`,
        entityId: teamId
      });

      return auditAndReturn(newState, 'PROGRAM_TEAM', `Updated directive for ${team.name}`, prevStateSnap, events);
    }

    case 'BUILD_HATCHERY': {
      const { regionId } = command.payload;
      const targetRegion = state.map.regions.find(r => r.id === regionId);
      if (!targetRegion) {
        return { ok: false, code: 'INVALID_REGION', message: `Region "${regionId}" not found.`, state };
      }

      const rule = MUTATION_RULES['Hatchery'];
      if (state.swarm.biomass < rule.biomassCost) {
        return {
          ok: false,
          code: 'INSUFFICIENT_BIOMASS',
          message: `Requires ${rule.biomassCost} Biomass to build Hatchery.`,
          state
        };
      }

      const processId = `proc-build-hatchery-${Date.now()}`;
      const newProcess: Process = {
        id: processId,
        type: 'BUILD_BASE',
        name: `Constructing Hatchery at ${targetRegion.name}`,
        ownerId: 'swarm',
        targetId: null,
        locationId: regionId,
        startedTurn: state.turn,
        remainingMessages: rule.turnsRequired,
        totalMessages: rule.turnsRequired,
        reservedCosts: { biomass: rule.biomassCost },
        status: 'ACTIVE',
        onComplete: 'RESOLVE_BUILD_HATCHERY',
        completionData: { regionId, baseName: `${targetRegion.name} Spawning Node` }
      };

      const newState: GameState = {
        ...state,
        swarm: {
          ...state.swarm,
          biomass: state.swarm.biomass - rule.biomassCost,
          processes: [...state.swarm.processes, newProcess]
        }
      };

      events.push({
        type: 'PROCESS_STARTED',
        message: `Hatchery construction started at ${targetRegion.name} (${rule.turnsRequired} messages).`,
        entityId: processId
      });

      return auditAndReturn(newState, 'BUILD_HATCHERY', `Building Hatchery at ${targetRegion.name}`, prevStateSnap, events);
    }

    case 'MUTATE_STRUCTURE': {
      const { baseId, targetStructure } = command.payload;
      const base = state.bases.find(b => b.baseId === baseId);
      if (!base) {
        return { ok: false, code: 'BASE_NOT_FOUND', message: `Base ${baseId} not found.`, state };
      }

      const rule = MUTATION_RULES[targetStructure];
      if (!rule) {
        return { ok: false, code: 'INVALID_STRUCTURE', message: `Unknown structure ${targetStructure}.`, state };
      }

      // Check prerequisites
      if (targetStructure === 'Lair' && base.type !== 'HATCHERY') {
        return { ok: false, code: 'INVALID_PREREQUISITE', message: 'Lair mutation requires a completed Hatchery.', state };
      }
      if (targetStructure === 'Hive' && base.type !== 'LAIR') {
        return { ok: false, code: 'INVALID_PREREQUISITE', message: 'Hive mutation requires a completed Lair.', state };
      }
      if (targetStructure === 'Swarm Citadel' && base.type !== 'HIVE') {
        return { ok: false, code: 'INVALID_PREREQUISITE', message: 'Swarm Citadel requires a completed Hive.', state };
      }

      if (state.swarm.biomass < rule.biomassCost) {
        return {
          ok: false,
          code: 'INSUFFICIENT_BIOMASS',
          message: `Requires ${rule.biomassCost} Biomass to mutate ${targetStructure}.`,
          state
        };
      }

      const processId = `proc-struct-${Date.now()}`;
      const newProcess: Process = {
        id: processId,
        type: 'MUTATE_STRUCTURE',
        name: `Evolving ${base.name} into ${targetStructure}`,
        ownerId: base.ownerId,
        targetId: baseId,
        locationId: base.locationId,
        startedTurn: state.turn,
        remainingMessages: rule.turnsRequired,
        totalMessages: rule.turnsRequired,
        reservedCosts: { biomass: rule.biomassCost },
        status: 'ACTIVE',
        onComplete: 'RESOLVE_MUTATE_STRUCTURE',
        completionData: { baseId, targetStructure }
      };

      const newState: GameState = {
        ...state,
        swarm: {
          ...state.swarm,
          biomass: state.swarm.biomass - rule.biomassCost,
          processes: [...state.swarm.processes, newProcess]
        }
      };

      events.push({
        type: 'PROCESS_STARTED',
        message: `Metamorphosis into ${targetStructure} initiated (${rule.turnsRequired} messages).`,
        entityId: processId
      });

      return auditAndReturn(newState, 'MUTATE_STRUCTURE', `Mutating structure to ${targetStructure}`, prevStateSnap, events);
    }

    case 'TRANSFER_UNITS': {
      const { fromOwner, toOwner, unitIds } = command.payload as {
        fromOwner: string;
        toOwner: string;
        unitIds: string[];
      };

      if (!unitIds || unitIds.length === 0) {
        return { ok: false, code: 'NO_UNITS', message: 'No units specified for transfer.', state };
      }

      // Find units
      const unitsToTransfer: Unit[] = [];
      for (const id of unitIds) {
        let found = state.swarm.units.find(u => u.id === id);
        if (!found) {
          // Check hive units
          for (const h of state.hives) {
            // In GameState, all units can also be resolved via helper
            if (h.ownedUnits.includes(id)) {
              // Create mock or resolve
              found = {
                id,
                name: 'Transferred Organism',
                type: 'Zerglings',
                ownerId: h.hiveId,
                locationId: h.territory[0] || 'region-central-spire',
                teamId: null,
                status: 'IDLE',
                hp: 35,
                maxHp: 35,
                attack: 10,
                consumesCap: true,
                providesCap: 0
              };
            }
          }
        }
        if (!found || found.ownerId !== fromOwner) {
          return {
            ok: false,
            code: 'UNIT_TRANSFER_INVALID',
            message: `Unit ${id} is not owned by source owner ${fromOwner}.`,
            state
          };
        }
        unitsToTransfer.push(found);
      }

      // Execute transfer atomically
      let newSwarmUnits = [...state.swarm.units];
      if (fromOwner === 'swarm') {
        newSwarmUnits = newSwarmUnits.filter(u => !unitIds.includes(u.id));
      }

      const newHives = state.hives.map(h => {
        if (h.hiveId === fromOwner) {
          return {
            ...h,
            ownedUnits: h.ownedUnits.filter(id => !unitIds.includes(id))
          };
        }
        if (h.hiveId === toOwner) {
          return {
            ...h,
            ownedUnits: [...h.ownedUnits, ...unitIds]
          };
        }
        return h;
      });

      if (toOwner === 'swarm') {
        for (const u of unitsToTransfer) {
          u.ownerId = 'swarm';
          newSwarmUnits.push(u);
        }
      }

      const newState: GameState = {
        ...state,
        swarm: {
          ...state.swarm,
          units: newSwarmUnits,
          unitCap: calculateSwarmUnitCap(newSwarmUnits)
        },
        hives: newHives
      };

      events.push({
        type: 'UNITS_TRANSFERRED',
        message: `Transferred ${unitIds.length} organism(s) from ${fromOwner} to ${toOwner}.`,
        data: { fromOwner, toOwner, unitIds }
      });

      return auditAndReturn(newState, 'TRANSFER_UNITS', `Transferred units from ${fromOwner} to ${toOwner}`, prevStateSnap, events);
    }

    case 'SET_HIVE_POLICY': {
      const { hiveId, policy } = command.payload;
      const hive = state.hives.find(h => h.hiveId === hiveId);
      if (!hive) {
        return { ok: false, code: 'HIVE_NOT_FOUND', message: `Hive ${hiveId} not found.`, state };
      }

      const updatedHives = state.hives.map(h => {
        if (h.hiveId === hiveId) {
          return {
            ...h,
            permissions: {
              ...h.permissions,
              ...policy
            }
          };
        }
        return h;
      });

      const newState: GameState = {
        ...state,
        hives: updatedHives
      };

      events.push({
        type: 'POLICY_UPDATED',
        message: `Updated behavioral doctrines for ${hive.name}.`,
        entityId: hiveId
      });

      return auditAndReturn(newState, 'SET_HIVE_POLICY', `Updated policy for ${hive.name}`, prevStateSnap, events);
    }

    case 'ADVANCE_TURN': {
      // Direct manual advance turn call without extra command
      return { ok: true, state, events: [{ type: 'TURN_ADVANCED', message: `Turn advanced to ${state.turn + 1}` }] };
    }

    default:
      return { ok: false, code: 'UNKNOWN_COMMAND', message: `Unknown command type: ${(command as any).type}`, state };
  }
}

/**
 * Creates audit log, checks invariants, and returns standardized Result
 */
function auditAndReturn(
  newState: GameState,
  commandType: string,
  summary: string,
  prevStateSnap: Record<string, any>,
  events: StateEvent[]
): Result<GameState> {
  const invariantCheck = validateInvariants(newState);
  if (!invariantCheck.valid) {
    return {
      ok: false,
      code: 'INVARIANT_VIOLATION',
      message: invariantCheck.error || 'State invariant violated.',
      state: newState
    };
  }

  const logEntry: StateTransition = {
    id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    turn: newState.turn,
    commandType,
    summary,
    before: prevStateSnap,
    after: {
      biomass: newState.swarm.biomass,
      larvae: newState.swarm.larvae,
      unitsCount: newState.swarm.units.length,
      hivesCount: newState.hives.length,
      processesCount: newState.swarm.processes.length
    },
    timestamp: Date.now()
  };

  return {
    ok: true,
    state: {
      ...newState,
      log: [logEntry, ...newState.log.slice(0, 99)]
    },
    events
  };
}
