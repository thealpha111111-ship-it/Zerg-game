/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  GameState,
  Mode,
  StateEvent,
  FirstPersonResponse,
  StateChangeSummary,
  Command,
  Result,
  Process
} from '../types/game.ts';

/**
 * Renders mode-appropriate narration after state mutation has completed.
 * Pure narration: strictly consumes state, never mutates it.
 */
export function generateNarration(
  mode: Mode,
  state: GameState,
  command: Command,
  result: Result<GameState>,
  completedProcesses: Process[] = []
): { text: string; firstPerson?: FirstPersonResponse } {
  // If the command failed validation, explain the exact blocking rule
  if (!result.ok) {
    const errorText = `Direct mental feedback: Command halted — ${result.message} [Error Code: ${result.code}]. Suggestion: Review available resources or prerequisites.`;
    return {
      text: errorText,
      firstPerson: {
        mode: 'FIRST_PERSON',
        speaker: 'Neural Overmind Cortex',
        reply: errorText,
        scene: null,
        playerLocationId: state.player.locationId,
        stateChanges: []
      }
    };
  }

  const events = result.events || [];
  const stateChanges: StateChangeSummary[] = events.map(e => ({
    type: e.type,
    description: e.message,
    entityId: e.entityId
  }));

  const currentRegion = state.map.regions.find(r => r.id === state.player.locationId);
  const locationName = currentRegion ? currentRegion.name : 'Unknown Biome';

  // 1. FIRST PERSON MODE (Section 4 & 4.1)
  if (mode === 'FIRST_PERSON') {
    const playerMsg = (command.rawMessage || '').toLowerCase();
    let reply = '';
    let scene: string | null = null;
    let speaker = 'Queen Zagara';

    // Check if player explicitly asked for resource status
    const requestedStatus =
      playerMsg.includes('resource') ||
      playerMsg.includes('biomass') ||
      playerMsg.includes('larvae') ||
      playerMsg.includes('how many units') ||
      playerMsg.includes('status report');

    if (requestedStatus) {
      reply = `"Sovereign, our metabolic stores currently stand at ${state.swarm.biomass} Biomass. We have ${state.swarm.larvae} viable larvae in the incubation pool, commanding ${state.swarm.units.length} total bio-forms under neural lock."`;
    } else if (command.type === 'MOVE_PLAYER') {
      speaker = 'Sovereign Awareness';
      reply = `You stride through the pulsating chitin archways into the ${locationName}. The air here is heavy with spores, and the creep responds instantly to the weight of your presence.`;
      scene = `Location: ${locationName}. ${currentRegion?.description || ''}`;
    } else if (command.type === 'CREATE_INDEPENDENT_HIVE') {
      speaker = 'Queen Zagara';
      reply = `"As you command, my Sovereign. I take the assigned brood to the ${locationName}. I shall weave a new heart for the Swarm and tithe thirty percent of our metabolic surplus back to your throne."`;
      scene = `Spawning tendrils detach as Queen Zagara and her vanguard march toward their new territory. Gestation process commenced (3 turns remaining).`;
    } else if (command.type === 'SEND_HIVE_DIRECTIVE') {
      speaker = 'Hive Queen';
      reply = `"Directive received and sealed into synaptic memory. My brood is mobilizing to execute."`;
    } else if (command.type === 'MUTATE_UNIT') {
      speaker = 'Central Gestation Pit';
      const unitType = command.payload.unitType;
      const proc = state.swarm.processes.find(p => p.type === 'MUTATE_UNIT' && p.status === 'ACTIVE');
      reply = `A warm cocoon envelops the genetic sample. Gestation of ${unitType} has begun. It will require ${proc?.remainingMessages ?? 1} turn(s) to hatch.`;
    } else if (command.type === 'CREATE_NYDUS') {
      speaker = 'Nydus Maw';
      reply = `The earth groans deep beneath your feet as subterranean acid carves a tunnel to the target sector.`;
    } else {
      // General TALK / RP conversation
      if (playerMsg.includes('scout') || playerMsg.includes('western') || playerMsg.includes('returned')) {
        reply = `"The scouting party beyond the ridge has missed its scheduled neural ping. I have marked their last vector and dispatched sensory drones to investigate."`;
        scene = `The fleshy membranes of the ${locationName} pulse softly beneath your feet.`;
      } else if (playerMsg.includes('enemy') || playerMsg.includes('threat') || playerMsg.includes('danger')) {
        reply = `"Sensors detect faint seismic tremors beyond our creep borders. The outer perimeter remains on high vigil."`;
      } else {
        speaker = 'Queen Zagara';
        reply = `"My Sovereign. The collective will flows unbroken through our synapses. What direction shall the brood take?"`;
        scene = `You stand within ${locationName}. Bio-luminescent veins course with vital nutrients along the ribbed cavern ceiling.`;
      }
    }

    // Append newly completed processes if any finished this turn
    if (completedProcesses.length > 0) {
      const compTexts = completedProcesses.map(p => `A gestation vat ruptures open: ${p.name} has finished and stands ready.`);
      reply += `\n\n${compTexts.join('\n')}`;
    }

    const firstPersonResponse: FirstPersonResponse = {
      mode: 'FIRST_PERSON',
      speaker,
      reply,
      scene,
      playerLocationId: state.player.locationId,
      stateChanges
    };

    return {
      text: reply,
      firstPerson: firstPersonResponse
    };
  }

  // 2. OVERVIEW MODE
  if (mode === 'OVERVIEW') {
    const activeProcCount = state.swarm.processes.filter(p => p.status === 'ACTIVE').length;
    const hivesCount = state.hives.length;
    return {
      text: `Strategic Overview: ${state.swarm.biomass} Biomass | ${state.swarm.larvae} Larvae | ${state.swarm.units.length}/${state.swarm.unitCap} Units | ${state.bases.length} Bases | ${hivesCount} Sub-Hives | ${activeProcCount} Active Gestations.`
    };
  }

  // 3. MUTATION MODE
  if (mode === 'MUTATION') {
    if (command.type === 'MUTATE_UNIT') {
      return {
        text: `Mutation vat initiated: ${command.payload.unitType}. Reserved costs applied. Gestation progressing.`
      };
    }
    return {
      text: `Mutation Chamber online. ${state.swarm.larvae} larvae available for genetic transcription.`
    };
  }

  // 4. MAP MODE
  if (mode === 'MAP') {
    return {
      text: `Tactical Grid: Sovereign located at ${locationName}. ${state.map.objects.length} entities tracked across ${state.map.regions.length} bio-sectors.`
    };
  }

  // 5. HIVE WINDOW MODE
  if (mode === 'HIVE_WINDOW') {
    return {
      text: `Sub-Hive neural link active. Monitoring autonomous brood operations and resource contributions.`
    };
  }

  // Fallback
  return {
    text: events.length > 0 ? events[0].message : `Swarm state registered at turn ${state.turn}.`
  };
}
