/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  GameState,
  Command,
  Mode,
  Result,
  FirstPersonResponse,
  ChatMessage
} from '../types/game.ts';
import { createInitialGameState } from './data/initialState.ts';
import { applyCommand, validateInvariants } from './rulesEngine.ts';
import { advanceSimulationTurn } from './processEngine.ts';
import { parsePlayerMessage } from './commandParser.ts';
import { generateNarration } from './narrator.ts';

const STORAGE_KEY = 'the_swarm_rts_game_state_v2';
let memoryStorage: Record<string, string> = {};

function getStorageItem(key: string): string | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      return window.localStorage.getItem(key);
    }
    return memoryStorage[key] || null;
  } catch {
    return memoryStorage[key] || null;
  }
}

function setStorageItem(key: string, value: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
    memoryStorage[key] = value;
  } catch {
    memoryStorage[key] = value;
  }
}

function removeStorageItem(key: string): void {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.removeItem(key);
    }
    delete memoryStorage[key];
  } catch {
    delete memoryStorage[key];
  }
}

/**
 * Loads GameState from LocalStorage or generates initial state
 */
export function loadGameState(): GameState {
  try {
    const raw = getStorageItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Validate basic shape
      if (parsed && typeof parsed.turn === 'number' && parsed.swarm && parsed.map) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load state from localStorage:', err);
  }
  const fresh = createInitialGameState();
  saveGameState(fresh);
  return fresh;
}

/**
 * Persists GameState atomically to LocalStorage
 */
export function saveGameState(state: GameState): void {
  try {
    setStorageItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to save state to localStorage:', err);
  }
}

/**
 * Resets GameState to clean initial seed
 */
export function resetGameState(): GameState {
  removeStorageItem(STORAGE_KEY);
  const fresh = createInitialGameState();
  saveGameState(fresh);
  return fresh;
}

/**
 * Central State Machine Dispatcher
 * PLAYER MESSAGE -> MODE ROUTER -> COMMAND PARSER -> VALIDATION -> RULES ENGINE -> PROCESS ENGINE (+1 turn) -> PERSIST -> MODE NARRATOR -> UI RENDER
 */
export function dispatchTurn(
  currentState: GameState,
  playerMessage: string,
  activeMode: Mode,
  explicitCommand?: Command
): { state: GameState; result: Result<GameState>; narration: { text: string; firstPerson?: FirstPersonResponse } } {
  // 1. Command Parser
  const command = explicitCommand || parsePlayerMessage(playerMessage, currentState, activeMode);

  // Record player message to chat history if in FIRST_PERSON or message was typed
  let chatHistory = [...currentState.chatHistory];
  if (playerMessage && playerMessage.trim().length > 0) {
    const playerChat: ChatMessage = {
      id: `chat-p-${Date.now()}`,
      turn: currentState.turn,
      mode: activeMode,
      sender: 'PLAYER',
      text: playerMessage,
      locationId: currentState.player.locationId,
      timestamp: Date.now()
    };
    chatHistory.push(playerChat);
  }

  const stateWithChat: GameState = {
    ...currentState,
    chatHistory
  };

  // 2. Rules Engine Validation & State Transition
  const ruleResult = applyCommand(stateWithChat, command);

  // If command failed validation, do NOT advance processes or turns. Explain failure directly!
  if (!ruleResult.ok) {
    const narration = generateNarration(activeMode, stateWithChat, command, ruleResult, []);
    
    // Add failure reply to chat if in First Person
    if (activeMode === 'FIRST_PERSON') {
      const assistantChat: ChatMessage = {
        id: `chat-fail-${Date.now()}`,
        turn: currentState.turn,
        mode: activeMode,
        sender: 'ASSISTANT',
        text: narration.firstPerson?.reply || narration.text,
        scene: null,
        locationId: currentState.player.locationId,
        timestamp: Date.now()
      };
      const finalFailedState = {
        ...ruleResult.state,
        chatHistory: [...ruleResult.state.chatHistory, assistantChat]
      };
      saveGameState(finalFailedState);
      return { state: finalFailedState, result: ruleResult, narration };
    }

    return { state: ruleResult.state, result: ruleResult, narration };
  }

  // 3. Process Engine (+1 Turn, decrements remainingMessages, resolves completions)
  const processResult = advanceSimulationTurn(ruleResult.state);
  let finalState = processResult.state;

  // 4. Invariant assertion
  const invariantCheck = validateInvariants(finalState);
  if (!invariantCheck.valid) {
    console.error('Simulation invariant error:', invariantCheck.error);
  }

  // 5. Narrator
  const allEvents = [...ruleResult.events, ...processResult.events];
  const combinedResult: Result<GameState> = {
    ok: true,
    state: finalState,
    events: allEvents
  };

  const narration = generateNarration(
    activeMode,
    finalState,
    command,
    combinedResult,
    processResult.completedProcesses
  );

  // Add assistant narrative response to chat history
  if (activeMode === 'FIRST_PERSON') {
    const assistantChat: ChatMessage = {
      id: `chat-a-${Date.now()}`,
      turn: finalState.turn,
      mode: activeMode,
      sender: narration.firstPerson?.speaker === 'Queen Zagara' ? 'QUEEN' : 'ASSISTANT',
      text: narration.firstPerson?.reply || narration.text,
      scene: narration.firstPerson?.scene,
      locationId: finalState.player.locationId,
      timestamp: Date.now()
    };
    finalState = {
      ...finalState,
      chatHistory: [...finalState.chatHistory, assistantChat]
    };
  }

  // 6. Persistence before response
  saveGameState(finalState);

  return {
    state: finalState,
    result: combinedResult,
    narration
  };
}
