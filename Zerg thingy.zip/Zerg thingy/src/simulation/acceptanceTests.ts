/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GameState } from '../types/game.ts';
import { createInitialGameState } from './data/initialState.ts';
import { dispatchTurn, saveGameState, loadGameState } from './gameEngine.ts';
import { applyCommand, calculateSwarmUnitCap } from './rulesEngine.ts';

export interface TestResult {
  id: string;
  name: string;
  passed: boolean;
  expected: string;
  actual: string;
  details: string;
  timestamp: number;
}

export function runAllAcceptanceTests(): TestResult[] {
  const results: TestResult[] = [];

  // Helper to run a test with fresh state
  const fresh = () => createInitialGameState();

  // Test 1: FP-01
  // Send a normal conversational message in First Person. Expected: direct in-character reply, no dashboard.
  try {
    const s = fresh();
    const res = dispatchTurn(s, 'What is the current status of the hive walls?', 'FIRST_PERSON');
    const reply = res.narration.firstPerson?.reply || '';
    const hasDashboard = reply.includes('BIOMASS:') || reply.includes('LARVAE:') || reply.includes('UNITS:');
    const hasDialogue = reply.length > 10;
    const passed = !hasDashboard && hasDialogue;
    results.push({
      id: 'FP-01',
      name: 'Conversational First Person Response',
      passed,
      expected: 'Direct in-character reply without global dashboard template.',
      actual: hasDashboard ? 'Contained forbidden dashboard template' : `Character reply: "${reply.slice(0, 60)}..."`,
      details: 'First person mode answered without prepending raw numerical status table.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'FP-01', name: 'Conversational First Person Response', passed: false, expected: 'Reply', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 2: FP-02
  // Move from one location to another in First Person. Expected: player.locationId changes and map marker moves.
  try {
    const s = fresh();
    const targetRegion = 'region-eastern-ridge';
    const res = dispatchTurn(s, 'I walk through the tunnel to Eastern Creep Ridge', 'FIRST_PERSON');
    const moved = res.state.player.locationId === targetRegion;
    results.push({
      id: 'FP-02',
      name: 'Player Movement in First Person',
      passed: moved,
      expected: `player.locationId changes to ${targetRegion}`,
      actual: `player.locationId is ${res.state.player.locationId}`,
      details: 'Player location successfully updated upon movement command.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'FP-02', name: 'Player Movement in First Person', passed: false, expected: 'Region change', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 3: FP-03
  // Ask First Person for resource information explicitly. Expected: status appears only because requested.
  try {
    const s = fresh();
    const res = dispatchTurn(s, 'Give me a status report on our biomass and larvae stores.', 'FIRST_PERSON');
    const reply = res.narration.firstPerson?.reply || '';
    const mentionsBiomass = reply.toLowerCase().includes('biomass');
    const mentionsLarvae = reply.toLowerCase().includes('larva');
    results.push({
      id: 'FP-03',
      name: 'Explicit Resource Query in First Person',
      passed: mentionsBiomass && mentionsLarvae,
      expected: 'Status appears because player explicitly asked for resources.',
      actual: `Reply mentions resources: ${mentionsBiomass && mentionsLarvae}`,
      details: reply.slice(0, 100),
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'FP-03', name: 'Explicit Resource Query', passed: false, expected: 'Resources stated', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 4: HIVE-01
  // Assign units to a new independent hive. Expected: units disappear from Swarm list and appear exactly once in hive list.
  try {
    const s = fresh();
    const queen = s.swarm.units.find(u => u.type === 'Hive Queen');
    const zerglings = s.swarm.units.filter(u => u.type === 'Zerglings').slice(0, 5).map(u => u.id);
    const assignIds = [queen!.id, ...zerglings];

    const res = dispatchTurn(s, '', 'HIVE_WINDOW', {
      type: 'CREATE_INDEPENDENT_HIVE',
      payload: {
        queenUnitId: queen!.id,
        assignedUnitIds: zerglings,
        baseLocation: 'region-northern-chasm',
        hiveName: "Zagara's Brood"
      }
    });

    const swarmStillHas = res.state.swarm.units.some(u => assignIds.includes(u.id));
    const hiveCreated = res.state.hives.length === 1;
    const hiveHasUnits = hiveCreated && assignIds.every(id => res.state.hives[0].ownedUnits.includes(id));
    const passed = !swarmStillHas && hiveCreated && hiveHasUnits;

    results.push({
      id: 'HIVE-01',
      name: 'Atomic Transfer to Independent Hive',
      passed,
      expected: 'Units removed from Swarm and assigned once to Hive.',
      actual: `Swarm has transferred units: ${!swarmStillHas}. Hive has units: ${hiveHasUnits}.`,
      details: 'Atomic transaction transferred Queen and Zerglings into forming hive state.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'HIVE-01', name: 'Atomic Transfer', passed: false, expected: 'Transferred', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 5: HIVE-02
  // Send a directive to the hive. Expected: queen acknowledgement appears immediately in News.
  try {
    const s = fresh();
    // Create hive first
    const queen = s.swarm.units.find(u => u.type === 'Hive Queen');
    const zIds = s.swarm.units.filter(u => u.type === 'Zerglings').slice(0, 4).map(u => u.id);
    const h1 = dispatchTurn(s, '', 'HIVE_WINDOW', {
      type: 'CREATE_INDEPENDENT_HIVE',
      payload: { queenUnitId: queen!.id, assignedUnitIds: zIds, baseLocation: 'region-northern-chasm', hiveName: 'Test Hive' }
    });

    // Advance 3 turns to make hive ACTIVE
    let activeState = h1.state;
    for (let i = 0; i < 3; i++) {
      activeState = dispatchTurn(activeState, 'wait', 'OVERVIEW').state;
    }

    const hiveId = activeState.hives[0].hiveId;
    const dirRes = dispatchTurn(activeState, 'Scout northern volcanic rifts', 'HIVE_WINDOW', {
      type: 'SEND_HIVE_DIRECTIVE',
      payload: { hiveId, orderText: 'Scout northern volcanic rifts', objectiveType: 'SCOUT' }
    });

    const hasAckNews = dirRes.state.news.some(n => n.sourceId === hiveId && n.headline.includes('Accepted Directive'));
    results.push({
      id: 'HIVE-02',
      name: 'Queen Immediate Acknowledgement in News',
      passed: hasAckNews,
      expected: 'Queen acknowledgement appears immediately in News upon directive dispatch.',
      actual: `Acknowledgement News found: ${hasAckNews}`,
      details: 'Queen received private order and logged acknowledgement to news immediately.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'HIVE-02', name: 'Queen Acknowledgement', passed: false, expected: 'News entry', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 6: HIVE-03
  // Directive causes movement. Expected: order remains ACTIVE after arrival until objective is actually completed.
  try {
    let s = fresh();
    const queen = s.swarm.units.find(u => u.type === 'Hive Queen');
    const zIds = s.swarm.units.filter(u => u.type === 'Zerglings').slice(0, 4).map(u => u.id);
    s = dispatchTurn(s, '', 'HIVE_WINDOW', {
      type: 'CREATE_INDEPENDENT_HIVE',
      payload: { queenUnitId: queen!.id, assignedUnitIds: zIds, baseLocation: 'region-northern-chasm', hiveName: 'Active Hive' }
    }).state;

    // Complete formation (3 turns)
    for (let i = 0; i < 3; i++) s = dispatchTurn(s, 'wait', 'OVERVIEW').state;

    // Send directive
    const hiveId = s.hives[0].hiveId;
    s = dispatchTurn(s, 'Hunt enemies', 'HIVE_WINDOW', {
      type: 'SEND_HIVE_DIRECTIVE',
      payload: { hiveId, orderText: 'Hunt enemies', objectiveType: 'HUNT', targetLocationId: 'region-eastern-ridge' }
    }).state;

    // Advance 3 turns: PLANNED -> TEAM_FORMED -> MOVING -> ARRIVED
    for (let i = 0; i < 3; i++) s = dispatchTurn(s, 'wait', 'OVERVIEW').state;

    const order = s.hives[0].activeOrders[0];
    const passed = order && (order.stage === 'ARRIVED' || order.stage === 'EXECUTING') && order.status === 'ACTIVE';

    results.push({
      id: 'HIVE-03',
      name: 'Directive Remains Active After Arrival',
      passed: !!passed,
      expected: 'Order remains ACTIVE at ARRIVED / EXECUTING; not prematurely completed.',
      actual: order ? `Stage: ${order.stage}, Status: ${order.status}` : 'Order missing',
      details: 'Arrival does not terminate order; continues to execution stage.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'HIVE-03', name: 'Directive Lifecycle', passed: false, expected: 'Active after arrival', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 7: HIVE-04
  // Hive completes base construction. Expected: a real Base entity is created, ownedBases updates, map marker changes, and hive becomes ACTIVE.
  try {
    let s = fresh();
    const queen = s.swarm.units.find(u => u.type === 'Hive Queen');
    const zIds = s.swarm.units.filter(u => u.type === 'Zerglings').slice(0, 4).map(u => u.id);
    s = dispatchTurn(s, '', 'HIVE_WINDOW', {
      type: 'CREATE_INDEPENDENT_HIVE',
      payload: { queenUnitId: queen!.id, assignedUnitIds: zIds, baseLocation: 'region-northern-chasm', hiveName: 'Colony 4' }
    }).state;

    // Initially FORMING
    const formingHive = s.hives[0];
    const initialStatus = formingHive.status; // FORMING

    // Advance 3 turns
    for (let i = 0; i < 3; i++) s = dispatchTurn(s, 'wait', 'OVERVIEW').state;

    const activeHive = s.hives[0];
    const hasBaseEntity = s.bases.some(b => b.ownerId === activeHive.hiveId && b.status === 'ACTIVE');
    const hasOwnedBase = activeHive.ownedBases.length > 0;
    const mapMarkerActive = s.map.objects.find(m => m.sourceEntityId === activeHive.hiveId)?.status === 'ACTIVE';
    const passed = initialStatus === 'FORMING' && activeHive.status === 'ACTIVE' && hasBaseEntity && hasOwnedBase && mapMarkerActive;

    results.push({
      id: 'HIVE-04',
      name: 'Hive Formation & Base Realization',
      passed,
      expected: 'Base created, ownedBases updated, marker becomes ACTIVE, hive status=ACTIVE.',
      actual: `Status: ${activeHive.status}, Base exists: ${hasBaseEntity}, Marker: ${mapMarkerActive}`,
      details: 'Complete independent hive formation handler executed successfully.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'HIVE-04', name: 'Hive Realization', passed: false, expected: 'Active base', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 8: HIVE-05
  // Reload page mid-construction. Expected: process resumes from saved remainingMessages, not from the beginning.
  try {
    let s = fresh();
    const queen = s.swarm.units.find(u => u.type === 'Hive Queen');
    s = dispatchTurn(s, '', 'HIVE_WINDOW', {
      type: 'CREATE_INDEPENDENT_HIVE',
      payload: { queenUnitId: queen!.id, assignedUnitIds: [], baseLocation: 'region-northern-chasm', hiveName: 'Reload Hive' }
    }).state;

    // Initial creation: takes 3 turns, action turn decrements to 2
    const remainingBeforeReload = s.swarm.processes.find(p => p.type === 'HIVE_FORMATION')?.remainingMessages;

    // Simulate page reload: Save & Load
    saveGameState(s);
    const reloaded = loadGameState();
    const remainingAfterReload = reloaded.swarm.processes.find(p => p.type === 'HIVE_FORMATION')?.remainingMessages;

    const passed = remainingBeforeReload !== undefined && remainingBeforeReload === remainingAfterReload && remainingAfterReload > 0;
    results.push({
      id: 'HIVE-05',
      name: 'Mid-Construction Persistence',
      passed,
      expected: 'Process remainingMessages matches saved value across reload without resetting.',
      actual: `Before reload: ${remainingBeforeReload}, After reload: ${remainingAfterReload}`,
      details: 'State resumes faithfully from disk without reset.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'HIVE-05', name: 'Mid-Construction Reload', passed: false, expected: 'Resumes', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 9: HIVE-06
  // Issue an impossible order. Expected: BLOCKED/REJECTED with reason; no phantom team or base.
  try {
    const s = fresh();
    // Try to issue order to non-existent hive
    const res = applyCommand(s, {
      type: 'SEND_HIVE_DIRECTIVE',
      payload: { hiveId: 'fake-hive-999', orderText: 'Conquer the void' }
    });
    const passed = !res.ok && res.code === 'HIVE_NOT_FOUND' && res.state.teams.length === s.teams.length;
    results.push({
      id: 'HIVE-06',
      name: 'Reject Impossible Directive',
      passed,
      expected: 'REJECTED with reason; no phantom entities created.',
      actual: `Success: ${res.ok}, Code: ${!res.ok ? res.code : 'N/A'}`,
      details: 'System rejected invalid hive order before any state mutation.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'HIVE-06', name: 'Reject Impossible', passed: false, expected: 'Rejected', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 10: TEAM-01
  // Create team from selected units. Expected: units are removed from previous active team and assigned once.
  try {
    const s = fresh();
    const existingTeam = s.teams[0];
    const unitToMove = existingTeam.unitIds[0];

    const res = dispatchTurn(s, '', 'TEAM_WINDOW', {
      type: 'CREATE_TEAM',
      payload: {
        ownerId: 'swarm',
        unitIds: [unitToMove],
        teamName: 'Delta Infiltrators'
      }
    });

    const oldTeamUpdated = res.state.teams.find(t => t.teamId === existingTeam.teamId);
    const unitRemovedFromOld = !oldTeamUpdated?.unitIds.includes(unitToMove);
    const newTeam = res.state.teams.find(t => t.name === 'Delta Infiltrators');
    const unitInNewTeam = newTeam?.unitIds.includes(unitToMove);
    const passed = unitRemovedFromOld && !!unitInNewTeam;

    results.push({
      id: 'TEAM-01',
      name: 'Atomic Unit Reassignment Across Teams',
      passed,
      expected: 'Unit removed from previous team and assigned to new team exactly once.',
      actual: `Removed from old: ${unitRemovedFromOld}, In new: ${unitInNewTeam}`,
      details: 'Unit transferred cleanly without duplication.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'TEAM-01', name: 'Team Unit Reassignment', passed: false, expected: 'Transferred', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 11: TEAM-02
  // Team reaches destination but objective is unfinished. Expected: state=EXECUTING, not completed.
  try {
    let s = fresh();
    const team = s.teams[0];
    s = dispatchTurn(s, '', 'TEAM_WINDOW', {
      type: 'PROGRAM_TEAM',
      payload: { teamId: team.teamId, directive: 'Scout Acid Trench', targetLocationId: 'region-acid-trench' }
    }).state;

    const progTeam = s.teams.find(t => t.teamId === team.teamId);
    const passed = progTeam?.status === 'MOVING';
    results.push({
      id: 'TEAM-02',
      name: 'Team Directive Execution State',
      passed: !!passed,
      expected: 'Team enters MOVING then EXECUTING, does not prematurely complete.',
      actual: `Team status is ${progTeam?.status}`,
      details: 'Tactical group correctly assigned destination and moving state.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'TEAM-02', name: 'Team Directive Execution', passed: false, expected: 'In progress', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 12: PROC-01
  // Any timed process with N remaining messages must show N and complete exactly once when N reaches 0.
  try {
    let s = fresh();
    // Mutate Roach (requires 3 turns)
    s = dispatchTurn(s, '', 'MUTATION', {
      type: 'MUTATE_UNIT',
      payload: { unitType: 'Roach' }
    }).state;

    const proc = s.swarm.processes.find(p => p.type === 'MUTATE_UNIT');
    const startCount = proc?.remainingMessages; // 2 (since initiating message counted as turn 1)

    // Advance 1 turn
    s = dispatchTurn(s, 'wait', 'OVERVIEW').state;
    const after1 = s.swarm.processes.find(p => p.id === proc?.id)?.remainingMessages; // 1

    // Advance 1 more turn: reaches 0 and completes!
    s = dispatchTurn(s, 'wait', 'OVERVIEW').state;

    // Should now be completed and a new Roach created
    const hasRoach = s.swarm.units.some(u => u.type === 'Roach' && u.name.includes('Roach'));
    const procActive = s.swarm.processes.some(p => p.id === proc?.id && p.status === 'ACTIVE');
    const passed = startCount === 2 && after1 === 1 && !procActive && hasRoach;

    results.push({
      id: 'PROC-01',
      name: 'Timed Process N-to-Zero Completion',
      passed,
      expected: 'Process decrements on each turn (2 -> 1 -> 0) and completes when reaching 0.',
      actual: `Start: ${startCount}, Turn 1: ${after1}, Active at end: ${procActive}`,
      details: 'Process completed and new Roach emerged exactly when remaining reached 0.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'PROC-01', name: 'Process Completion', passed: false, expected: 'Completes at 0', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 13: CAP-01
  // Create/destroy/transfer Overseers. Expected: unit cap updates by exactly +6/-6 and never duplicates.
  try {
    const s = fresh();
    const initialCap = s.swarm.unitCap; // base + 1 overseer = 36

    // Add another Overseer
    const newOverseer = {
      id: 'test-overseer-2',
      type: 'Overseer' as const,
      name: 'Test Overseer 2',
      ownerId: 'swarm',
      locationId: 'region-central-spire',
      teamId: null,
      status: 'IDLE' as const,
      hp: 200,
      maxHp: 200,
      attack: 0,
      consumesCap: false,
      providesCap: 6
    };
    const capWith2 = calculateSwarmUnitCap([...s.swarm.units, newOverseer]); // 42 (+6)
    const capWithoutAny = calculateSwarmUnitCap(s.swarm.units.filter(u => u.type !== 'Overseer')); // 30 (-6)

    const passed = capWith2 === initialCap + 6 && capWithoutAny === initialCap - 6;
    results.push({
      id: 'CAP-01',
      name: 'Overseer Unit Cap Invariant (+6 / -6)',
      passed,
      expected: 'Cap updates by exactly +6 upon addition and -6 upon removal.',
      actual: `Initial: ${initialCap}, Added: ${capWith2} (+6), Removed: ${capWithoutAny} (-6)`,
      details: 'Overseer support-unit capacity calculation is strictly deterministic.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'CAP-01', name: 'Unit Cap Calculation', passed: false, expected: '+6/-6', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 14: NEWS-01
  // Hidden enemy event without valid intelligence. Expected: no News entry.
  try {
    const s = fresh();
    const initialNewsCount = s.news.length;
    // Simulate turn advance with no scouts/seers observing enemy
    const advanced = dispatchTurn(s, 'wait', 'OVERVIEW');
    const omniscientLeaks = advanced.state.news.filter(n => n.headline.toLowerCase().includes('secret enemy plan'));
    const passed = omniscientLeaks.length === 0;

    results.push({
      id: 'NEWS-01',
      name: 'Information Boundaries (No Omniscient News)',
      passed,
      expected: 'No hidden enemy actions leaked without active observation.',
      actual: `Omniscient leaks: ${omniscientLeaks.length}`,
      details: 'News only displays verified Swarm intelligence.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'NEWS-01', name: 'Information Boundaries', passed: false, expected: 'No leak', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 15: NYDUS-01
  // Try to create Nydus Worm without a Network. Expected: rejected with clear reason.
  try {
    const s = fresh();
    const res = applyCommand(s, {
      type: 'CREATE_NYDUS',
      payload: { sourceBaseId: s.bases[0].baseId, destination: 'region-sunken-expanse' }
    });
    const passed = !res.ok && res.code === 'REQUIRES_NYDUS_NETWORK';
    results.push({
      id: 'NYDUS-01',
      name: 'Reject Nydus Worm Without Nydus Network',
      passed,
      expected: 'Rejected with code REQUIRES_NYDUS_NETWORK.',
      actual: `Success: ${res.ok}, Code: ${!res.ok ? res.code : 'OK'}`,
      details: !res.ok ? res.message : 'Nydus constructed',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'NYDUS-01', name: 'Nydus Rejection', passed: false, expected: 'Rejected', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  // Test 16: SAVE-01
  // Reload during a process. Expected: no duplicate units, duplicate base, duplicate team, or duplicate completion event.
  try {
    let s = fresh();
    s = dispatchTurn(s, '', 'MUTATION', {
      type: 'MUTATE_UNIT',
      payload: { unitType: 'Roach' }
    }).state;

    saveGameState(s);
    const reloaded = loadGameState();

    const procCount = reloaded.swarm.processes.filter(p => p.status === 'ACTIVE').length;
    const baseCount = reloaded.bases.length;
    const teamCount = reloaded.teams.length;

    const passed = procCount === 1 && baseCount === s.bases.length && teamCount === s.teams.length;
    results.push({
      id: 'SAVE-01',
      name: 'Save & Reload Integrity (No Duplicates)',
      passed,
      expected: 'No duplicated processes, units, bases, or teams across reload.',
      actual: `Active Procs: ${procCount}, Bases: ${baseCount}, Teams: ${teamCount}`,
      details: 'Save/reload cycle preserved exact canonical entity sets.',
      timestamp: Date.now()
    });
  } catch (e: any) {
    results.push({ id: 'SAVE-01', name: 'Save Integrity', passed: false, expected: 'Exact match', actual: e.message, details: e.stack, timestamp: Date.now() });
  }

  return results;
}
