/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Command, GameState, Mode, UnitType, StructureType } from '../types/game.ts';
import { MUTATION_RULES } from './data/mutationTable.ts';

/**
 * Normalizes input text for keyword searching
 */
function clean(text: string): string {
  return text.toLowerCase().trim();
}

/**
 * Converts a player natural language prompt + active mode into a strictly typed command.
 */
export function parsePlayerMessage(message: string, state: GameState, activeMode: Mode): Command {
  const text = clean(message);

  // 1. Special case: Independent Hive Expansion pattern from Section 15
  // "Zagara, take 20 zerglings and 5 roaches north and establish an independent hive."
  if (
    (text.includes('establish') || text.includes('found') || text.includes('create') || text.includes('start')) &&
    (text.includes('hive') || text.includes('independent hive') || text.includes('colony'))
  ) {
    // Locate Queen
    const queen = state.swarm.units.find(u => u.type === 'Hive Queen' && u.ownerId === 'swarm');
    // Extract location
    let targetRegion = state.map.regions.find(r => text.includes(r.name.toLowerCase()));
    if (!targetRegion) {
      if (text.includes('north')) targetRegion = state.map.regions.find(r => r.id === 'region-northern-chasm');
      else if (text.includes('east')) targetRegion = state.map.regions.find(r => r.id === 'region-eastern-ridge');
      else if (text.includes('acid') || text.includes('south')) targetRegion = state.map.regions.find(r => r.id === 'region-acid-trench');
      else if (text.includes('cavern')) targetRegion = state.map.regions.find(r => r.id === 'region-spawning-caverns');
      else if (text.includes('sunken')) targetRegion = state.map.regions.find(r => r.id === 'region-sunken-expanse');
    }

    if (queen && targetRegion) {
      // Collect units: e.g. 20 zerglings and 5 roaches
      const assignedUnits: string[] = [];

      // Look for Zerglings
      const zerglingMatch = text.match(/(\d+)\s+zerglings?/);
      const zCount = zerglingMatch ? parseInt(zerglingMatch[1], 10) : 10;
      const zerglings = state.swarm.units.filter(u => u.type === 'Zerglings' && u.ownerId === 'swarm').slice(0, zCount);
      assignedUnits.push(...zerglings.map(u => u.id));

      // Look for Roaches
      const roachMatch = text.match(/(\d+)\s+roaches?/);
      const rCount = roachMatch ? parseInt(roachMatch[1], 10) : 4;
      const roaches = state.swarm.units.filter(u => u.type === 'Roach' && u.ownerId === 'swarm').slice(0, rCount);
      assignedUnits.push(...roaches.map(u => u.id));

      return {
        type: 'CREATE_INDEPENDENT_HIVE',
        payload: {
          queenUnitId: queen.id,
          assignedUnitIds: assignedUnits,
          baseLocation: targetRegion.id,
          hiveName: `${queen.name}'s Hive`
        },
        rawMessage: message
      };
    }
  }

  // 2. Directives to existing Independent Hives
  // e.g. "tell Zagara to scout northern chasm", "order Northern Hive to gather biomass"
  for (const hive of state.hives) {
    const hiveMatches = text.includes(hive.name.toLowerCase()) || text.includes('zagara') || text.includes('hive');
    if (hiveMatches && (text.includes('scout') || text.includes('attack') || text.includes('hunt') || text.includes('defend') || text.includes('gather') || text.includes('order') || text.includes('directive'))) {
      let objectiveType: 'HUNT' | 'ATTACK' | 'DEFEND' | 'EXPAND' | 'BUILD' | 'SCOUT' | 'PATROL' | 'GATHER' = 'SCOUT';
      if (text.includes('attack')) objectiveType = 'ATTACK';
      else if (text.includes('hunt')) objectiveType = 'HUNT';
      else if (text.includes('defend')) objectiveType = 'DEFEND';
      else if (text.includes('gather')) objectiveType = 'GATHER';
      else if (text.includes('build')) objectiveType = 'BUILD';

      const targetRegion = state.map.regions.find(r => text.includes(r.name.toLowerCase())) || state.map.regions[1];

      return {
        type: 'SEND_HIVE_DIRECTIVE',
        payload: {
          hiveId: hive.hiveId,
          orderText: message,
          objectiveType,
          targetLocationId: targetRegion ? targetRegion.id : hive.territory[0]
        },
        rawMessage: message
      };
    }
  }

  // 3. Movement
  // "I walk through the eastern tunnel", "move to Northern Chasm", "travel south", "go to Central Spire"
  if (
    text.startsWith('move') ||
    text.startsWith('go to') ||
    text.startsWith('walk to') ||
    text.includes('i walk') ||
    text.includes('travel to') ||
    text.includes('relocate to')
  ) {
    for (const region of state.map.regions) {
      if (
        text.includes(region.name.toLowerCase()) ||
        (region.name.includes('Eastern') && text.includes('east')) ||
        (region.name.includes('Northern') && text.includes('north')) ||
        (region.name.includes('Acid') && text.includes('acid')) ||
        (region.name.includes('Central') && text.includes('central')) ||
        (region.name.includes('Cavern') && text.includes('cavern'))
      ) {
        return {
          type: 'MOVE_PLAYER',
          payload: { destinationId: region.id },
          rawMessage: message
        };
      }
    }
  }

  // 4. Mutation / Unit Breeding
  // "mutate roach", "incubate overseer", "breed 2 zerglings", "evolve hydralisk"
  if (text.includes('mutate') || text.includes('breed') || text.includes('incubate') || text.includes('produce') || text.includes('evolve')) {
    // Check unit types
    for (const key of Object.keys(MUTATION_RULES)) {
      if (text.includes(key.toLowerCase())) {
        const rule = MUTATION_RULES[key];
        if (rule.category === 'UNIT') {
          return {
            type: 'MUTATE_UNIT',
            payload: {
              unitType: key as UnitType,
              ownerId: 'swarm'
            },
            rawMessage: message
          };
        } else if (rule.category === 'STRUCTURE') {
          if (key === 'Hatchery') {
            const reg = state.map.regions.find(r => text.includes(r.name.toLowerCase())) || state.map.regions.find(r => r.id === state.player.locationId);
            return {
              type: 'BUILD_HATCHERY',
              payload: { regionId: reg ? reg.id : state.player.locationId },
              rawMessage: message
            };
          } else {
            return {
              type: 'MUTATE_STRUCTURE',
              payload: {
                baseId: state.bases[0]?.baseId || 'base-central-spire',
                targetStructure: key as StructureType
              },
              rawMessage: message
            };
          }
        }
      }
    }
  }

  // 5. Nydus Worm
  if (text.includes('nydus') || text.includes('canal') || text.includes('worm')) {
    const reg = state.map.regions.find(r => text.includes(r.name.toLowerCase())) || state.map.regions.find(r => r.id === 'region-sunken-expanse');
    return {
      type: 'CREATE_NYDUS',
      payload: {
        sourceBaseId: state.bases[0]?.baseId || 'base-central-spire',
        destination: reg?.id || 'region-sunken-expanse'
      },
      rawMessage: message
    };
  }

  // 6. Teams
  if (text.includes('team') && (text.includes('create') || text.includes('form') || text.includes('assign'))) {
    const availableUnits = state.swarm.units.filter(u => u.ownerId === 'swarm' && u.status === 'IDLE').slice(0, 4);
    return {
      type: 'CREATE_TEAM',
      payload: {
        ownerId: 'swarm',
        unitIds: availableUnits.map(u => u.id),
        teamName: "Swarm's Strike Claws",
        directive: message
      },
      rawMessage: message
    };
  }

  // 7. Advance turn explicit requests
  if (text === 'end turn' || text === 'next turn' || text === 'wait' || text === 'advance turn' || text === 'pass') {
    return {
      type: 'ADVANCE_TURN',
      payload: {},
      rawMessage: message
    };
  }

  // 8. Default: Conversation / Scene / RP inquiry
  // Covers "ask the nearest queen whether the western scouting party returned", etc.
  return {
    type: 'TALK',
    payload: {
      targetId: 'Queen Zagara',
      message
    },
    rawMessage: message
  };
}
