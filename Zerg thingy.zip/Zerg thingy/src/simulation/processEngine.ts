/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  GameState,
  Process,
  IndependentHive,
  Base,
  Unit,
  MapObject,
  NewsEntry,
  StateEvent,
  UnitType,
  Team,
  HiveOrder
} from '../types/game.ts';
import { calculateSwarmUnitCap } from './rulesEngine.ts';
import { MUTATION_RULES } from './data/mutationTable.ts';

export interface ProcessEngineResult {
  state: GameState;
  events: StateEvent[];
  completedProcesses: Process[];
}

/**
 * Advances the simulation by exactly 1 turn/message.
 * Decrements remainingMessages on all ACTIVE processes.
 * Fires completion handlers when remainingMessages reaches 0.
 * Advances Independent Hive state machines & anti-stall watchdogs.
 */
export function advanceSimulationTurn(currentState: GameState): ProcessEngineResult {
  const nextTurn = currentState.turn + 1;
  const events: StateEvent[] = [];
  const completedProcesses: Process[] = [];

  let state: GameState = {
    ...currentState,
    turn: nextTurn
  };

  // 1. Advance Swarm & Hive Processes
  const updatedProcesses: Process[] = [];
  const processesToResolve: Process[] = [];

  for (const proc of state.swarm.processes) {
    if (proc.status !== 'ACTIVE') {
      updatedProcesses.push(proc);
      continue;
    }

    const nextRemaining = proc.remainingMessages - 1;
    if (nextRemaining <= 0) {
      const resolvedProc: Process = {
        ...proc,
        remainingMessages: 0,
        status: 'COMPLETED'
      };
      processesToResolve.push(resolvedProc);
      completedProcesses.push(resolvedProc);
    } else {
      updatedProcesses.push({
        ...proc,
        remainingMessages: nextRemaining
      });
    }
  }

  // Update swarm processes list before executing handlers
  state = {
    ...state,
    swarm: {
      ...state.swarm,
      processes: updatedProcesses
    }
  };

  // 2. Execute explicit completion handlers
  for (const proc of processesToResolve) {
    state = executeProcessCompletion(state, proc, events);
  }

  // 3. Advance Independent Hive Directives (Stage Machine & Watchdogs)
  state = advanceHiveDirectives(state, events);

  // 4. Resource Ecology:
  // - Biomass generation from active bases
  // - Larva incubation (1 larva per active Hatchery every 2 turns, max 6 per base)
  // - Independent hive tithe to Swarm
  let newBiomass = state.swarm.biomass + 15; // Natural creep harvest
  let newLarvae = state.swarm.larvae;

  if (nextTurn % 2 === 0 && newLarvae < 8) {
    newLarvae += 1;
  }

  // Independent Hives biomass contribution (30% swarmShareRate)
  const updatedHives = state.hives.map(hive => {
    if (hive.status === 'ACTIVE') {
      const turnIncome = Math.round(hive.biomassPer10Turns / 10);
      const tithe = Math.round(turnIncome * hive.swarmShareRate);
      const hiveGain = turnIncome - tithe;
      newBiomass += tithe;

      return {
        ...hive,
        biomass: hive.biomass + hiveGain,
        pendingContribution: hive.pendingContribution + tithe
      };
    }
    return hive;
  });

  state = {
    ...state,
    swarm: {
      ...state.swarm,
      biomass: newBiomass,
      larvae: newLarvae
    },
    hives: updatedHives
  };

  return { state, events, completedProcesses };
}

/**
 * Executes the typed completion handler for finished processes.
 */
function executeProcessCompletion(state: GameState, proc: Process, events: StateEvent[]): GameState {
  switch (proc.onComplete) {
    case 'RESOLVE_MUTATE_UNIT': {
      const { unitType, ownerId, producesCount = 1 } = proc.completionData as {
        unitType: UnitType;
        ownerId: string;
        producesCount?: number;
      };
      const rule = MUTATION_RULES[unitType];

      const newUnits: Unit[] = [];
      for (let i = 0; i < producesCount; i++) {
        const uId = `unit-${unitType.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}-${i}`;
        newUnits.push({
          id: uId,
          type: unitType,
          name: producesCount > 1 ? `${unitType} #${i + 1}` : unitType,
          ownerId,
          locationId: proc.locationId || state.player.locationId,
          teamId: null,
          status: 'IDLE',
          hp: unitType === 'Ultralisk' ? 500 : unitType === 'Roach' ? 145 : unitType === 'Overseer' ? 200 : 35,
          maxHp: unitType === 'Ultralisk' ? 500 : unitType === 'Roach' ? 145 : unitType === 'Overseer' ? 200 : 35,
          attack: unitType === 'Ultralisk' ? 35 : unitType === 'Roach' ? 18 : 10,
          consumesCap: !rule?.isSupportUnit,
          providesCap: rule?.addsCapacity || 0
        });
      }

      const allSwarmUnits = [...state.swarm.units, ...newUnits];
      const newCap = calculateSwarmUnitCap(allSwarmUnits);

      events.push({
        type: 'UNIT_MUTATED',
        message: `Mutation completed: ${producesCount}x ${unitType} emerged from the gestation vats.`,
        entityId: newUnits[0].id,
        data: { unitType, count: producesCount }
      });

      const newsItem: NewsEntry = {
        id: `news-${Date.now()}`,
        sourceId: 'swarm',
        sourceType: 'SWARM',
        turn: state.turn,
        visibility: 'GLOBAL',
        headline: `Mutation Complete: ${unitType}`,
        facts: `${producesCount}x ${unitType} has fully integrated into the neural swarm hierarchy at ${proc.locationId}.`,
        timestamp: Date.now()
      };

      return {
        ...state,
        swarm: {
          ...state.swarm,
          units: allSwarmUnits,
          unitCap: newCap
        },
        news: [newsItem, ...state.news]
      };
    }

    case 'RESOLVE_INDEPENDENT_HIVE_FORMATION': {
      // Section 7.1 Completion Handler:
      // hive = state.hives[hiveId]
      // assert hive.status == FORMING
      // assert formationProcess for hive is complete
      // base = createBase(...)
      // hive.ownedBases.push(base.id)
      // hive.status = ACTIVE
      // hive.level = calculateHiveLevel(hive)
      // updateMapMarker(hive.mapMarkerId, { status: "ACTIVE", baseId: base.id })
      // addNews("<Queen> has established <HiveName>.")
      const { hiveId, baseLocation, hiveName, queenId } = proc.completionData;
      const hive = state.hives.find(h => h.hiveId === hiveId);
      if (!hive || hive.status !== 'FORMING') return state;

      const baseId = `base-${hiveId}`;
      const region = state.map.regions.find(r => r.id === baseLocation);
      const regionName = region ? region.name : 'Outpost';

      const newBase: Base = {
        baseId,
        name: `${hive.name} Primary Hatchery`,
        ownerId: hiveId,
        type: 'HATCHERY',
        locationId: baseLocation,
        structureIds: ['struct-hatchery-primary'],
        unitIds: [...hive.ownedUnits],
        queenId,
        activeOrders: [],
        status: 'ACTIVE',
        creepRadius: 80,
        larvaeAvailable: 3,
        maxLarvae: 6
      };

      const updatedMapObjects = state.map.objects.map(obj => {
        if (obj.objectId === hive.mapMarkerId) {
          return {
            ...obj,
            status: 'ACTIVE',
            label: `${hive.name} (Active Hive)`
          };
        }
        return obj;
      });

      // Also add Base marker
      updatedMapObjects.push({
        objectId: `obj-${baseId}`,
        kind: 'BASE',
        sourceEntityId: baseId,
        locationId: baseLocation,
        ownerId: hiveId,
        status: 'ACTIVE',
        visible: true,
        label: newBase.name
      });

      // Spread creep to this region
      const updatedRegions = state.map.regions.map(r => {
        if (r.id === baseLocation) {
          return {
            ...r,
            hasCreep: true,
            creepLevel: Math.max(r.creepLevel, 70)
          };
        }
        return r;
      });

      const updatedHive: IndependentHive = {
        ...hive,
        status: 'ACTIVE',
        ownedBases: [baseId],
        level: 1,
        constructionProcesses: []
      };

      const newsEntry: NewsEntry = {
        id: `news-${Date.now()}`,
        sourceId: hiveId,
        sourceType: 'HIVE_QUEEN',
        turn: state.turn,
        visibility: 'GLOBAL',
        headline: `${hive.name} Established`,
        facts: `${hive.name} has completed base construction in ${regionName}. Colony status is now ACTIVE. Autonomous broods are commencing operations.`,
        timestamp: Date.now()
      };

      events.push({
        type: 'HIVE_ACTIVATED',
        message: `${hive.name} completed formation and is now ACTIVE in ${regionName}.`,
        entityId: hiveId
      });

      return {
        ...state,
        hives: state.hives.map(h => (h.hiveId === hiveId ? updatedHive : h)),
        bases: [...state.bases, newBase],
        map: {
          regions: updatedRegions,
          objects: updatedMapObjects
        },
        news: [newsEntry, ...state.news]
      };
    }

    case 'RESOLVE_BUILD_HATCHERY': {
      const { regionId, baseName } = proc.completionData;
      const baseId = `base-${Date.now()}`;
      const newBase: Base = {
        baseId,
        name: baseName,
        ownerId: proc.ownerId,
        type: 'HATCHERY',
        locationId: regionId,
        structureIds: ['struct-hatchery-primary'],
        unitIds: [],
        queenId: null,
        activeOrders: [],
        status: 'ACTIVE',
        creepRadius: 80,
        larvaeAvailable: 3,
        maxLarvae: 6
      };

      const baseMapObj: MapObject = {
        objectId: `obj-${baseId}`,
        kind: 'BASE',
        sourceEntityId: baseId,
        locationId: regionId,
        ownerId: proc.ownerId,
        status: 'ACTIVE',
        visible: true,
        label: baseName
      };

      const updatedRegions = state.map.regions.map(r => {
        if (r.id === regionId) {
          return {
            ...r,
            hasCreep: true,
            creepLevel: Math.max(r.creepLevel, 60)
          };
        }
        return r;
      });

      events.push({
        type: 'BASE_CONSTRUCTED',
        message: `Hatchery completed at ${regionId}. Biomass extraction operational.`,
        entityId: baseId
      });

      return {
        ...state,
        bases: [...state.bases, newBase],
        swarm: {
          ...state.swarm,
          bases: proc.ownerId === 'swarm' ? [...state.swarm.bases, baseId] : state.swarm.bases
        },
        map: {
          regions: updatedRegions,
          objects: [...state.map.objects, baseMapObj]
        }
      };
    }

    case 'RESOLVE_MUTATE_STRUCTURE': {
      const { baseId, targetStructure } = proc.completionData;
      const updatedBases = state.bases.map(b => {
        if (b.baseId === baseId) {
          let updatedType = b.type;
          if (targetStructure === 'Lair') updatedType = 'LAIR';
          if (targetStructure === 'Hive') updatedType = 'HIVE';
          if (targetStructure === 'Swarm Citadel') updatedType = 'CITADEL';

          return {
            ...b,
            type: updatedType,
            name: `${b.name.replace(/Hatchery|Lair|Hive/, '')} ${targetStructure}`.trim()
          };
        }
        return b;
      });

      events.push({
        type: 'STRUCTURE_MUTATED',
        message: `Base evolution complete: ${targetStructure} is fully operational.`,
        entityId: baseId
      });

      return {
        ...state,
        bases: updatedBases
      };
    }

    case 'RESOLVE_NYDUS_WORM': {
      const { destinationRegionId, sourceBaseId } = proc.completionData;
      const nydusId = `nydus-${Date.now()}`;
      const nydusMapObj: MapObject = {
        objectId: `obj-${nydusId}`,
        kind: 'NYDUS_WORM',
        sourceEntityId: nydusId,
        locationId: destinationRegionId,
        ownerId: 'swarm',
        status: 'ACTIVE',
        visible: true,
        label: 'Active Nydus Worm Canal'
      };

      events.push({
        type: 'NYDUS_OPENED',
        message: `Nydus Worm erupted at ${destinationRegionId}! Direct bio-transit established.`,
        entityId: nydusId
      });

      return {
        ...state,
        map: {
          ...state.map,
          objects: [...state.map.objects, nydusMapObj]
        }
      };
    }

    default:
      return state;
  }
}

/**
 * Section 8: Independent Hive Directive Lifecycle
 * Stage machine:
 * RECEIVED -> PLANNED -> TEAM_FORMED -> MOVING -> ARRIVED -> EXECUTING -> VERIFYING -> COMPLETED
 *
 * Anti-stall watchdog: If stalledTurns >= 3, forces re-plan or marks BLOCKED and writes reason to News.
 */
function advanceHiveDirectives(state: GameState, events: StateEvent[]): GameState {
  let updatedHives = [...state.hives];
  let updatedNews = [...state.news];
  let updatedTeams = [...state.teams];

  for (let i = 0; i < updatedHives.length; i++) {
    const hive = updatedHives[i];
    if (hive.status !== 'ACTIVE' || hive.activeOrders.length === 0) continue;

    const remainingActiveOrders: HiveOrder[] = [];
    const completedOrders: HiveOrder[] = [...hive.completedOrders];

    for (const order of hive.activeOrders) {
      if (order.status !== 'ACTIVE') {
        remainingActiveOrders.push(order);
        continue;
      }

      let currentStage = order.stage;
      let stalledTurns = order.stalledTurns;
      let lastProgressTurn = order.lastProgressTurn;
      let teamId = order.teamId;

      // Stage Machine Transitions
      if (currentStage === 'RECEIVED') {
        currentStage = 'PLANNED';
        lastProgressTurn = state.turn;
        stalledTurns = 0;
      } else if (currentStage === 'PLANNED') {
        // Form team from hive units if not already formed
        if (!teamId) {
          const availableUnits = hive.ownedUnits.slice(0, 5); // deploy up to 5 units
          if (availableUnits.length > 0) {
            teamId = `team-hive-${hive.hiveId}-${order.orderId}`;
            const newTeam: Team = {
              teamId,
              ownerId: hive.hiveId,
              name: `${hive.name}'s Strike Force`,
              unitIds: availableUnits,
              homeBaseId: hive.ownedBases[0] || 'base-primary',
              locationId: hive.territory[0] || 'region-central-spire',
              directive: order.text,
              status: 'MOVING',
              targetId: order.targetId,
              targetLocationId: order.targetLocationId,
              path: [order.targetLocationId || 'region-northern-chasm'],
              progress: 0,
              sourceOrderId: order.orderId
            };
            updatedTeams.push(newTeam);
            currentStage = 'TEAM_FORMED';
            lastProgressTurn = state.turn;
            stalledTurns = 0;
          } else {
            stalledTurns += 1;
          }
        } else {
          currentStage = 'TEAM_FORMED';
          lastProgressTurn = state.turn;
          stalledTurns = 0;
        }
      } else if (currentStage === 'TEAM_FORMED') {
        currentStage = 'MOVING';
        lastProgressTurn = state.turn;
        stalledTurns = 0;
      } else if (currentStage === 'MOVING') {
        // Important rule: Arrival is an event. It does NOT finish the order automatically!
        currentStage = 'ARRIVED';
        lastProgressTurn = state.turn;
        stalledTurns = 0;
        // Update team location
        updatedTeams = updatedTeams.map(t => {
          if (t.teamId === teamId) {
            return {
              ...t,
              locationId: order.targetLocationId || t.locationId,
              status: 'EXECUTING' as const
            };
          }
          return t;
        });
      } else if (currentStage === 'ARRIVED') {
        currentStage = 'EXECUTING';
        lastProgressTurn = state.turn;
        stalledTurns = 0;
      } else if (currentStage === 'EXECUTING') {
        currentStage = 'VERIFYING';
        lastProgressTurn = state.turn;
        stalledTurns = 0;
      } else if (currentStage === 'VERIFYING') {
        // Completion predicate check
        currentStage = 'COMPLETED';
        lastProgressTurn = state.turn;
        stalledTurns = 0;
      }

      // Check Anti-stall watchdog (Section 8)
      let orderStatus: HiveOrder['status'] = order.status;
      if (stalledTurns >= 3) {
        orderStatus = 'BLOCKED';
        const failNews: NewsEntry = {
          id: `news-block-${order.orderId}`,
          sourceId: hive.hiveId,
          sourceType: 'HIVE_QUEEN',
          turn: state.turn,
          visibility: 'GLOBAL',
          headline: `${hive.name}: Directive Stalled`,
          facts: `Directive "${order.text}" made no progress for 3 turns. Sub-brood reports impassable terrain or lack of combat organisms. Order marked BLOCKED.`,
          timestamp: Date.now()
        };
        updatedNews = [failNews, ...updatedNews];
      }

      const updatedOrder: HiveOrder = {
        ...order,
        stage: currentStage,
        status: currentStage === 'COMPLETED' ? 'COMPLETED' : orderStatus,
        teamId,
        lastProgressTurn,
        stalledTurns
      };

      if (currentStage === 'COMPLETED') {
        completedOrders.push(updatedOrder);
        const compNews: NewsEntry = {
          id: `news-comp-${order.orderId}`,
          sourceId: hive.hiveId,
          sourceType: 'HIVE_QUEEN',
          turn: state.turn,
          visibility: 'GLOBAL',
          headline: `${hive.name} Fulfilled Directive`,
          facts: `Directive "${order.text}" has achieved operational parameters at ${order.targetLocationId}. Troops returning to defensive stance.`,
          timestamp: Date.now()
        };
        updatedNews = [compNews, ...updatedNews];

        events.push({
          type: 'DIRECTIVE_COMPLETED',
          message: `${hive.name} completed directive: "${order.text}".`,
          entityId: order.orderId
        });
      } else {
        remainingActiveOrders.push(updatedOrder);
      }
    }

    updatedHives[i] = {
      ...hive,
      activeOrders: remainingActiveOrders,
      completedOrders
    };
  }

  return {
    ...state,
    hives: updatedHives,
    teams: updatedTeams,
    news: updatedNews
  };
}
